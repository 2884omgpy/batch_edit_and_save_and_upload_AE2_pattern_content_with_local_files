package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import appeng.parts.crafting.PatternProviderPart;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.init.ModJEIPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotView;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.fluids.FluidStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class PatternContentHelper
{
    //将JEI中的List<IRecipeSlotView>转换为List<GenericStack>
    public static List<GenericStack> List_IRecipeSlotView_to_List_GenericStack(List<IRecipeSlotView> slotViews)
    {
        List<GenericStack> genericStacks = new ArrayList<>();
        for (IRecipeSlotView slotView : slotViews)
        {
            Optional<ITypedIngredient<?>> displayed = slotView.getDisplayedIngredient();
            if (displayed.isPresent())
            {
                Object ingredient = displayed.get().getIngredient();
                if (ingredient instanceof ItemStack)
                {
                    genericStacks.add(GenericStack.fromItemStack((ItemStack) ingredient));
                }
                else
                    if (ingredient instanceof FluidStack)
                    {
                        genericStacks.add(GenericStack.fromFluidStack((FluidStack) ingredient));
                    }
                        else
                        {
                            genericStacks.add(null);
                        }
            }
                else
                {
                    genericStacks.add(null);
                }
        }
        return genericStacks;
    }

    //AE2 GenericStack转换为ItemStack
    public static ItemStack genericStackToItemStack(GenericStack genericStack)
    {
        if (genericStack == null || !(genericStack.what() instanceof AEItemKey itemKey))
        {
            return ItemStack.EMPTY;
        }
        ItemStack itemStack = itemKey.toStack();
        int amount = (int) Math.min(genericStack.amount(), itemStack.getMaxStackSize());
        itemStack.setCount(amount);
        return itemStack;
    }

    //AE2 GenericStack转换为FluidStack
    public static FluidStack genericStackToFluidStack(GenericStack genericStack)
    {
        if (genericStack == null || !(genericStack.what() instanceof AEFluidKey fluidKey))
        {
            return FluidStack.EMPTY;
        }
        int amount = (int)genericStack.amount();
        return fluidKey.toStack(amount);
    }

    //根据样板SNBT中的tag内容生成对应的List<GenericStack>
    public static List<GenericStack> patternTag_to_List_GenericStack(CompoundTag tag, String patternType, String slotSemantic)
    {
        List<GenericStack> patternInputOrOutputStacks = new ArrayList<>();

        if(patternType.equals("ae2:smithing_table_pattern") && slotSemantic.equals("in"))
        {
            if (tag.get("template") instanceof ListTag inList)
            {
                patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inList.getCompound(0)));
            }
            else
                if (tag.get("template") instanceof CompoundTag inCompound)
                {
                    patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inCompound));
                }

            if (tag.get("base") instanceof ListTag inList)
            {
                patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inList.getCompound(0)));
            }
            else
                if (tag.get("base") instanceof CompoundTag inCompound)
                {
                    patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inCompound));
                }

            if (tag.get("addition") instanceof ListTag inList)
            {
                patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inList.getCompound(0)));
            }
            else
                if (tag.get("addition") instanceof CompoundTag inCompound)
                {
                    patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inCompound));
                }
        }
            else
            {
                if (tag.contains(slotSemantic))
                {
                    if (tag.get(slotSemantic) instanceof ListTag inList)
                    {
                        for (int i = 0; i < inList.size(); i++)
                        {
                            patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inList.getCompound(i)));
                        }
                    }
                    else
                        if (tag.get(slotSemantic) instanceof CompoundTag inCompound)
                        {
                            patternInputOrOutputStacks.add(PatternContentHelper.Tag_to_GenericStack(inCompound));
                        }
                }
            }
        return patternInputOrOutputStacks;
    }

    //根据样板SNBT中的单个tag内容生成对应的GenericStack
    public static GenericStack Tag_to_GenericStack(CompoundTag tag)
    {
        if (tag == null || tag.isEmpty())
        {
            return null;
        }
        //优先作为GenericStack
        if (tag.contains("#c"))
        {
            return GenericStack.readTag(tag);
        }
            else
            {
                //否则作为物品
                ItemStack item = ItemStack.of(tag);
                if (!item.isEmpty())
                {
                    return GenericStack.fromItemStack(item);
                }
                return null;
            }
    }

    //根据GenericStack生成样板Tag
    public static CompoundTag GenericStack_to_Tag(GenericStack stack, boolean isProcessing)
    {
        if (stack == null)
        {
            return new CompoundTag();
        }
        if (stack.what() instanceof AEItemKey itemKey)
        {
            CompoundTag tag = new CompoundTag();
            if (isProcessing)
            {
                tag.putLong("#", stack.amount());
                tag.putString("#c", "ae2:i");
                tag.putString("id", BuiltInRegistries.ITEM.getKey(itemKey.getItem()).toString());
            }
                else
                {
                    tag.putString("id", BuiltInRegistries.ITEM.getKey(itemKey.getItem()).toString());
                    tag.putByte("Count", (byte) stack.amount());
                }
            ItemStack item = itemKey.toStack();
            if (item.hasTag())
            {
                tag.put("tag", item.getTag().copy());
            }
            return tag;
        }
        else
            if (stack.what() instanceof AEFluidKey fluidKey)
            {
                CompoundTag tag = new CompoundTag();
                tag.putLong("#", stack.amount());
                tag.putString("#c", "ae2:f");
                tag.putString("id", BuiltInRegistries.FLUID.getKey(fluidKey.getFluid()).toString());
                CompoundTag fluidTag = fluidKey.getTag();
                if (fluidTag != null && !fluidTag.isEmpty())
                {
                    tag.put("tag", fluidTag.copy());
                }
                return tag;
            }
        return new CompoundTag();
    }

    //根据样板SNBT中的tag内容生成对应的List<String>（用于样板内容无法正确读取时）
    public static List<String> patternTag_to_List_String(CompoundTag tag, String patternType, String slotSemantic)
    {
        List<String> patternInputOrOutputString = new ArrayList<>();

        if(patternType.equals("ae2:smithing_table_pattern") && slotSemantic.equals("in"))
        {
            if (tag.get("template") instanceof ListTag inList)
            {
                patternInputOrOutputString.add(inList.getCompound(0).isEmpty() ? null : inList.getCompound(0).getString("id"));
            }
            else
            if (tag.get("template") instanceof CompoundTag inCompound)
            {
                patternInputOrOutputString.add(inCompound.isEmpty() ? null : inCompound.getString("id"));
            }

            if (tag.get("base") instanceof ListTag inList)
            {
                patternInputOrOutputString.add(inList.getCompound(0).isEmpty() ? null : inList.getCompound(0).getString("id"));
            }
            else
            if (tag.get("base") instanceof CompoundTag inCompound)
            {
                patternInputOrOutputString.add(inCompound.isEmpty() ? null : inCompound.getString("id"));
            }

            if (tag.get("addition") instanceof ListTag inList)
            {
                patternInputOrOutputString.add(inList.getCompound(0).isEmpty() ? null : inList.getCompound(0).getString("id"));
            }
            else
            if (tag.get("addition") instanceof CompoundTag inCompound)
            {
                patternInputOrOutputString.add(inCompound.isEmpty() ? null : inCompound.getString("id"));
            }
        }
        else
        {
            if (tag.contains(slotSemantic))
            {
                if (tag.get(slotSemantic) instanceof ListTag inList)
                {
                    for (int i = 0; i < inList.size(); i++)
                    {
                        patternInputOrOutputString.add(inList.getCompound(i).isEmpty() ? null : inList.getCompound(i).getString("id"));
                    }
                }
                else
                if (tag.get(slotSemantic) instanceof CompoundTag inCompound)
                {
                    patternInputOrOutputString.add(inCompound.isEmpty() ? null : inCompound.getString("id"));
                }
            }
        }
        return patternInputOrOutputString;
    }

    public static GenericStack patternTag_to_GenericStack(CompoundTag patternTag, String slotSemantic, int index)
    {
        CompoundTag tag = patternTag.getCompound("tag");
        GenericStack genericStack = null;

        if (tag.contains(slotSemantic))
        {
            Tag slotTag = tag.get(slotSemantic);
            if (slotTag instanceof CompoundTag slotCompound)
            {
                if (slotCompound.contains("#c"))
                {
                    genericStack = GenericStack.readTag(slotCompound);
                }
                else
                {
                    ItemStack item = ItemStack.of(slotCompound);
                    if (!item.isEmpty())
                    {
                        genericStack = GenericStack.fromItemStack(item);
                    }
                }
            }
            else
                if (slotTag instanceof ListTag item_list)
                {
                    if (!item_list.isEmpty())
                    {
                        CompoundTag slotContent = item_list.getCompound(index);
                        if (slotContent.contains("#c"))
                        {
                            genericStack = GenericStack.readTag(slotContent);
                        }
                        else
                        {
                            ItemStack item = ItemStack.of(slotContent);
                            if (!item.isEmpty())
                            {
                                genericStack = GenericStack.fromItemStack(item);
                            }
                        }
                    }
                }
        }
        return genericStack;
    }

    //JEI配方->样板NBT
    public static CompoundTag JeiRecipeToPatternNBT(IRecipeCategory<?> category, Object recipe, IRecipeLayoutDrawable<?> layout, String patternType)
    {
        String categoryUid = patternType == null ? category.getRecipeType().getUid().toString() : patternType;

        CompoundTag patternTag = new CompoundTag();
        patternTag.putByte("Count", (byte) 1);

        //获取所有槽位视图
        IRecipeSlotsView slotsView = layout.getRecipeSlotsView();
        List<IRecipeSlotView> slotViews = slotsView.getSlotViews();

        //分离输入和输出槽位
        List<IRecipeSlotView> inputSlots = new ArrayList<>();
        List<IRecipeSlotView> outputSlots = new ArrayList<>();

        for (IRecipeSlotView slotView : slotViews)
        {
            RecipeIngredientRole role = slotView.getRole();
            if (role == RecipeIngredientRole.INPUT)
            {
                inputSlots.add(slotView);
            }
            else
                if (role == RecipeIngredientRole.OUTPUT)
                {
                    outputSlots.add(slotView);
                }
        }

        return inputAndOutputAndPatternTypeAndRecipeToPatternNBT(List_IRecipeSlotView_to_List_GenericStack(inputSlots), List_IRecipeSlotView_to_List_GenericStack(outputSlots), categoryUid, recipe);
    }

    //3参数方法
    public static CompoundTag JeiRecipeToPatternNBT(IRecipeCategory<?> category, Object recipe, IRecipeLayoutDrawable<?> layout)
    {
        return JeiRecipeToPatternNBT(category, recipe, layout, null);
    }

    public static CompoundTag inputAndOutputAndPatternTypeAndRecipeToPatternNBT(List<GenericStack> inputStacks, List<GenericStack> outputStacks, String patternType, Object recipe)
    {
        CompoundTag tag = new CompoundTag();
        CompoundTag patternTag = new CompoundTag();
        //合成配方
        if (patternType.equals("minecraft:crafting") || patternType.contains("crafting"))
        {
            patternTag.putString("id", "ae2:crafting_pattern");

            //输入
            ListTag inList = new ListTag();
            for (int i = 0; i < 9; i++)
            {
                if (i < inputStacks.size())
                {
                    ItemStack inputStack = genericStackToItemStack(inputStacks.get(i));
                    if (!inputStack.isEmpty())
                    {
                        inList.add(itemStackToTag(inputStack, false));
                    }
                        else
                        {
                            inList.add(new CompoundTag());
                        }
                }
                    else
                    {
                        inList.add(new CompoundTag());
                    }
            }
            tag.put("in", inList);

            //输出
            if (!outputStacks.isEmpty())
            {
                ItemStack outputStack = genericStackToItemStack(outputStacks.get(0));
                if (!outputStack.isEmpty())
                {
                    tag.put("out", itemStackToTag(outputStack, true));
                }
            }

            //配方ID
            if (recipe instanceof Recipe && Minecraft.getInstance().level != null)
            {
                ResourceLocation id = ((Recipe<?>) recipe).getId();

                //有效原版配方ID
                if (Minecraft.getInstance().level.getRecipeManager().byKey(id).isPresent())
                {
                    tag.putString("recipe", id.toString());
                }
                    else//配方ID无效
                    {

                    }
            }
            tag.putByte("substitute", (byte) 0);
            tag.putByte("substituteFluids", (byte) 1);
        }
        else//锻造台配方
            if (patternType.equals("minecraft:smithing"))
            {
                patternTag.putString("id", "ae2:smithing_table_pattern");

                //三个输入
                CompoundTag templateTag = new CompoundTag();
                CompoundTag baseTag = new CompoundTag();
                CompoundTag additionTag = new CompoundTag();

                if (inputStacks.get(0) != null)
                {
                    ItemStack templateStack = genericStackToItemStack(inputStacks.get(0));
                    if (!templateStack.isEmpty())
                    {
                        templateTag = itemStackToTag(templateStack, true);
                    }
                }
                if (inputStacks.get(1) != null)
                {
                    ItemStack baseStack = genericStackToItemStack(inputStacks.get(1));
                    if (!baseStack.isEmpty())
                    {
                        baseTag = itemStackToTag(baseStack, true);
                    }
                }
                if (inputStacks.get(2) != null)
                {
                    ItemStack additionStack = genericStackToItemStack(inputStacks.get(2));
                    if (!additionStack.isEmpty())
                    {
                        additionTag = itemStackToTag(additionStack, true);
                    }
                }

                tag.put("template", templateTag);
                tag.put("base", baseTag);
                tag.put("addition", additionTag);

                //输出
                if (!outputStacks.isEmpty())
                {
                    ItemStack outStack = genericStackToItemStack(outputStacks.get(0));
                    if (!outStack.isEmpty())
                    {
                        tag.put("out", itemStackToTag(outStack, true));
                    }
                }

                //配方ID
                if (recipe instanceof Recipe)
                {
                    tag.putString("recipe", ((Recipe<?>) recipe).getId().toString());
                }
                tag.putByte("substitute", (byte) 0);
            }
            else//切石机配方
                if (patternType.equals("minecraft:stonecutting"))
                {
                    patternTag.putString("id", "ae2:stonecutting_pattern");

                    //输入
                    if (!inputStacks.isEmpty())
                    {
                        ItemStack inStack = genericStackToItemStack(inputStacks.get(0));
                        if (!inStack.isEmpty())
                        {
                            tag.put("in", itemStackToTag(inStack, true));
                        }
                    }

                    //输出
                    if (!outputStacks.isEmpty())
                    {
                        ItemStack outStack = genericStackToItemStack(outputStacks.get(0));
                        if (!outStack.isEmpty())
                        {
                            tag.put("out", itemStackToTag(outStack, true));
                        }
                    }

                    //配方id
                    if (recipe instanceof Recipe)
                    {
                        tag.putString("recipe", ((Recipe<?>) recipe).getId().toString());
                    }
                    tag.putByte("substitute", (byte) 0);
                }
                else//处理样板（所有其他类别）
                {
                    patternTag.putString("id", "ae2:processing_pattern");

                    //输入
                    ListTag inList = new ListTag();
                    for (int i = 0; i < 81; i++)
                    {
                        if (i < inputStacks.size())
                        {
                            GenericStack inputStack = inputStacks.get(i);
                            if (inputStack != null)
                            {
                                inList.add(processingPatternGenericStackToTag(inputStack));
                            }
                                else
                                {
                                    inList.add(new CompoundTag());
                                }
                        }
                            else
                            {
                                inList.add(new CompoundTag());
                            }
                    }
                    tag.put("in", inList);

                    //输出
                    ListTag outList = new ListTag();
                    for (int i = 0; i < 27; i++)
                    {
                        if (i < outputStacks.size())
                        {
                            GenericStack outputStack = outputStacks.get(i);
                            if (outputStack != null)
                            {
                                outList.add(processingPatternGenericStackToTag(outputStack));
                            }
                                else
                                {
                                    outList.add(new CompoundTag());
                                }
                        }
                            else
                            {
                                outList.add(new CompoundTag());
                            }
                    }
                    tag.put("out", outList);
                }

        patternTag.put("tag", tag);
        return patternTag;
    }

    //获取样板类型
    public static String getPatternTypeFromCategory(IRecipeCategory<?> category)
    {
        String uid = category.getRecipeType().getUid().toString();
        return uid.equals("minecraft:crafting") || uid.equals("minecraft:smithing") || uid.equals("minecraft:stonecutting") ? uid : "ae2:processing";
    }

    //获取JEI配方槽位信息（用于原材料选择）
    public static List<InputSlotInfo> collectInputSlotInfos(IRecipeLayoutDrawable<?> layout)
    {
        List<InputSlotInfo> infos = new ArrayList<>();
        IRecipeSlotsView slotsView = layout.getRecipeSlotsView();
        IJeiRuntime jeiRuntime = ModJEIPlugin.getJeiRuntime();
        if (jeiRuntime == null)
        {
            return infos;
        }

        IIngredientManager ingredientManager = jeiRuntime.getIngredientManager();
        Optional<IIngredientType<FluidStack>> fluidTypeOpt = ingredientManager.getIngredientTypeChecked(FluidStack.class);
        IIngredientType<FluidStack> fluidType = fluidTypeOpt.orElse(null);

        for (IRecipeSlotView slotView : slotsView.getSlotViews())
        {
            if (slotView.getRole() == RecipeIngredientRole.INPUT)
            {
                List<GenericStack> candidates = new ArrayList<>();

                //物品原料
                List<ItemStack> itemIngredients = slotView.getIngredients(VanillaTypes.ITEM_STACK).toList();
                for (int i = 0; i < itemIngredients.size(); i++)
                {
                    GenericStack stack = GenericStack.fromItemStack(itemIngredients.get(i));
                    if (stack != null)
                    {
                        candidates.add(stack);
                    }
                }

                //流体原料
                if (fluidType != null)
                {
                    List<FluidStack> fluidIngredients = slotView.getIngredients(fluidType).toList();
                    for (int i = 0; i < fluidIngredients.size(); i++)
                    {
                        GenericStack stack = GenericStack.fromFluidStack(fluidIngredients.get(i));
                        if (stack != null)
                        {
                            candidates.add(stack);
                        }
                    }
                }

                if (!candidates.isEmpty())
                {
                    //推断标签（若所有候选物品共享同一标签）
                    String tagId = null;

                    //如果第0个是物品，那么就应该都是物品
                    if (candidates.get(0).what() instanceof AEItemKey)
                    {
                        Set<ResourceLocation> commonTags = null;
                        for (GenericStack gs : candidates)
                        {
                            if (!(gs.what() instanceof AEItemKey))
                            {
                                commonTags = null;
                                break;
                            }

                            ItemStack stack = ((AEItemKey) gs.what()).toStack();
                            Set<ResourceLocation> tags = stack.getTags().map(t -> t.location()).collect(Collectors.toSet());
                            if (commonTags == null)
                            {
                                commonTags = tags;
                            }
                                else
                                {
                                    commonTags.retainAll(tags);
                                    if (commonTags.isEmpty())
                                    {
                                        break;
                                    }
                                }
                        }
                        if (commonTags != null && commonTags.size() == 1)
                        {
                            tagId = "#" + commonTags.iterator().next().toString();
                        }
                    }
                    infos.add(new PatternContentHelper.InputSlotInfo(candidates, tagId));
                }
                    else
                    {
                        infos.add(new PatternContentHelper.InputSlotInfo(null, null));
                    }
            }
        }
        return infos;
    }

    public static List<OutputSlotInfo> collectOutputSlotInfos(IRecipeLayoutDrawable<?> layout)
    {
        List<OutputSlotInfo> infos = new ArrayList<>();
        IRecipeSlotsView slotsView = layout.getRecipeSlotsView();
        IJeiRuntime jeiRuntime = ModJEIPlugin.getJeiRuntime();
        if (jeiRuntime == null)
        {
            return infos;
        }

        IIngredientManager ingredientManager = jeiRuntime.getIngredientManager();
        Optional<IIngredientType<FluidStack>> fluidTypeOpt = ingredientManager.getIngredientTypeChecked(FluidStack.class);
        IIngredientType<FluidStack> fluidType = fluidTypeOpt.orElse(null);

        for (IRecipeSlotView slotView : slotsView.getSlotViews())
        {
            if (slotView.getRole() == RecipeIngredientRole.OUTPUT)
            {
                List<GenericStack> candidates = new ArrayList<>();

                //物品产出
                List<ItemStack> itemIngredients = slotView.getIngredients(VanillaTypes.ITEM_STACK).toList();
                for (int i = 0; i < itemIngredients.size(); i++)
                {
                    GenericStack stack = GenericStack.fromItemStack(itemIngredients.get(i));
                    if (stack != null)
                    {
                        candidates.add(stack);
                    }
                }

                //流体产出
                if (fluidType != null)
                {
                    List<FluidStack> fluidIngredients = slotView.getIngredients(fluidType).toList();
                    for (int i = 0; i < fluidIngredients.size(); i++)
                    {
                        GenericStack stack = GenericStack.fromFluidStack(fluidIngredients.get(i));
                        if (stack != null)
                        {
                            candidates.add(stack);
                        }
                    }
                }

                if (!candidates.isEmpty())
                {
                    //推断标签（若所有候选物品共享同一标签）
                    String tagId = null;

                    //如果第0个是物品，那么就应该都是物品
                    if (candidates.get(0).what() instanceof AEItemKey)
                    {
                        Set<ResourceLocation> commonTags = null;
                        for (GenericStack gs : candidates)
                        {
                            if (!(gs.what() instanceof AEItemKey))
                            {
                                commonTags = null;
                                break;
                            }

                            ItemStack stack = ((AEItemKey) gs.what()).toStack();
                            Set<ResourceLocation> tags = stack.getTags().map(t -> t.location()).collect(Collectors.toSet());
                            if (commonTags == null)
                            {
                                commonTags = tags;
                            }
                            else
                            {
                                commonTags.retainAll(tags);
                                if (commonTags.isEmpty())
                                {
                                    break;
                                }
                            }
                        }
                        if (commonTags != null && commonTags.size() == 1)
                        {
                            tagId = "#" + commonTags.iterator().next().toString();
                        }
                    }
                    infos.add(new PatternContentHelper.OutputSlotInfo(candidates, tagId));
                }
                else
                {
                    infos.add(new PatternContentHelper.OutputSlotInfo(null, null));
                }
            }
        }
        return infos;
    }

    public static class InputSlotInfo
    {
        public List<GenericStack> candidates;
        public String tagId;
        InputSlotInfo(List<GenericStack> candidates, String tagId)
        {
            this.candidates = candidates;
            this.tagId = tagId;
        }
    }

    public static class OutputSlotInfo
    {
        public List<GenericStack> candidates;
        public String tagId;
        OutputSlotInfo(List<GenericStack> candidates, String tagId)
        {
            this.candidates = candidates;
            this.tagId = tagId;
        }
    }

    //从JEI槽位获取ItemStack
    public static ItemStack getItemStackFromSlot(IRecipeSlotView slot)
    {
        Optional<ITypedIngredient<?>> displayed = slot.getDisplayedIngredient();
        if (displayed.isPresent() && displayed.get().getIngredient() instanceof ItemStack)
        {
            return (ItemStack) displayed.get().getIngredient();
        }
        return ItemStack.EMPTY;
    }

    //从JEI槽位获取FluidStack
    public static FluidStack getFluidStackFromSlot(IRecipeSlotView slot)
    {
        Optional<ITypedIngredient<?>> displayed = slot.getDisplayedIngredient();
        if (displayed.isPresent() && displayed.get().getIngredient() instanceof FluidStack)
        {
            return (FluidStack) displayed.get().getIngredient();
        }
        return FluidStack.EMPTY;
    }

    public static CompoundTag itemStackToTag(ItemStack itemStack, boolean useRealCount)
    {
        CompoundTag tag = new CompoundTag();
        tag.putString("id", BuiltInRegistries.ITEM.getKey(itemStack.getItem()).toString());
        tag.putByte("Count", (byte) (useRealCount ? itemStack.getCount() : 1));
        if (itemStack.hasTag())
        {
            tag.put("tag", itemStack.getTag().copy());
        }
        return tag;
    }

    public static CompoundTag processingPatternGenericStackToTag(GenericStack genericStack)
    {
        CompoundTag slotTag = new CompoundTag();
        if (genericStack.what() instanceof AEItemKey)
        {
            ItemStack itemStack = genericStackToItemStack(genericStack);
            slotTag.putLong("#", itemStack.getCount());
            slotTag.putString("#c", "ae2:i");
            slotTag.putString("id", BuiltInRegistries.ITEM.getKey(itemStack.getItem()).toString());
            if (itemStack.hasTag())
            {
                slotTag.put("tag", itemStack.getTag().copy());
            }
        }
        else
            if (genericStack.what() instanceof AEFluidKey)
            {
                FluidStack fluidStack = genericStackToFluidStack(genericStack);
                slotTag.putLong("#", fluidStack.getAmount());
                slotTag.putString("#c", "ae2:f");
                slotTag.putString("id", BuiltInRegistries.FLUID.getKey(fluidStack.getFluid()).toString());
                if (fluidStack.hasTag())
                {
                    slotTag.put("tag", fluidStack.getTag().copy());
                }
            }
        return slotTag;
    }

    //标准化样板NBT
    public static CompoundTag normalizePattern(CompoundTag compoundTag)
    {
        //移除Slot字段
        compoundTag.remove("Slot");

        //如果是返回栏中的包装格式（包含 "#c" 和 "#"），转换为普通物品格式
        if (compoundTag.contains("#c") && compoundTag.contains("#"))
        {
            String id = compoundTag.getString("id");
            CompoundTag tag = compoundTag.contains("tag") ? compoundTag.getCompound("tag") : null;

            //创建新的CompoundTag
            CompoundTag normalized = new CompoundTag();
            normalized.putString("id", id);
            normalized.putByte("Count", (byte) 1);
            if (tag != null)
            {
                normalized.put("tag", tag);
            }
            compoundTag = normalized;
        }

        ensureCount(compoundTag);
        return compoundTag;
    }

    //校验数量
    public static void ensureCount(CompoundTag tag)
    {
        if (!tag.contains("Count") && !tag.isEmpty())
        {
            tag.putByte("Count", (byte) 1);
        }

        //处理内层tag
        if (tag.contains("tag", 10))
        {
            CompoundTag inner = tag.getCompound("tag");
            //处理切石机输入
            if (inner.contains("in", 9))
            {
                ListTag inList = inner.getList("in", 10);
                for (int i = 0; i < inList.size(); i++)
                {
                    CompoundTag in = inList.getCompound(i);
                    if (in.contains("id") && !in.contains("Count"))
                    {
                        in.putByte("Count", (byte) 1);
                    }
                }
            }
            else
                if (inner.contains("in", 10))
                {
                    CompoundTag in = inner.getCompound("in");
                    if (in.contains("id") && !in.contains("Count"))
                    {
                        in.putByte("Count", (byte) 1);
                    }
                }

            //处理锻造台输入
            if (inner.contains("template", 10))
            {
                CompoundTag template = inner.getCompound("template");
                if (template.contains("id") && !template.contains("Count"))
                {
                    template.putByte("Count", (byte) 1);
                }
            }

            if (inner.contains("base", 10))
            {
                CompoundTag base = inner.getCompound("base");
                if (base.contains("id") && !base.contains("Count"))
                {
                    base.putByte("Count", (byte) 1);
                }
            }

            if (inner.contains("addition", 10))
            {
                CompoundTag addition = inner.getCompound("addition");
                if (addition.contains("id") && !addition.contains("Count"))
                {
                    addition.putByte("Count", (byte) 1);
                }
            }

            //处理输出
            if (inner.contains("out", 10))
            {
                CompoundTag out = inner.getCompound("out");
                if (out.contains("id") && !out.contains("Count"))
                {
                    out.putByte("Count", (byte) 1);
                }
            }
            else
                if (inner.contains("out", 9))
                {
                    ListTag outList = inner.getList("out", 10);
                    for (int i = 0; i < outList.size(); i++)
                    {
                        CompoundTag out = outList.getCompound(i);
                        if (out.contains("id") && !out.contains("Count"))
                        {
                            out.putByte("Count", (byte) 1);
                        }
                    }
                }
        }
    }

    //递归提取所有patterns和returnInv中的样板
    public static List<CompoundTag> extractPatternsFromNBT(CompoundTag root)
    {
        List<CompoundTag> patterns = new ArrayList<>();
        collectPatterns(root, patterns);
        return patterns;
    }

    //获取样板内容
    public static void collectPatterns(CompoundTag tag, List<CompoundTag> out)
    {
        //检查当前tag是否为样板
        if (tag.contains("id", Tag.TAG_STRING))
        {
            String id = tag.getString("id");
            if (id.equals("ae2:crafting_pattern") || id.equals("ae2:processing_pattern") || id.equals("ae2:smithing_table_pattern") || id.equals("ae2:stonecutting_pattern"))
            {
                out.add(tag.copy()); //复制样板NBT
            }
        }
        //递归遍历所有子 CompoundTag 和 ListTag
        for (String key : tag.getAllKeys())
        {
            Tag subTag = tag.get(key);
            if (subTag instanceof CompoundTag)
            {
                collectPatterns((CompoundTag) subTag, out);
            }
            else
            if (subTag instanceof ListTag)
            {
                ListTag list = (ListTag) subTag;
                for (int i = 0; i < list.size(); i++)
                {
                    Tag element = list.get(i);
                    if (element instanceof CompoundTag)
                    {
                        collectPatterns((CompoundTag) element, out);
                    }
                }
            }
        }
    }

    //读取blockEntity中的NBT
    public static List<CompoundTag> readNBTFromBlockEntity(BlockEntity blockEntity)
    {
        if (blockEntity == null)
        {
            Minecraft.getInstance().player.displayClientMessage(Component.translatable("无法获取方块实体"), false);
            return null;
        }

        List<CompoundTag> patternTags = extractPatternsFromNBT(blockEntity.saveWithoutMetadata());
        List<CompoundTag> normalizedTags = new ArrayList<>();

        for (CompoundTag tag : patternTags)
        {
            CompoundTag normalized = normalizePattern(tag);
            normalizedTags.add(normalized);
        }
        return normalizedTags;
    }

    //读取线缆组件中的NBT
    public static List<CompoundTag> readNBTFromPart(PatternProviderPart part)
    {
        CompoundTag partNbt = new CompoundTag();
        part.writeToNBT(partNbt);
        List<CompoundTag> patternTags = extractPatternsFromNBT(partNbt);
        List<CompoundTag> normalizedTags = new ArrayList<>();
        for (CompoundTag tag : patternTags)
        {
            normalizedTags.add(normalizePattern(tag));
        }
        return normalizedTags;
    }
}
