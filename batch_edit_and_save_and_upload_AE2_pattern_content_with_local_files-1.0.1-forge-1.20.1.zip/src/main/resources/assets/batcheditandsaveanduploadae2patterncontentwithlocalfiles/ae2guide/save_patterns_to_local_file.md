---
navigation:
  parent: index.md
  title: 样板保存至本地NBT文件
  icon: ae2:pattern_provider
  position: 0
---

# 样板保存至本地NBT文件

在样板供应器及其子类的 Screen中，通过 Mixin 添加了“保存样板内容”的按钮，点击后可以直接把样板供应器中所有的样板内容保存至 JEI 批量编写界面的样板内容缓存。

![样板供应器Mixin](pictures/pattern_provider_mixin.png)
考虑到AE2附属模组中也会有样板供应器，本模组在 PatternProviderScreen 及其子类中都会添加这个按钮，但是 AE2 附属模组的样板供应器的 Screen 未必继承 PatternProviderScreen，导致有些模组的样板供应器界面不会显示这个按钮。

为了解决这个问题,可以使用 /savepatternproviderpatterncontent 直接读取面前选中的 blockentity 的 NBT，解析其中所包含的样板数据，并写入 JEI 批量编写界面左侧的样板内容缓存（无论是不是样板供应器，就算是个放了样板的箱子也能正确读取样板内容并写入缓存）。

从左到右依次是：样板内容缓存、更高显示密度的 JEI、本地样板预览。
![根据JEI编写样板内容界面](pictures/get_pattern_content_from_jei.png)

右侧可以预览本地的样板文件的内容（右下角可以新建样板文件，右上角可以打开样板文件所在文件夹,可以靠鼠标滚轮滑动选择预览的文件），左键点击样板内容缓存中的配方可以将此配方写入本地文件并删除此缓存，中间点击写入本地文件但不删除，右键点击删除，左下角有批量处理的按钮，右上角显示样板内容预览，右下角显示虚拟样板槽位（像把样板放在样板供应器/样板管理终端中一样，显示样板的主产物）。

这些文件是保存在本地的，路径为"游戏文件夹/ae2_pattern_content_nbt/"
![本地文件保存](pictures/save_to_local_files.png)
