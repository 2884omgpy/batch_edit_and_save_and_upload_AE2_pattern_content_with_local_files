---
navigation:
  parent: index.md
  title: 编辑本地NBT文件包含的样板内容
  icon: ae2:processing_pattern
  position: 3
---

# 编辑本地NBT文件包含的样板内容

中键点击 JEI 批量编写界面右下角虚拟样板槽位或任意键点击右上角本地样板内容预览区域可进入样板内容编辑界面，左侧是样板NBT预览，右侧是JEI物品列表。
![样板内容编辑器](pictures/pattern_content_editor.png)
可以像样板编码终端一样编辑样板内容。

在本地样板编辑界面中，左侧是样板 NBT 内容预览区域，右侧是重新实现的 JEI 物品列表（显示区域更大），中间是样板内容预览/编辑区域，对样板的操作和样板编码终端中的操作逻辑相同，可以点击左下角按钮直接编辑样板 NBT，编辑好后可以保存到本地。
![NBT编辑器](pictures/nbt_editor.png)
