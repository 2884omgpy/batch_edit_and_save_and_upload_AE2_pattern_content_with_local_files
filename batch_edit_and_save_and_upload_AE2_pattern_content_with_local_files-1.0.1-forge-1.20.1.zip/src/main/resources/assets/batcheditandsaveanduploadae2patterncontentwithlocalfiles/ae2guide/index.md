---
navigation:
  title: 批量编辑,保存到本地,模拟玩家编写AE2样板
  position: 0
---

# 批量编辑,保存到本地,模拟玩家编写AE2样板

欢迎使用“批量编辑,保存到本地,模拟玩家编写AE2样板”，本模组是一个客户端模组，提供样板保存至本地NBT文件，在样板编码终端中根据本地NBT文件的样板内容模拟玩家自动编写样板，根据JEI配方生成样板NBT文件并保存到本地，编辑本地NBT文件包含的样板内容。

![批量编辑,保存到本地,模拟玩家编写AE2样板](pictures/logo.png)

* [样板保存至本地NBT文件](save_patterns_to_local_file.md)
* [在样板编码终端中根据本地NBT文件的样板内容模拟玩家自动编写样板](auto_encode_pattern_from_local_file.md)
* [根据JEI配方生成样板NBT文件并保存到本地](get_pattern_content_from_jei.md)
* [编辑本地NBT文件包含的样板内容](edit_pattern_content.md)
