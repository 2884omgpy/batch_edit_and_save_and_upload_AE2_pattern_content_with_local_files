---
navigation:
  parent: index.md
  title: 在样板编码终端中根据本地NBT文件的样板内容模拟玩家自动编写样板
  icon: ae2:pattern_encoding_terminal
  position: 1
---

# 在样板编码终端中根据本地NBT文件的样板内容模拟玩家自动编写样板

在样板编码终端中，通过 Mixin 添加了“批量上传样板”的按钮，点击后进入文件样板内容预览界面，左上角可打开样板文件所在文件夹和通过鼠标滚轮选择文件，虚拟槽位中显示本地样板的主产物,点击“确认”开始模拟玩家行为编码样板，将使用空白样板编写选择的文件中的所有样板。其中，编写每个非切石机样板需要 4tick，编写切石机样板需要 5tick。

![样板编码终端Mixin](pictures/pattern_encoding_terminal_mixin.png)
![上传内容选择](pictures/upload_pattern_content_select.png)
