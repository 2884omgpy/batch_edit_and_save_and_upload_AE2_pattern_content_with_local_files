package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.network.OpenScreenWithPatternsPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID)
public class BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles
{
    public static final String MOD_ID = "batcheditandsaveanduploadae2patterncontentwithlocalfiles";
    public static BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles INSTANCE;


    public BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles(FMLJavaModLoadingContext context)
    {
        INSTANCE = this;
        IEventBus modEventBus = context.getModEventBus();

        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
        context.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    //在这里输入通用设置代码
    private void commonSetup(final FMLCommonSetupEvent event)
    {
        registerPackets();
    }

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(ResourceLocation.fromNamespaceAndPath(MOD_ID, "main"), () -> "1", s -> true, s -> true);
    public static void registerPackets()
    {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenScreenWithPatternsPacket.class, OpenScreenWithPatternsPacket::encode, OpenScreenWithPatternsPacket::decode, OpenScreenWithPatternsPacket::handle);
    }
}
