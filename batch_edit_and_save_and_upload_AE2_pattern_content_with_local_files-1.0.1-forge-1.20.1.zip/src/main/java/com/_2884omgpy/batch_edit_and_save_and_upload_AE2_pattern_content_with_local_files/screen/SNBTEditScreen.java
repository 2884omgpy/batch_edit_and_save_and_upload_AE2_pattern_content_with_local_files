package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.GUIBackgroundRendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.MultilineTextBox;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;

public class SNBTEditScreen extends Screen
{
    private final CompoundTag patternTag;
    private final Screen previousScreen;
    private MultilineTextBox textBox;
    private String errorMessage = "";

    public SNBTEditScreen(CompoundTag tag, Screen previousScreen)
    {
        super(Component.translatable("编辑 SNBT"));
        this.patternTag = tag;
        this.previousScreen = previousScreen;
    }

    @Override
    protected void init()
    {
        super.init();

        MultilineTextBox.scrollOffset = 0;
        //创建多行文本框，占满屏幕大部分区域
        textBox = new MultilineTextBox(font, 5, 5, width - 10, height - 30);
        textBox.setText(patternTag.getAsString()); // 初始化文本

        createButton();
    }

    private void createButton()
    {
        //保存按钮
        Button saveButton = Button.builder(Component.translatable("保存"), button ->
        {
            try
            {
                String snbt = textBox.getText();
                CompoundTag newTag = TagParser.parseTag(snbt); // 解析 SNBT
                //通过回调更新原屏幕
                if (previousScreen instanceof PatternContentEditScreen)
                {
                    ((PatternContentEditScreen) previousScreen).updatePatternTag(newTag);
                }
                onClose();
            }
            catch (Exception e)
            {
                errorMessage = "解析错误: " + e.getMessage();
            }
        }).pos(4, height - 24).size(width / 2 - 5, 20).build();

        Button cancelButton = Button.builder(Component.translatable("取消"), button ->
        {
            onClose();
        }).pos(width / 2 + 1, height - 24).size(width / 2 - 5, 20).build();

        addRenderableWidget(saveButton);
        addRenderableWidget(cancelButton);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        renderBackground(guiGraphics);
        //绘制背景
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, 0, 0, width, height);
        GUIBackgroundRendHelper.rendSNBTEditScreen(guiGraphics, 5, 5, width - 10, height - 30);
        textBox.render(guiGraphics, mouseX, mouseY, partialTick);
        if (!errorMessage.isEmpty())
        {
            guiGraphics.drawString(font, errorMessage, 6, height - 34, 0xFF0000);
        }
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        textBox.mouseClicked(mouseX, mouseY, button);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY)
    {
        if (textBox != null)
        {
            textBox.mouseDragged(mouseX, mouseY, button, dragX, dragY);
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button)
    {
        if (textBox != null)
        {
            textBox.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        if(MultilineTextBox.linesPerPage < MultilineTextBox.linesCount)
        {
            if (delta > 0)
            {
                if (MultilineTextBox.scrollOffset > 0)
                {
                    MultilineTextBox.scrollOffset--;
                }
            }
            else
                if (delta < 0)
                {
                    if (MultilineTextBox.scrollOffset < MultilineTextBox.linesCount - MultilineTextBox.linesPerPage)
                    {
                        MultilineTextBox.scrollOffset++;
                    }
                }
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        textBox.keyPressed(keyCode, scanCode, modifiers);
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        textBox.charTyped(codePoint, modifiers);
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }

    @Override
    public void onClose()
    {
        minecraft.setScreen(previousScreen);
    }
}