package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import appeng.api.stacks.GenericStack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.GUIBackgroundRendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.RendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.init.ModJEIPlugin;
import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PatternContentAddFromJEIScreen extends Screen
{
    public static final int LEFT_AND_RIGHT_GUI_WIDTH = 132;
    public static int GUI_HEIGHT = 240;
    public static int CENTER_GUI_WIDTH = 216;

    public static int LEFT_GUI_START_X = 0;
    public static int LEFT_GUI_START_Y = 0;

    public static int CENTER_GUI_START_X = 0;
    public static int CENTER_GUI_START_Y = 0;

    public static int RIGHT_GUI_START_X = 0;
    public static int RIGHT_GUI_START_Y = 0;

    public static final ResourceLocation PREV_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/prev_button_hover.png");
    public static final ResourceLocation NEXT_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/next_button_hover.png");
    public static final ResourceLocation OPEN_FOLDER_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/open_folder_button_hover.png");

    private static final int SMALL_BUTTON_WIDTH = 13;
    private static final int SMALL_BUTTON_HEIGHT = 13;

    private static final int PREV_BUTTON_AREA_START_X_1 = 6;
    private static final int PREV_BUTTON_AREA_START_Y_1 = 4;

    private static int NEXT_BUTTON_AREA_START_X_1 = CENTER_GUI_WIDTH - 19;
    private static final int NEXT_BUTTON_AREA_START_Y_1 = 4;

    private static final int PREV_BUTTON_AREA_START_X_2 = 6;
    private static final int PREV_BUTTON_AREA_START_Y_2 = 19;

    private static int NEXT_BUTTON_AREA_START_X_2 = CENTER_GUI_WIDTH - 19;
    private static final int NEXT_BUTTON_AREA_START_Y_2 = 19;

    private static final int OPEN_FOLDER_BUTTON_AREA_START_X = 4;
    private static final int OPEN_FOLDER_BUTTON_AREA_START_Y = 5;

    private static final int WHEEL_AREA_START_X_JEI_PART = 0;
    private static final int WHEEL_AREA_START_Y_JEI_PART = 0;

    private static final int AE2_PATTERN_PANEL_START_X_IN_RIGHT_SCREEN = 3;
    private static final int AE2_PATTERN_PANEL_START_Y_IN_RIGHT_SCREEN = 20;

    private static final int AE2_PATTERN_PANEL_WIDTH = 126;
    private static final int AE2_PATTERN_PANEL_HEIGHT = 68;

    private Screen previousScreen;

    //JEI内容浏览相关
    private List<IRecipeCategory<?>> categories;
    private IRecipeCategory<?> currentCategory;
    private List<?> currentRecipes;
    private int categoryIndex = 0;
    private int recipePage = 0;
    private int JEIRecipeNameLength = 0;
    private int lastRecipeStartIndex = 0;

    //JEI每行，每列，每页显示的配方数量默认值
    private int JEIRecipeWidth = 0;
    private int JEIRecipeHeight = 0;
    private int JEIRecipesPerRow = 1;
    private int JEIRecipesPerColumn = 1;
    private int JEIRecipesPerPage = 1;

    //右侧GUI文件预览相关
    private List<Path> fileList = new ArrayList<>();
    private int selectedFileIndex = -1;
    private List<CompoundTag> currentFilePatterns = new ArrayList<>();
    private int now_preview_pattern_index = 0; //当前预览的样板索引
    private int filePreviewScrollOffset = 0; // 当前滚动偏移（起始索引）
    private boolean loadingFile = false;
    private EditBox fileNameInput;
    private boolean is_show_EditBox_file_name = false;

    //布局常量
    private static final int FILE_SELECTOR_WIDTH = 109;
    private static final int FILE_SELECTOR_HEIGHT = 15;

    private static final int SLOT_COLS = 7;
    private static int SLOT_ROWS = 1;

    //左侧样板列表缓存相关
    private List<CompoundTag> leftBufferPatterns = new ArrayList<>();
    private int left_GUI_start_panel_index = 0;
    private int pattern_content_buffer_show_panel_count = 1;

    //记录每个配方的布局对象和绘制区域，用于事件转发
    private final List<RecipeLayoutInfo> recipeLayouts = new ArrayList<>();

    public PatternContentAddFromJEIScreen(int fileIndex, int patternIndex, CompoundTag patternTag, List<CompoundTag> externalBuffer, Screen previousScreen)
    {
        super(Component.translatable("样板内容编辑器"));

        if (fileIndex >= 0 && fileIndex < fileList.size())
        {
            selectedFileIndex = fileIndex;
        }
            else
            {
                selectedFileIndex = 0;
            }

        if (patternIndex >= 0 && patternIndex < currentFilePatterns.size())
        {
            if (patternTag != null)
            {
                currentFilePatterns.set(patternIndex, patternTag);
                saveNBTFileToDisk(); //保存到文件
            }
            now_preview_pattern_index = patternIndex;
        }
            else
            {
                now_preview_pattern_index = 0;
            }

        if (externalBuffer != null)
        {
            leftBufferPatterns.addAll(externalBuffer);
        }

        if (previousScreen != null)
        {
            this.previousScreen = previousScreen;
        }
    }

    public PatternContentAddFromJEIScreen(int fileIndex, int patternIndex, CompoundTag patternTag)
    {
        this(fileIndex, patternIndex, patternTag, null, null);
    }

    public PatternContentAddFromJEIScreen(List<CompoundTag> externalBuffer, Screen previousScreen)
    {
        this(0, 0, null, externalBuffer, previousScreen);
    }

    public PatternContentAddFromJEIScreen(List<CompoundTag> externalBuffer)
    {
        this(0, 0, null, externalBuffer, null);
    }

    public PatternContentAddFromJEIScreen(Screen previousScreen)
    {
        this(0, 0, null, null, previousScreen);
    }

    public PatternContentAddFromJEIScreen()
    {
        this(0, 0, null, null, null);
    }

    @Override
    protected void init()
    {
        super.init();

        //GUI大小重新计算
        CENTER_GUI_WIDTH = width - 2 * LEFT_AND_RIGHT_GUI_WIDTH;
        GUI_HEIGHT = height;

        //GUI起始位置重新计算
        CENTER_GUI_START_X = (width - CENTER_GUI_WIDTH) / 2;

        RIGHT_GUI_START_X = width - LEFT_AND_RIGHT_GUI_WIDTH;

        NEXT_BUTTON_AREA_START_X_1 = CENTER_GUI_WIDTH - 19;
        NEXT_BUTTON_AREA_START_X_2 = CENTER_GUI_WIDTH - 19;

        SLOT_ROWS = 1 + (GUI_HEIGHT - 132) / 18;

        pattern_content_buffer_show_panel_count = Math.max(1, (height - 40) / 69);

        categories = ModJEIPlugin.getAllCategories();

        if (!categories.isEmpty())
        {
            //使用上次保存的配方类别
            setCategory(categoryIndex);

            //根据保存的起始索引计算当前页
            if (lastRecipeStartIndex >= 0 && lastRecipeStartIndex < currentRecipes.size())
            {
                recipePage = lastRecipeStartIndex / JEIRecipesPerPage;
            }
                else
                {
                    recipePage = 0;
                }
        }

        //复位处理样板显示页码
        RendHelper.PROCESSING_ENCODING_PANEL_PAGE = 0;

        refreshFileList();

        //添加按钮
        createButton();

        //添加输入框
        this.fileNameInput = new EditBox(this.font, RIGHT_GUI_START_X + 21, RIGHT_GUI_START_Y + 8, 108, 14, Component.literal(""));
        this.fileNameInput.setMaxLength(32768);
        this.fileNameInput.setBordered(false);      //不绘制边框
        this.fileNameInput.setTextColor(0xFFFFFF);
        this.fileNameInput.setValue("new_pattern"); //默认文件名
        this.fileNameInput.setVisible(false);
        addRenderableWidget(this.fileNameInput);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        renderBackground(guiGraphics);

        //绘制左侧纹理
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, LEFT_GUI_START_X, LEFT_GUI_START_Y, LEFT_AND_RIGHT_GUI_WIDTH, GUI_HEIGHT);

        //绘制中间纹理
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, CENTER_GUI_START_X, CENTER_GUI_START_Y, CENTER_GUI_WIDTH, GUI_HEIGHT);
        GUIBackgroundRendHelper.rendJEIRecipeNameBar(guiGraphics, CENTER_GUI_START_X + 6, CENTER_GUI_START_Y + 4, CENTER_GUI_WIDTH - 12);
        GUIBackgroundRendHelper.rendJEIRecipeNameBar(guiGraphics, CENTER_GUI_START_X + 6, CENTER_GUI_START_Y + 19, CENTER_GUI_WIDTH - 12);

        //绘制右侧纹理
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, RIGHT_GUI_START_X, RIGHT_GUI_START_Y, LEFT_AND_RIGHT_GUI_WIDTH, GUI_HEIGHT);
        GUIBackgroundRendHelper.rendFileNameSelectTextbox(guiGraphics, RIGHT_GUI_START_X + 4, RIGHT_GUI_START_Y + 4);
        GUIBackgroundRendHelper.rendErrorPatternPanelBackGround(guiGraphics, RIGHT_GUI_START_X + 3, RIGHT_GUI_START_Y + 20);
        for(int row = 0; row < (GUI_HEIGHT - 112) / 18; row++)
        {
            for(int col = 0; col < 7; col++)
            {
                GUIBackgroundRendHelper.rendSlot(guiGraphics, RIGHT_GUI_START_X + 3 + 18 * col, RIGHT_GUI_START_Y + 88 + 18 * row);
            }
        }

        //绘制JEI配方类型名
        renderCategorySelector(guiGraphics, CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2, CENTER_GUI_START_Y + 6);

        //绘制当前JEI配方类别的所有配方
        if (currentCategory != null)
        {
            renderJEIRecipes(guiGraphics, CENTER_GUI_WIDTH, GUI_HEIGHT, mouseX, mouseY);
        }

        for (RecipeLayoutInfo info : recipeLayouts)
        {
            if (mouseX >= info.x && mouseX <= info.x + info.width && mouseY >= info.y && mouseY <= info.y + info.height)
            {
                info.layout.drawOverlays(guiGraphics, mouseX, mouseY);
                break; // 只处理第一个悬浮的配方
            }
        }

        //渲染按钮文本提示
        rendButtonTooltips(guiGraphics, mouseX, mouseY);
        //渲染鼠标在按钮上的悬浮效果
        rendButtonHoverStatus(guiGraphics, mouseX, mouseY);

        //渲染右侧文件预览组件
        rendRightFileSelectorFileName(guiGraphics);
        rendRightPatternContentPreview(guiGraphics, RIGHT_GUI_START_X + 3, RIGHT_GUI_START_Y + 20, mouseX, mouseY);
        renderRightVirtualPatternSlotOutputItemAndTooltips(guiGraphics, mouseX, mouseY);

        //渲染左侧样板内容缓存
        rendLeftBufferPatternContentPreview(guiGraphics, mouseX, mouseY);

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    //显示不同配方类型
    private void setCategory(int categoryIndex)
    {
        this.categoryIndex = categoryIndex;
        currentCategory = categories.get(categoryIndex);
        currentRecipes = ModJEIPlugin.getRecipesForCategory(currentCategory);

        if (!currentRecipes.isEmpty())
        {
            //获取某种配方的第一个，用于获取其宽度和高度，用于计算一页能显示多少个这样的配方
            ModJEIPlugin.createRecipeLayout(currentCategory, currentRecipes.get(0), ModJEIPlugin.getEmptyFocusGroup()).ifPresent(layout ->
            {
                Rect2i rect = layout.getRect();
                JEIRecipeWidth = rect.getWidth() + 8;
                JEIRecipeHeight = rect.getHeight() + 8;

                //计算每页显示的配方行数，列数，以及总页码（至少为1）
                JEIRecipesPerRow = Math.max(1, (CENTER_GUI_WIDTH - 6) / JEIRecipeWidth);
                JEIRecipesPerColumn = Math.max(1, (GUI_HEIGHT - 35) / JEIRecipeHeight);
                JEIRecipesPerPage = JEIRecipesPerRow * JEIRecipesPerColumn;
            });
        }
            else
            {
                //无配方时设为默认值
                JEIRecipesPerRow = 1;
                JEIRecipesPerColumn = 1;
                JEIRecipesPerPage = 1;
            }
    }

    //显示配方类型
    private void renderCategorySelector(GuiGraphics guiGraphics, int x, int y)
    {
        if (categories.isEmpty())
        {
            return;
        }

        JEIRecipeNameLength = categories.get(categoryIndex).getTitle().getString().length();
        //配方类型名称
        guiGraphics.drawCenteredString(font, categories.get(categoryIndex).getTitle().getString(), x, y, 0xFFFFFF);
    }

    //显示配方内容
    private void renderJEIRecipes(GuiGraphics guiGraphics, int GUI_width, int GUI_height, int mouseX, int mouseY)
    {
        recipeLayouts.clear();

        int now_recipe_total_page = (int) Math.ceil((double) currentRecipes.size() / JEIRecipesPerPage);

        //当前页始末配方序列变化
        int start_recipe_index_in_now_page = recipePage * JEIRecipesPerPage;
        int end_recipe_index_in_now_page = Math.min(start_recipe_index_in_now_page + JEIRecipesPerPage, currentRecipes.size());

        //当前页面所有配方的总宽度/总高度
        int recipe_in_1_page_total_width = JEIRecipesPerRow * JEIRecipeWidth;
        int recipe_in_1_page_total_height = JEIRecipesPerColumn * JEIRecipeHeight;

        lastRecipeStartIndex = recipePage * JEIRecipesPerPage;

        for (int i = start_recipe_index_in_now_page; i < end_recipe_index_in_now_page; i++)
        {
            int row = (i - start_recipe_index_in_now_page) / JEIRecipesPerRow;
            int col = (i - start_recipe_index_in_now_page) % JEIRecipesPerRow;
            int recipe_draw_start_X = CENTER_GUI_START_X + 4 + (GUI_width - recipe_in_1_page_total_width) / 2 + col * JEIRecipeWidth;
            int recipe_draw_start_Y = CENTER_GUI_START_Y + 19 + (GUI_height - recipe_in_1_page_total_height) / 2 + row * JEIRecipeHeight;

            Object recipe = currentRecipes.get(i);
            var optional = ModJEIPlugin.createRecipeLayout(currentCategory, recipe, ModJEIPlugin.getJeiRuntime().getJeiHelpers().getFocusFactory().getEmptyFocusGroup());
            optional.ifPresent(layout ->
            {
                //设置布局的屏幕位置
                layout.setPosition(recipe_draw_start_X, recipe_draw_start_Y);

                //保存布局和绘制区域，用于事件转发
                recipeLayouts.add(new RecipeLayoutInfo(layout, recipe_draw_start_X, recipe_draw_start_Y, JEIRecipeWidth, JEIRecipeHeight));

                //显示配方
                layout.drawRecipe(guiGraphics, 0, 0);
            });
        }

        //显示配方类型页码和当前配方页码
        guiGraphics.drawCenteredString(font, (recipePage + 1) + "/" + now_recipe_total_page, CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2, CENTER_GUI_START_Y + 22, 0xFFFFFF);
        guiGraphics.drawCenteredString(font, (categoryIndex + 1) + "/" + categories.size(), CENTER_GUI_START_X + CENTER_GUI_WIDTH / 4, CENTER_GUI_START_Y + 7, 0xFFFFFF);

        //显示鼠标悬浮效果
        int JEI_recipe_start_x = CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2 - recipe_in_1_page_total_width / 2;
        int JEI_recipe_start_y = CENTER_GUI_START_Y + 15 + GUI_HEIGHT / 2 - recipe_in_1_page_total_height / 2;

        if (mouseX >= JEI_recipe_start_x && mouseX <= JEI_recipe_start_x + recipe_in_1_page_total_width - 1 && mouseY >= JEI_recipe_start_y && mouseY <= JEI_recipe_start_y + recipe_in_1_page_total_height - 1)
        {
            int row = (mouseX - JEI_recipe_start_x) / JEIRecipeWidth;
            int col = (mouseY - JEI_recipe_start_y) / JEIRecipeHeight;

            guiGraphics.fill(JEI_recipe_start_x + row * JEIRecipeWidth, JEI_recipe_start_y + col * JEIRecipeHeight, JEI_recipe_start_x + (row + 1) * JEIRecipeWidth, JEI_recipe_start_y + (col + 1) * JEIRecipeHeight, 0x7FFFFFFF);
        }
    }

    //添加按钮
    private void createButton()
    {
        Button delete_all_buffer_button = Button.builder(Component.translatable("删除所有缓存"),button ->
        {
            deleteAllBuffer();
        }).pos(4, GUI_HEIGHT - 45).size(60, 20).build();

        Button save_all_buffer_to_file_button = Button.builder(Component.translatable("写入本地文件"),button ->
        {
            saveAllBufferToFile();
        }).pos(68, GUI_HEIGHT - 45).size(60, 20).build();

        Button save_all_buffer_to_file_and_delete_all_buffer_button = Button.builder(Component.translatable("写入本地文件并删除缓存"),button ->
        {
            saveAllBufferToFile().thenRun(() ->
            {
                //写入完成后，在主线程清空缓存
                Minecraft.getInstance().execute(() ->
                {
                    deleteAllBuffer();
                });
            }).exceptionally(ex ->
            {
                //处理写入失败的情况
                System.err.println("保存失败: " + ex.getMessage());
                return null;
            });
        }).pos(4, GUI_HEIGHT - 24).size(124, 20).build();

        Button create_new_NBT_file_button = Button.builder(Component.translatable("创建新的NBT文件"),button ->
        {
            is_show_EditBox_file_name = true;
            fileNameInput.setVisible(true);
            fileNameInput.setValue("");     //清空之前输入
            fileNameInput.setFocused(true); //获得焦点
        }).pos(RIGHT_GUI_START_X + 4, GUI_HEIGHT - 24).size(124, 20).build();

        addRenderableWidget(delete_all_buffer_button);
        addRenderableWidget(save_all_buffer_to_file_button);
        addRenderableWidget(save_all_buffer_to_file_and_delete_all_buffer_button);
        addRenderableWidget(create_new_NBT_file_button);
    }

    //渲染按钮文本提示
    private void rendButtonTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (is_in_prev_button_1_area(mouseX, mouseY))
        {
            guiGraphics.renderTooltip(this.font, Component.translatable("上一页"), mouseX, mouseY);
        }
        else
            if (is_in_next_button_1_area(mouseX, mouseY))
            {
                guiGraphics.renderTooltip(this.font, Component.translatable("下一页"), mouseX, mouseY);
           }
            else
                if (is_in_prev_button_2_area(mouseX, mouseY))
                {
                    guiGraphics.renderTooltip(this.font, Component.translatable("上一页"), mouseX, mouseY);
                }
                else
                    if (is_in_next_button_2_area(mouseX, mouseY))
                    {
                        guiGraphics.renderTooltip(this.font, Component.translatable("下一页"), mouseX, mouseY);
                    }
                    else
                        if(is_in_open_folder_button_area(mouseX, mouseY))
                        {
                            guiGraphics.renderTooltip(this.font, Component.translatable("打开NBT文件夹"), mouseX, mouseY);
                        }
                        else
                            if(is_in_JEI_recipe_name_area(mouseX, mouseY))
                            {
                                guiGraphics.renderTooltip(this.font, Component.translatable("向缓存添加所有此配方类型的配方"), mouseX, mouseY);
                            }
    }

    private void rendButtonHoverStatus(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (is_in_prev_button_1_area(mouseX, mouseY))
        {
            guiGraphics.blit(PREV_BUTTON_HOVER, CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_1, CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_1, 0, 0, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT);
        }
        else
            if (is_in_next_button_1_area(mouseX, mouseY))
            {
                guiGraphics.blit(NEXT_BUTTON_HOVER, CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_1, CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_1, 0, 0, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT);
            }
            else
                if (is_in_prev_button_2_area(mouseX, mouseY))
                {
                    guiGraphics.blit(PREV_BUTTON_HOVER, CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_2, CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_2, 0, 0, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT);
                }
                else
                    if (is_in_next_button_2_area(mouseX, mouseY))
                    {
                        guiGraphics.blit(NEXT_BUTTON_HOVER, CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_2, CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_2, 0, 0, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT);
                    }
                    else
                        if(is_in_open_folder_button_area(mouseX, mouseY))
                        {
                            guiGraphics.blit(OPEN_FOLDER_BUTTON_HOVER, RIGHT_GUI_START_X + OPEN_FOLDER_BUTTON_AREA_START_X, RIGHT_GUI_START_Y + OPEN_FOLDER_BUTTON_AREA_START_Y, 0, 0, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT, SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT);
                        }
    }

    @Override
    public void tick()
    {
        super.tick();
        if (fileNameInput != null)
        {
            fileNameInput.tick();
        }
    }

    //鼠标点击
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        int now_recipe_total_page = (int) Math.ceil((double) currentRecipes.size() / JEIRecipesPerPage);

        if (is_in_prev_button_1_area((int)mouseX, (int)mouseY))
        {
            //上一个配方
            if (categoryIndex > 0)
            {
                setCategory(categoryIndex - 1);
            }
                else
                {
                    setCategory(categories.size() - 1);
                }
            recipePage = 0;
            playButtonClickSound();
            return true;
        }
        else
            if (is_in_next_button_1_area((int)mouseX, (int)mouseY))
            {
                //下一个配方
                if (categoryIndex < categories.size() - 1)
                {
                    setCategory(categoryIndex + 1);
                }
                    else
                    {
                        setCategory(0);
                    }
                recipePage = 0;
                playButtonClickSound();
                return true;
            }
            else
                if (is_in_prev_button_2_area((int)mouseX, (int)mouseY))
                {
                    //上一页
                    if (recipePage > 0)
                    {
                        recipePage--;
                    }
                        else
                        {
                            recipePage = now_recipe_total_page - 1;
                        }
                    playButtonClickSound();
                    return true;
                }
                else
                    if (is_in_next_button_2_area((int)mouseX, (int)mouseY))
                    {
                        //下一页
                        if (recipePage < now_recipe_total_page - 1)
                        {
                            recipePage++;
                        }
                            else
                            {
                                recipePage = 0;
                            }
                        playButtonClickSound();
                        return true;
                    }
                    else
                        if(is_in_open_folder_button_area((int)mouseX, (int)mouseY))
                        {
                            //打开本地存放AE2样板NBT文件的文件夹（<游戏文件夹>/ae2_pattern_content_nbt）
                            Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("ae2_pattern_content_nbt");
                            try
                            {
                                Util.getPlatform().openUri(dir.toFile().toURI());
                            }
                                catch (Exception e)
                                {
                                    System.err.println("无法打开<游戏文件夹>/ae2_pattern_content_nbt");
                                }

                            playButtonClickSound();
                            return true;
                        }
                        else
                            if(is_in_file_name_input_area((int)mouseX,(int)mouseY))
                            {
                                if(is_show_EditBox_file_name && fileNameInput.isFocused())
                                {
                                    createNewNBTFile();
                                    return true;
                                }
                            }

        //处理虚拟格子点击
        if (is_in_file_pattern_content_virtual_slot((int)mouseX, (int)mouseY))
        {
            int col = ((int)mouseX - RIGHT_GUI_START_X - 3) / 18;
            int row = ((int)mouseY - RIGHT_GUI_START_Y - 88) / 18;
            int index = filePreviewScrollOffset * 7 + row * SLOT_COLS + col;
            if (index >= 0 && index < currentFilePatterns.size())
            {
                //左键：选中并预览当前样板内容
                if (button == 0)
                {
                    now_preview_pattern_index = index;
                    return true;
                }
                else//右键：删除点击的样板
                    if (button == 1)
                    {
                        currentFilePatterns.remove(index);
                        //防止因为删除导致访问index超出范围
                        if (now_preview_pattern_index >= currentFilePatterns.size())
                        {
                            now_preview_pattern_index = currentFilePatterns.size() - 1;
                        }

                        if(currentFilePatterns.size() >= SLOT_ROWS * SLOT_COLS && filePreviewScrollOffset > ((currentFilePatterns.size() - 1)/ 7 + 1 - SLOT_ROWS))
                        {
                            filePreviewScrollOffset--;
                        }

                        //如果列表为空，预览索引设为0
                        if (currentFilePatterns.isEmpty())
                        {
                            now_preview_pattern_index = 0;
                        }
                        //保存文件
                        saveNBTFileToDisk();
                    }
                    else//中键：打开样板编辑界面
                        if (button == 2)
                        {
                            Minecraft.getInstance().setScreen(new PatternContentEditScreen(selectedFileIndex, index, currentFilePatterns.get(index), this));
                            return true;
                        }
            }
        }
        else//点击右侧样板内容预览区域（任意按键）打开样板编辑界面
            if (is_in_right_screen_pattern_content_preview_area((int)mouseX, (int)mouseY))
            {
                if (now_preview_pattern_index >= 0 && now_preview_pattern_index < currentFilePatterns.size())
                {
                    Minecraft.getInstance().setScreen(new PatternContentEditScreen(selectedFileIndex, now_preview_pattern_index, currentFilePatterns.get(now_preview_pattern_index), this));
                }
                return true;
            }

        //处理JEI配方选择
        if (is_in_JEI_area((int)mouseX, (int)mouseY))
        {
            int startX = CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2 - JEIRecipeWidth * JEIRecipesPerRow / 2;
            int startY = CENTER_GUI_START_Y + GUI_HEIGHT / 2 + 15 - JEIRecipeHeight * JEIRecipesPerColumn / 2;

            if (mouseX >= startX && mouseX <= startX + JEIRecipesPerRow * JEIRecipeWidth && mouseY >= startY && mouseY <= startY + JEIRecipesPerColumn * JEIRecipeHeight)
            {
                int row = ((int)mouseY - startY) / JEIRecipeHeight;
                int col = ((int)mouseX - startX) / JEIRecipeWidth;
                //当前页的配方引索
                int pageIndex = row * JEIRecipesPerRow + col;

                if (pageIndex >= recipeLayouts.size())
                {
                    return true;
                }

                //左键
                if (button == 0)
                {
                    CompoundTag patternNBT = PatternContentHelper.JeiRecipeToPatternNBT(currentCategory, recipeLayouts.get(pageIndex).layout.getRecipe(), recipeLayouts.get(pageIndex).layout);
                    leftBufferPatterns.add(patternNBT);
                    //自动滚动到最新项
                    left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
                    playButtonClickSound();
                    return true;
                }
                else//右键
                    if (button == 1)
                    {
                        List<PatternContentHelper.InputSlotInfo> inputSlotInfos = PatternContentHelper.collectInputSlotInfos(recipeLayouts.get(pageIndex).layout);
                        List<PatternContentHelper.OutputSlotInfo> outputSlotInfos = PatternContentHelper.collectOutputSlotInfos(recipeLayouts.get(pageIndex).layout);

                        Minecraft.getInstance().setScreen(new InputSelectScreen(inputSlotInfos, outputSlotInfos, PatternContentHelper.getPatternTypeFromCategory(currentCategory), recipeLayouts.get(pageIndex).layout.getRecipe(), (finalNBT) ->
                        {
                            leftBufferPatterns.add(finalNBT);
                            left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
                            playButtonClickSound();
                        }, this));
                        return true;
                    }
                    else//中键
                        if (button == 2)
                        {
                            Minecraft.getInstance().setScreen(new PatternContentEditScreen(PatternContentHelper.JeiRecipeToPatternNBT(currentCategory, recipeLayouts.get(pageIndex).layout.getRecipe(), recipeLayouts.get(pageIndex).layout, "minecraft:processing"), this));
                            return true;
                        }
            }
        }
        else
            if(is_in_JEI_recipe_name_area((int)mouseX, (int)mouseY))
            {
                if (currentCategory == null || currentRecipes.isEmpty())
                {
                    return true; // 无配方，直接返回
                }

                int addedCount = 0;
                for (Object recipe : currentRecipes)
                {
                    //为所有JEI配方类型创建布局
                    var optional = ModJEIPlugin.createRecipeLayout(currentCategory, recipe, ModJEIPlugin.getEmptyFocusGroup());
                    if (optional.isPresent())
                    {
                        IRecipeLayoutDrawable<?> layout = optional.get();
                        CompoundTag patternNBT = PatternContentHelper.JeiRecipeToPatternNBT(currentCategory, layout.getRecipe(), layout);
                        leftBufferPatterns.add(patternNBT);
                        addedCount++;
                        //自动滚动到最新项
                        left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);

                    }
                }

                if (addedCount > 0)
                {
                    //自动滚动到最新项
                    left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
                    playButtonClickSound();
                }
                return true;
            }

        if (is_in_left_GUI_area((int)mouseX, (int)mouseY))
        {
            if (mouseX >= 3 && mouseX <= AE2_PATTERN_PANEL_WIDTH - 3 && mouseY >= 3 && mouseY <= GUI_HEIGHT - 48)
            {
                int clickedRow = ((int)mouseY - (LEFT_GUI_START_Y + 20)) / AE2_PATTERN_PANEL_HEIGHT;
                int clickedIndex = left_GUI_start_panel_index + clickedRow;
                if (clickedIndex >= 0 && clickedIndex < leftBufferPatterns.size())
                {
                    CompoundTag pattern = leftBufferPatterns.get(clickedIndex);

                    //左键：添加该buffer到文件并删除buffer
                    if (button == 0)
                    {
                        addBufferToFile(pattern);
                        leftBufferPatterns.remove(clickedIndex);
                        //确保不超出屏幕范围
                        if (left_GUI_start_panel_index >= leftBufferPatterns.size() - pattern_content_buffer_show_panel_count + 1)
                        {
                            left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
                        }
                    }
                    else//右键：删除该buffer
                        if (button == 1)
                        {
                            leftBufferPatterns.remove(clickedIndex);
                            if (left_GUI_start_panel_index >= leftBufferPatterns.size() - pattern_content_buffer_show_panel_count + 1)
                            {
                                left_GUI_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
                            }
                        }
                        else//中键：添加该buffer至文件
                            if (button == 2)
                            {
                                addBufferToFile(pattern);
                            }
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    //鼠标滚轮操作
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        int now_recipe_total_page = (int) Math.ceil((double) currentRecipes.size() / JEIRecipesPerPage);

        if (is_in_jei_part_wheel_area((int)mouseX, (int)mouseY))
        {
            if (delta > 0)
            {
                if (recipePage > 0)
                {
                    recipePage--;
                }
                    else
                    {
                        recipePage = now_recipe_total_page - 1;
                    }
            }
            else
                if (delta < 0)
                {
                    if (recipePage < now_recipe_total_page - 1)
                    {
                        recipePage++;
                    }
                        else
                        {
                            recipePage = 0;
                        }
                }
            return true;
        }

        if (is_in_right_screen_pattern_content_preview_area((int)mouseX, (int)mouseY))
        {
            if (delta > 0)
            {
                if (RendHelper.PROCESSING_ENCODING_PANEL_PAGE > 0)
                {
                    RendHelper.PROCESSING_ENCODING_PANEL_PAGE--;
                }
            }
            else
                if (delta < 0)
                {
                    if (RendHelper.PROCESSING_ENCODING_PANEL_PAGE < 8)
                    {
                        RendHelper.PROCESSING_ENCODING_PANEL_PAGE++;
                    }
                }
        }

        //文件预览界面文件选择
        if (is_in_file_name_input_area((int)mouseX, (int)mouseY))
        {
            if (fileList.isEmpty())
            {
                return true;
            }

            int newIndex = selectedFileIndex + (delta > 0 ? -1 : 1);

            if (newIndex < 0)
            {
                newIndex = fileList.size() - 1;
            }

            if (newIndex >= fileList.size())
            {
                newIndex = 0;
            }

            if (selectedFileIndex != newIndex)
            {
                selectedFileIndex = newIndex;
                loadFileContent(newIndex);
                now_preview_pattern_index = 0;
                filePreviewScrollOffset = 0;
            }
            return true;
        }

        //虚拟样板槽位滚动
        if (is_in_file_pattern_content_virtual_slot((int)mouseX, (int)mouseY))
        {
            {
                int maxOffset = Math.max(0, currentFilePatterns.size() - SLOT_ROWS * SLOT_COLS);
                //向上滚动
                if (delta > 0)
                {
                    if (filePreviewScrollOffset > 0)
                    {
                        filePreviewScrollOffset--;
                    }
                }
                else//向下滚动
                    if (delta < 0)
                    {
                        if (filePreviewScrollOffset * 7 < maxOffset)
                        {
                            filePreviewScrollOffset++;
                        }
                    }
                return true;
            }
        }

        //左侧列表滚动
        if (is_in_left_GUI_area((int)mouseX, (int)mouseY))
        {
            int left_GUI_last_page_start_panel_index = Math.max(0, leftBufferPatterns.size() - pattern_content_buffer_show_panel_count);
            if(delta > 0)
            {
                if(left_GUI_start_panel_index > 0)
                {
                    left_GUI_start_panel_index--;
                }
            }

            else
                if(delta < 0)
                {
                    if(left_GUI_start_panel_index < left_GUI_last_page_start_panel_index)
                    {
                        left_GUI_start_panel_index++;
                    }
                }

            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    //嵌入式JEI的存储布局和绘制位置
    private static class RecipeLayoutInfo
    {
        final IRecipeLayoutDrawable<?> layout;
        final int x, y, width, height;
        RecipeLayoutInfo(IRecipeLayoutDrawable<?> layout, int x, int y, int width, int height)
        {
            this.layout = layout; this.x = x; this.y = y; this.width = width; this.height = height;
        }
    }

    //键盘操作
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        if (is_show_EditBox_file_name && fileNameInput.isFocused())
        {
            //Enter键值（包括小键盘）
            if (keyCode == 257 || keyCode == 335)
            {
                createNewNBTFile();
                return true;
            }
            return fileNameInput.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        if (is_show_EditBox_file_name && fileNameInput.isFocused())
        {
            return fileNameInput.charTyped(codePoint, modifiers);
        }
        return super.charTyped(codePoint, modifiers);
    }

    //打开此屏幕时不暂停游戏
    @Override
    public boolean isPauseScreen()
    {
        return false;
    }

    @Override
    public void onClose()
    {
        if (previousScreen != null)
        {
            Minecraft.getInstance().setScreen(previousScreen);
        }
            else
            {
                super.onClose();
            }
    }

    //播放按钮点击声音
    private void playButtonClickSound()
    {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    //重置文件列表
    private void refreshFileList()
    {
        Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("ae2_pattern_content_nbt");
        if (!Files.exists(dir))
        {
            try
            {
                Files.createDirectories(dir);
            }
                catch (IOException e)
                {
                    System.err.println("无法刷新文件列表：" + e);
                }
        }

        try (Stream<Path> stream = Files.list(dir))
        {
            fileList = stream.filter(p -> p.toString().endsWith(".ae2_pattern_content_nbt")).sorted(Comparator.comparing(Path::getFileName)).collect(Collectors.toList());
        }
            catch (IOException e)
            {
                System.err.println("找不到文件：：" + e);
            }

        //重置选中
        if (!fileList.isEmpty())
        {
            loadFileContent(selectedFileIndex);
        }
            else
            {
                selectedFileIndex = -1;
                currentFilePatterns.clear();
                now_preview_pattern_index = 0;
            }
    }

    //加载文件内容
    private void loadFileContent(int index)
    {
        if (index < 0 || index >= fileList.size())
        {
            return;
        }

        Path file = fileList.get(index);
        loadingFile = true;
        CompletableFuture.supplyAsync(() ->
        {
            try
            {
                //读取文件（假设文件内容是一个 CompoundTag，包含"patterns"列表）
                CompoundTag root = NbtIo.read(file.toFile());
                if (root != null && root.contains("patterns", Tag.TAG_LIST))
                {
                    ListTag list = root.getList("patterns", Tag.TAG_COMPOUND);
                    List<CompoundTag> patterns = new ArrayList<>();
                    for (int i = 0; i < list.size(); i++)
                    {
                        patterns.add(list.getCompound(i));
                    }
                    return patterns;
                }
            }
                catch (IOException e)
                {
                    System.err.println("无法正确加载文件：" + e);
                }
            return new ArrayList<CompoundTag>();
        }, Util.backgroundExecutor()).thenAcceptAsync(patterns ->
        {
            currentFilePatterns = patterns;
            loadingFile = false;
        }, Minecraft.getInstance());
    }

    //显示右侧文件选择器
    private void rendRightFileSelectorFileName(GuiGraphics guiGraphics)
    {
        //绘制当前文件名
        if (!is_show_EditBox_file_name)
        {
            if (selectedFileIndex >= 0 && selectedFileIndex < fileList.size())
            {
                String fileName = fileList.get(selectedFileIndex).getFileName().toString();
                //移除.ae2_pattern_content_nbt 后缀
                if (fileName.endsWith(".ae2_pattern_content_nbt"))
                {
                    fileName = fileName.substring(0, fileName.length() - ".ae2_pattern_content_nbt".length());
                }
                guiGraphics.drawString(font, font.plainSubstrByWidth(fileName, FILE_SELECTOR_WIDTH), RIGHT_GUI_START_X + 21, RIGHT_GUI_START_Y + 4 + 4, 0xFFFFFF);
            }
                else
                {
                    guiGraphics.drawString(font, Component.translatable("<没有文件>"), RIGHT_GUI_START_X + 21, RIGHT_GUI_START_Y + 4 + 4, 0xFF0000);
                }
        }
    }

    //右侧屏幕样板内容预览
    private void rendRightPatternContentPreview(GuiGraphics guiGraphics, int x, int y, int mouseX, int mouseY)
    {
        if (currentFilePatterns.isEmpty() || now_preview_pattern_index < 0 || now_preview_pattern_index >= currentFilePatterns.size())
        {
            if (loadingFile)
            {
                guiGraphics.drawCenteredString(font, Component.translatable("正在加载样板内容……"), RIGHT_GUI_START_X + 3 + AE2_PATTERN_PANEL_WIDTH / 2, RIGHT_GUI_START_Y + 20 + AE2_PATTERN_PANEL_HEIGHT / 2 - 4, 0xFFFFFF);
            }
            return;
        }

        CompoundTag patternTag = currentFilePatterns.get(now_preview_pattern_index);

        if (patternTag != null)
        {
            String id = patternTag.getString("id");
            CompoundTag tag = patternTag.getCompound("tag");

            List<GenericStack> inputStack = PatternContentHelper.patternTag_to_List_GenericStack(tag, id, "in");
            List<String> inputItemId = PatternContentHelper.patternTag_to_List_String(tag, id, "in");

            List<GenericStack> outputStack = PatternContentHelper.patternTag_to_List_GenericStack(tag, id, "out");
            List<String> outputItemId = PatternContentHelper.patternTag_to_List_String(tag, id, "out");

            RendHelper.rendAE2PatternPanelAndItemAndTooltip(guiGraphics, id, inputStack, inputItemId, outputStack, outputItemId, x, y, mouseX, mouseY);
        }
    }

    //绘制虚拟样板槽位产物和tooltips
    private void renderRightVirtualPatternSlotOutputItemAndTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        //先绘制所有物品
        for (int row = 0; row < SLOT_ROWS; row++)
        {
            for (int col = 0; col < SLOT_COLS; col++)
            {
                int index = filePreviewScrollOffset * 7 + row * SLOT_COLS + col;
                int slot_x = RIGHT_GUI_START_X + 3 + col * 18;
                int slot_y = RIGHT_GUI_START_Y + 88 + row * 18;

                if (index < currentFilePatterns.size())
                {
                    CompoundTag patternTag = currentFilePatterns.get(index);

                    //从NBT解析输出物品
                    GenericStack output = PatternContentHelper.patternTag_to_GenericStack(patternTag, "out", 0);
                    if (output != null)
                    {
                        RendHelper.rendItemOrFluid(guiGraphics, output, slot_x + 1, slot_y + 1);
                    }
                        else
                        {
                            //无输出或解析失败，显示错误图标
                            GUIBackgroundRendHelper.rendErrorItemPanel(guiGraphics, slot_x + 1, slot_y + 1);
                        }
                }
                //渲染slot选中效果
                if (index == now_preview_pattern_index)
                {
                    RendHelper.rendSlotBeSelectedEffect(guiGraphics, slot_x + 1, slot_y + 1);
                }
            }
        }

        //渲染样板tooltip
        if (is_in_file_pattern_content_virtual_slot(mouseX, mouseY))
        {
            int col = (mouseX - RIGHT_GUI_START_X - 3) / 18;
            int row = (mouseY - RIGHT_GUI_START_Y - 88) / 18;
            int index = filePreviewScrollOffset * 7 + row * SLOT_COLS + col;
            int slot_x = RIGHT_GUI_START_X + 3 + col * 18;
            int slot_y = RIGHT_GUI_START_Y + 88 + row * 18;

            //绘制悬停高亮
            RendHelper.rendSlotBeSelectedEffect(guiGraphics, slot_x + 1, slot_y + 1);

            //显示tooltip（如果有物品）
            if (index < currentFilePatterns.size())
            {
                CompoundTag patternTag = currentFilePatterns.get(index);
                GenericStack output = PatternContentHelper.patternTag_to_GenericStack(patternTag, "out", 0);
                if (output != null)
                {
                    RendHelper.rendItemOrFluidTooltip(guiGraphics, output, mouseX, mouseY);
                }
                    else
                    {
                        //无输出时，尝试显示错误tooltip
                        RendHelper.rendErrorPatternItemTooltip(guiGraphics, patternTag, "out", mouseX, mouseY);
                    }
            }
        }
    }

    //创建新的NBT文件
    public void createNewNBTFile()
    {
        String fileName = fileNameInput.getValue().trim();
        if (fileName.isEmpty())
        {
            fileName = "new_pattern";
        }
        // 确保扩展名正确
        if (!fileName.endsWith(".ae2_pattern_content_nbt"))
        {
            fileName += ".ae2_pattern_content_nbt";
        }

        //创建新的NBT文件
        Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("ae2_pattern_content_nbt");
        try
        {
            Files.createDirectories(dir);
            Path file = dir.resolve(fileName);
            CompoundTag root = new CompoundTag();
            ListTag patternsList = new ListTag();
            root.put("patterns", patternsList);
            NbtIo.write(root, file.toFile());

            //刷新文件列表
            refreshFileList();

            //自动选中新创建的文件
            for (int i = 0; i < fileList.size(); i++)
            {
                if (fileList.get(i).getFileName().toString().equals(fileName))
                {
                    selectedFileIndex = i;
                    loadFileContent(i);
                    now_preview_pattern_index = 0;
                    filePreviewScrollOffset = 0;
                    break;
                }
            }
        }
            catch (IOException e)
            {
                e.printStackTrace();
                if (Minecraft.getInstance().player != null)
                {
                    System.err.println("创建文件失败: " + e.getMessage());
                }
            }
                finally
                {
                    //隐藏输入框
                    is_show_EditBox_file_name = false;
                    fileNameInput.setVisible(false);
                    fileNameInput.setFocused(false);
                }
    }

    //绘制左侧样板内容buffer
    private void rendLeftBufferPatternContentPreview(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        int BufferCountInLeftScreen = (GUI_HEIGHT - 48) / AE2_PATTERN_PANEL_HEIGHT;
        for (int i = left_GUI_start_panel_index; i < Math.min(left_GUI_start_panel_index + BufferCountInLeftScreen, leftBufferPatterns.size()); i++)
        {
            //绘制样板预览
            if (leftBufferPatterns != null)
            {
                String id = leftBufferPatterns.get(i).getString("id");
                CompoundTag tag = leftBufferPatterns.get(i).getCompound("tag");

                List<GenericStack> inputStack = PatternContentHelper.patternTag_to_List_GenericStack(tag, id, "in");
                List<String> inputItemId = PatternContentHelper.patternTag_to_List_String(tag, id, "in");

                List<GenericStack> outputStack = PatternContentHelper.patternTag_to_List_GenericStack(tag, id, "out");
                List<String> outputItemId = PatternContentHelper.patternTag_to_List_String(tag, id, "out");

                RendHelper.rendAE2PatternPanelAndItemAndTooltip(guiGraphics, id, inputStack, inputItemId, outputStack, outputItemId, LEFT_GUI_START_X + 3, LEFT_GUI_START_Y + 3 + (i - left_GUI_start_panel_index) * AE2_PATTERN_PANEL_HEIGHT, mouseX, mouseY);
            }
        }

        //鼠标悬停高亮
        if (mouseX >= LEFT_GUI_START_X + 3 && mouseX <= LEFT_GUI_START_X + 3 + AE2_PATTERN_PANEL_WIDTH && mouseY >= LEFT_GUI_START_Y + 3 && mouseY <= LEFT_GUI_START_Y + 3 + AE2_PATTERN_PANEL_HEIGHT * BufferCountInLeftScreen)
        {
            int BufferPatternPanelIndex = (mouseY - 3) / AE2_PATTERN_PANEL_HEIGHT;
            guiGraphics.fill(LEFT_GUI_START_X + 3, LEFT_GUI_START_Y + 3 + BufferPatternPanelIndex * AE2_PATTERN_PANEL_HEIGHT, LEFT_GUI_START_X + 3 + AE2_PATTERN_PANEL_WIDTH, LEFT_GUI_START_Y + 3 + (BufferPatternPanelIndex + 1) * AE2_PATTERN_PANEL_HEIGHT, 0x7FFFFFFF);
        }
    }

    //清空左侧缓存
    private void deleteAllBuffer()
    {
        leftBufferPatterns.clear();
        left_GUI_start_panel_index = 0;
    }

    //将左侧缓存全部写入本地文件
    private CompletableFuture<Void> saveAllBufferToFile()
    {
        //无样板可保存
        if (leftBufferPatterns.isEmpty())
        {
            System.out.println("缓存区中没有样板数据");
            return CompletableFuture.completedFuture(null);
        }

        //未选中任何文件
        if (selectedFileIndex < 0 || selectedFileIndex >= fileList.size())
        {
            System.out.println("没有选中的文件");
            return CompletableFuture.completedFuture(null);
        }

        //当前选中的文件
        Path targetFile = fileList.get(selectedFileIndex);

        return CompletableFuture.runAsync(() ->
        {
            try
            {
                CompoundTag root;
                if (Files.exists(targetFile))
                {
                    root = NbtIo.read(targetFile.toFile());
                    if (root == null)
                    {
                        root = new CompoundTag();
                    }
                }
                    else
                    {
                        root = new CompoundTag();
                    }

                ListTag patternsList;
                if (root.contains("patterns", Tag.TAG_LIST))
                {
                    patternsList = root.getList("patterns", Tag.TAG_COMPOUND);
                }
                    else
                    {
                        patternsList = new ListTag();
                        root.put("patterns", patternsList);
                    }

                //使用复制的列表进行追加
                patternsList.addAll(leftBufferPatterns);
                NbtIo.write(root, targetFile.toFile());
            }
            catch (IOException e)
            {
                e.printStackTrace();
                throw new RuntimeException(e); //让CompletableFuture捕获异常
            }
        }, Util.backgroundExecutor()).thenRunAsync(() ->
        {
            //保存成功后，在主线程刷新右侧预览
            Minecraft.getInstance().execute(() ->
            {
                if (selectedFileIndex >= 0 && selectedFileIndex < fileList.size())
                {
                    loadFileContent(selectedFileIndex);
                    now_preview_pattern_index = currentFilePatterns.size();
                    if(currentFilePatterns.size() >= SLOT_ROWS * 7)
                    {
                        filePreviewScrollOffset = currentFilePatterns.size() / 7 + 1 - SLOT_ROWS;
                    }
                }
            });
        }, Util.backgroundExecutor());
    }

    //保存单个样板
    private void addBufferToFile(CompoundTag pattern)
    {
        if (selectedFileIndex < 0 || selectedFileIndex >= fileList.size())
        {
            return;
        }

        Path targetFile = fileList.get(selectedFileIndex);
        CompletableFuture.runAsync(() ->
        {
            try
            {
                CompoundTag root;
                if (Files.exists(targetFile))
                {
                    root = NbtIo.read(targetFile.toFile());
                    if (root == null)
                    {
                        root = new CompoundTag();
                    }
                }
                    else
                    {
                        root = new CompoundTag();
                    }

                ListTag patternsList;
                if (root.contains("patterns", Tag.TAG_LIST))
                {
                    patternsList = root.getList("patterns", Tag.TAG_COMPOUND);
                }
                else
                    {
                        patternsList = new ListTag();
                        root.put("patterns", patternsList);
                    }

                patternsList.add(pattern);
                NbtIo.write(root, targetFile.toFile());
                //保存成功后，在主线程刷新右侧预览
                Minecraft.getInstance().execute(() ->
                {
                    if (selectedFileIndex >= 0 && selectedFileIndex < fileList.size())
                    {
                        loadFileContent(selectedFileIndex);
                        now_preview_pattern_index = currentFilePatterns.size();
                        if(currentFilePatterns.size() >= SLOT_ROWS * 7)
                        {
                            filePreviewScrollOffset = currentFilePatterns.size() / 7 + 1 - SLOT_ROWS;
                        }
                    }
                });
            }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
        }, Util.backgroundExecutor());
    }

    //保存文件到本地
    private void saveNBTFileToDisk()
    {
        //如果没有选中文件或文件列表为空，则不保存
        if (selectedFileIndex < 0 || selectedFileIndex >= fileList.size())
        {
            return;
        }

        Path targetFile = fileList.get(selectedFileIndex);
        CompletableFuture.runAsync(() ->
        {
            try
            {
                CompoundTag root = new CompoundTag();
                ListTag patternsList = new ListTag();
                patternsList.addAll(currentFilePatterns);
                root.put("patterns", patternsList);
                NbtIo.write(root, targetFile.toFile());
            }
            catch (IOException e)
                {
                    e.printStackTrace();
                    Minecraft.getInstance().execute(() ->
                    {
                        if (Minecraft.getInstance().player != null)
                        {
                            System.err.println("保存失败: " + e.getMessage());
                        }
                    });
                }
        }, Util.backgroundExecutor());
    }

    public void updatePattern(int fileIndex, int patternIndex, CompoundTag newPattern)
    {
        //处理文件模式
        if (fileIndex >= 0 && fileIndex < fileList.size())
        {
            if (patternIndex >= 0 && patternIndex < currentFilePatterns.size())
            {
                currentFilePatterns.set(patternIndex, newPattern);
                saveNBTFileToDisk();
                now_preview_pattern_index = patternIndex;
            }
        }
            //如果无法写入本地文件，则写入buffer
            else
            {
                leftBufferPatterns.add(newPattern);
            }
        // 可选：刷新左侧或右侧预览
    }

    //是否在上一页按钮区域内
    private boolean is_in_prev_button_1_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_1 && x <= CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_1 + SMALL_BUTTON_WIDTH && y >= CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_1 && y <= CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_1 + SMALL_BUTTON_HEIGHT;
    }

    private boolean is_in_prev_button_2_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_2 && x <= CENTER_GUI_START_X + PREV_BUTTON_AREA_START_X_2 + SMALL_BUTTON_WIDTH && y >= CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_2 && y <= CENTER_GUI_START_Y + PREV_BUTTON_AREA_START_Y_2 + SMALL_BUTTON_HEIGHT;
    }

    //是否在下一页按钮区域内
    private boolean is_in_next_button_1_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_1 && x <= CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_1 + SMALL_BUTTON_WIDTH && y >= CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_1 && y <= CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_1 + SMALL_BUTTON_HEIGHT;
    }

    private boolean is_in_next_button_2_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_2 && x <= CENTER_GUI_START_X + NEXT_BUTTON_AREA_START_X_2 + SMALL_BUTTON_WIDTH && y >= CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_2 && y <= CENTER_GUI_START_Y + NEXT_BUTTON_AREA_START_Y_2 + SMALL_BUTTON_HEIGHT;
    }

    //是否在打开文件夹按钮区域内
    private boolean is_in_open_folder_button_area(int x, int y)
    {
        return x >= RIGHT_GUI_START_X + OPEN_FOLDER_BUTTON_AREA_START_X && x <= RIGHT_GUI_START_X + OPEN_FOLDER_BUTTON_AREA_START_X + SMALL_BUTTON_WIDTH && y >= RIGHT_GUI_START_Y + OPEN_FOLDER_BUTTON_AREA_START_Y && y <= RIGHT_GUI_START_Y + OPEN_FOLDER_BUTTON_AREA_START_Y + SMALL_BUTTON_HEIGHT;
    }

    //是否在文件名输入框区域内
    private boolean is_in_file_name_input_area(int x, int y)
    {
        return x >= RIGHT_GUI_START_X + 18 && x <= RIGHT_GUI_START_X + 18 + FILE_SELECTOR_WIDTH && y >= RIGHT_GUI_START_Y + 4 && y <= RIGHT_GUI_START_Y + 4 + FILE_SELECTOR_HEIGHT;
    }

    //检查是否在滚轮区域内
    private boolean is_in_jei_part_wheel_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + WHEEL_AREA_START_X_JEI_PART && x <= CENTER_GUI_START_X + CENTER_GUI_WIDTH && y >= CENTER_GUI_START_Y + WHEEL_AREA_START_Y_JEI_PART && y <= CENTER_GUI_START_Y + GUI_HEIGHT;
    }

    private boolean is_in_right_screen_pattern_content_preview_area(int x, int y)
    {
        return x >= RIGHT_GUI_START_X + AE2_PATTERN_PANEL_START_X_IN_RIGHT_SCREEN - 1 && x <= RIGHT_GUI_START_X + AE2_PATTERN_PANEL_START_X_IN_RIGHT_SCREEN + AE2_PATTERN_PANEL_WIDTH - 1 && y >= RIGHT_GUI_START_Y + AE2_PATTERN_PANEL_START_Y_IN_RIGHT_SCREEN - 1 && y <= RIGHT_GUI_START_Y + AE2_PATTERN_PANEL_START_Y_IN_RIGHT_SCREEN + AE2_PATTERN_PANEL_HEIGHT - 1;
    }

    private boolean is_in_file_pattern_content_virtual_slot(int x, int y)
    {
        return x >= RIGHT_GUI_START_X + 3 && x <= RIGHT_GUI_START_X + 18 * SLOT_COLS + 2 && y >= RIGHT_GUI_START_Y + 88 && y <= RIGHT_GUI_START_Y + SLOT_ROWS * 18 + 87;
    }

    private boolean is_in_left_GUI_area(int x, int y)
    {
        return x >= LEFT_GUI_START_X && x <= LEFT_GUI_START_X + LEFT_AND_RIGHT_GUI_WIDTH && y >= LEFT_GUI_START_Y && y <= LEFT_GUI_START_Y + GUI_HEIGHT;
    }

    private boolean is_in_JEI_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + 3 && x <= CENTER_GUI_START_X + CENTER_GUI_WIDTH - 3 && y > CENTER_GUI_START_Y + 32 && y < CENTER_GUI_START_Y + GUI_HEIGHT - 3;
    }

    private boolean is_in_JEI_recipe_name_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2 - JEIRecipeNameLength * 8 / 2 && x <= CENTER_GUI_START_X + CENTER_GUI_WIDTH / 2 + JEIRecipeNameLength * 8 / 2 && y >= CENTER_GUI_START_Y + 6 && y <= CENTER_GUI_START_Y + 22;
    }
}