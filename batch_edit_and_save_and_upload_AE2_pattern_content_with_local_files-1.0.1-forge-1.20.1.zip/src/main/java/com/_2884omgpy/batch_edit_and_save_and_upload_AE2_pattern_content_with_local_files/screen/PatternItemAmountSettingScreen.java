package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import appeng.api.stacks.GenericStack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.GUIBackgroundRendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.RendHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.function.Consumer;

public class PatternItemAmountSettingScreen extends Screen
{
    private final Consumer<Long> onConfirm;
    private final long currentAmount;
    private final GenericStack itemStack;
    private EditBox amountInput;
    private final Screen previousScreen;

    private int SCREEN_START_X = 0;
    private int SCREEN_START_Y = 0;

    public PatternItemAmountSettingScreen(Consumer<Long> onConfirm, long currentAmount, GenericStack itemStack, Screen previousScreen)
    {
        super(Component.translatable("设置数量"));
        this.onConfirm = onConfirm;
        this.currentAmount = currentAmount;
        this.itemStack = itemStack;
        this.previousScreen = previousScreen;
    }

    @Override
    protected void init()
    {
        super.init();
        SCREEN_START_X = width / 2 - 88;
        SCREEN_START_Y = height / 2 - 53;

        amountInput = new EditBox(font, SCREEN_START_X + 50, SCREEN_START_Y + 57 ,70, 8, Component.literal(""));
        amountInput.setValue(String.valueOf(currentAmount));
        amountInput.setFilter(string -> string.matches("\\d*"));    //只允许数字
        amountInput.setBordered(false);
        amountInput.setTextColor(0XFFFFFF);
        amountInput.setResponder(string -> validateAndUpdateColor()); // 内容变化时验证
        addRenderableWidget(amountInput);

        createButton();
    }

    private void createButton()
    {
        Button confirmButton = Button.builder(Component.translatable("设置"), button ->
        {
            saveAmount(Long.parseLong(amountInput.getValue()));
        }).pos(SCREEN_START_X + 120, SCREEN_START_Y + 51).size(38, 20).build();

        Button add1 = Button.builder(Component.literal("+1"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) + 1));
        }).pos(SCREEN_START_X + 20, SCREEN_START_Y + 30).size(22, 20).build();

        Button add10 = Button.builder(Component.literal("+10"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) + 10));
        }).pos(SCREEN_START_X + 48, SCREEN_START_Y + 30).size(28, 20).build();

        Button add100 = Button.builder(Component.literal("+100"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) + 100));
        }).pos(SCREEN_START_X + 82, SCREEN_START_Y + 30).size(32, 20).build();

        Button add1000 = Button.builder(Component.literal("+1000"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) + 1000));
        }).pos(SCREEN_START_X + 120, SCREEN_START_Y + 30).size(38, 20).build();

        Button reduce1 = Button.builder(Component.literal("-1"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) - 1));
        }).pos(SCREEN_START_X + 20, SCREEN_START_Y + 72).size(22, 20).build();

        Button reduce10 = Button.builder(Component.literal("-10"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) - 10));
        }).pos(SCREEN_START_X + 48, SCREEN_START_Y + 72).size(28, 20).build();

        Button reduce100 = Button.builder(Component.literal("-100"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) - 100));
        }).pos(SCREEN_START_X + 82, SCREEN_START_Y + 72).size(32, 20).build();

        Button reduce1000 = Button.builder(Component.literal("-1000"), button ->
        {
            amountInput.setValue(String.valueOf(Long.parseLong(amountInput.getValue()) - 1000));
        }).pos(SCREEN_START_X + 120, SCREEN_START_Y + 72).size(38, 20).build();

        addRenderableWidget(confirmButton);
        addRenderableWidget(add1);
        addRenderableWidget(add10);
        addRenderableWidget(add100);
        addRenderableWidget(add1000);
        addRenderableWidget(reduce1);
        addRenderableWidget(reduce10);
        addRenderableWidget(reduce100);
        addRenderableWidget(reduce1000);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        renderBackground(guiGraphics);
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, width / 2 - 88, height / 2 - 53, 176, 107);
        guiGraphics.drawString(font, "选择数量", SCREEN_START_X + 8, SCREEN_START_Y + 6, 0x3F3F3F, false);
        GUIBackgroundRendHelper.rendAE2PatternContentAmountSettingInputTextbox(guiGraphics, SCREEN_START_X + 48, SCREEN_START_Y + 55);
        GUIBackgroundRendHelper.rendSlot(guiGraphics, SCREEN_START_X + 22, SCREEN_START_Y + 52);

        if (itemStack != null)
        {
            RendHelper.rendItemOrFluid(guiGraphics, itemStack, SCREEN_START_X + 23, SCREEN_START_Y + 53);
        }

        rendTooltipAndMouseHoverSlotEffect(guiGraphics, mouseX, mouseY);

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    private void validateAndUpdateColor()
    {
        try
        {
            long amount = Long.parseLong(amountInput.getValue());
            if (amount >= 1 && amount <= 2147483647)
            {
                amountInput.setTextColor(0xFFFFFF);
            }
                else
                {
                    amountInput.setTextColor(0xFF0000);
                }
        }
            catch (NumberFormatException e)
            {
                amountInput.setTextColor(0xFF0000);
            }
    }

    private void saveAmount(long amount)
    {
        if (amount > 0 && amount <= 2147483647)
        {
            onConfirm.accept(amount);
            onClose();
        }
        else
            {
                amountInput.setTextColor(0xFF0000);
            }
    }

    private void rendTooltipAndMouseHoverSlotEffect(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (mouseX >= SCREEN_START_X + 22 && mouseX <= SCREEN_START_X + 39 && mouseY >= SCREEN_START_Y + 52 && mouseY <= SCREEN_START_Y + 69)
        {
            RendHelper.rendSlotBeSelectedEffect(guiGraphics, SCREEN_START_X + 23, SCREEN_START_Y + 53);
            if (itemStack != null)
            {
                RendHelper.rendItemOrFluidTooltip(guiGraphics, itemStack, mouseX, mouseY);
            }
        }
    }

    @Override
    public void onClose()
    {
        Minecraft.getInstance().setScreen(previousScreen);
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }
}