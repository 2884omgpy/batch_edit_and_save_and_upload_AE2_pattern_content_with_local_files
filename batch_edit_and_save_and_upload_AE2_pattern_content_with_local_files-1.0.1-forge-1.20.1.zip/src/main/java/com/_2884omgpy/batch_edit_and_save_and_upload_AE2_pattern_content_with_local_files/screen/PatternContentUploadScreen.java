package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import appeng.api.stacks.GenericStack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.GUIBackgroundRendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.MixinCallBack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.RendHelper;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PatternContentUploadScreen extends Screen
{
    public static final ResourceLocation OPEN_FOLDER_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/open_folder_button_hover.png");

    private final Screen prevScreen;
    private MixinCallBack callback;

    private List<Path> fileList = new ArrayList<>();
    private int selectedFileIndex = -1;
    private List<CompoundTag> willBeUploadPatternContent = new ArrayList<>();
    private int filePreviewScrollOffset = 0;

    private int playerInventoryBlankPatternItemCount = 0;
    private boolean isPlayerInventoryBlankPatternNotEnough = false;

    private int slotTotalRow;
    private int slotTotalCol;
    private int slotStartX;
    private int slotStartY;

    public PatternContentUploadScreen(Screen prevScreen, MixinCallBack callback)
    {
        super(Component.translatable("批量上传样板"));
        this.prevScreen = prevScreen;
        this.callback = callback;
    }

    @Override
    protected void init()
    {
        super.init();
        refreshFileList();
        createButton();
    }

    private void refreshFileList()
    {
        Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("ae2_pattern_content_nbt");
        if (!Files.exists(dir))
        {
            try
            {
                Files.createDirectories(dir);
            }
                catch (IOException e)
                {
                    System.err.println("无法创建文件夹：" + e);
                }
        }

        try (Stream<Path> stream = Files.list(dir))
        {
            fileList = stream.filter(p -> p.toString().endsWith(".ae2_pattern_content_nbt")).sorted(Comparator.comparing(Path::getFileName)).collect(Collectors.toList());
        }
            catch (IOException e)
            {
                System.err.println("读取文件列表失败：" + e);
            }

        if (!fileList.isEmpty())
        {
            selectedFileIndex = 0;
            loadFileContent(0);
        }
            else
            {
                selectedFileIndex = -1;
                willBeUploadPatternContent.clear();
                filePreviewScrollOffset = 0;
            }
    }

    private void loadFileContent(int index)
    {
        if (index < 0 || index >= fileList.size())
        {
            return;
        }
        Path file = fileList.get(index);
        CompletableFuture.supplyAsync(() ->
        {
            try
            {
                CompoundTag root = NbtIo.read(file.toFile());
                if (root != null && root.contains("patterns", Tag.TAG_LIST))
                {
                    ListTag list = root.getList("patterns", Tag.TAG_COMPOUND);
                    List<CompoundTag> patterns = new ArrayList<>();
                    for (int i = 0; i < list.size(); i++)
                    {
                        patterns.add(list.getCompound(i));
                    }
                    return patterns;
                }
            }
                catch (IOException e)
                {
                    System.err.println("无法加载文件：" + e);
                }
            return new ArrayList<CompoundTag>();
        }, Util.backgroundExecutor()).thenAcceptAsync(patterns ->
        {
            willBeUploadPatternContent = patterns;
            filePreviewScrollOffset = 0;
        }, Minecraft.getInstance());
    }

    private void updateLayout()
    {
        slotTotalRow = Math.max(1, (height - 24) / 18);
        slotTotalCol = Math.max(1, (width - 4) / 18);
        slotStartX = (width - slotTotalCol * 18) / 2;
        slotStartY = (height - slotTotalRow * 18) / 2 + 8;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        updateLayout();
        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, 0, 0, width, height);
        GUIBackgroundRendHelper.rendFileNameSelectTextbox(guiGraphics, 4, 4);
        rendSelectorFileName(guiGraphics);
        rendSlotsAndItem(guiGraphics);
        rendButtonHoverEffectAndTooltip(guiGraphics, mouseX, mouseY);
        renderVirtualPatternSlotOutputItemAndTooltips(guiGraphics, mouseX, mouseY);

        if (isPlayerInventoryBlankPatternNotEnough)
        {
            if (Minecraft.getInstance().player.getAbilities().instabuild)
            {
                guiGraphics.drawString(font, Component.translatable("创造模式下背包中至少应有1个空白样板"), 130, 8, 0xFF0000, false);
            }
                else
                {
                    guiGraphics.drawString(font, Component.translatable("玩家样板数量不足，当前有：" + playerInventoryBlankPatternItemCount + "，需要：" + willBeUploadPatternContent.size()), 130, 8, 0xFF0000, false);
                }
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    private void createButton()
    {
        Button confirmButton = Button.builder(Component.translatable("确认"), button -> startUpload()).pos(width - 70, 4).size(32, 15).build();
        Button cancelButton = Button.builder(Component.translatable("取消"), button -> onClose()).pos(width - 36, 4).size(32, 15).build();
        addRenderableWidget(confirmButton);
        addRenderableWidget(cancelButton);
    }

    private void rendSlotsAndItem(GuiGraphics guiGraphics)
    {
        for (int row = 0; row < slotTotalRow; row++)
        {
            for (int col = 0; col < slotTotalCol; col++)
            {
                GUIBackgroundRendHelper.rendSlot(guiGraphics, slotStartX + col * 18, slotStartY + row * 18);
            }
        }
    }

    private void rendButtonHoverEffectAndTooltip(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (isInOpenFolderButtonArea(mouseX, mouseY))
        {
            guiGraphics.blit(OPEN_FOLDER_BUTTON_HOVER, 4, 5, 0, 0, 13, 13, 13, 13);
            guiGraphics.renderTooltip(font, Component.translatable("打开NBT文件夹"), mouseX, mouseY);
        }
    }

    private void rendSelectorFileName(GuiGraphics guiGraphics) {
        if (selectedFileIndex >= 0 && selectedFileIndex < fileList.size())
        {
            String fileName = fileList.get(selectedFileIndex).getFileName().toString();
            if (fileName.endsWith(".ae2_pattern_content_nbt"))
            {
                fileName = fileName.substring(0, fileName.length() - ".ae2_pattern_content_nbt".length());
            }
            guiGraphics.drawString(font, font.plainSubstrByWidth(fileName, 109), 21, 8, 0xFFFFFF);
        }
            else
            {
                guiGraphics.drawString(font, Component.translatable("<没有文件>"), 21, 8, 0xFF0000);
            }
    }

    private void renderVirtualPatternSlotOutputItemAndTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        //绘制物品
        for (int row = 0; row < slotTotalRow; row++)
        {
            for (int col = 0; col < slotTotalCol; col++)
            {
                int slotX = slotStartX + col * 18;
                int slotY = slotStartY + row * 18;
                int index = (filePreviewScrollOffset + row) * slotTotalCol + col;
                if (index < willBeUploadPatternContent.size())
                {
                    CompoundTag patternTag = willBeUploadPatternContent.get(index);
                    GenericStack output = PatternContentHelper.patternTag_to_GenericStack(patternTag, "out", 0);
                    if (output != null)
                    {
                        RendHelper.rendItemOrFluid(guiGraphics, output, slotX + 1, slotY + 1);
                    }
                        else
                        {
                            GUIBackgroundRendHelper.rendErrorItemPanel(guiGraphics, slotX + 1, slotY + 1);
                        }
                }
            }
        }

        //鼠标悬停tooltip
        if (isInVirtualSlotArea(mouseX, mouseY))
        {
            int col = (mouseX - slotStartX) / 18;
            int row = (mouseY - slotStartY) / 18;
            int index = (filePreviewScrollOffset + row) * slotTotalCol + col;
            RendHelper.rendSlotBeSelectedEffect(guiGraphics, slotStartX + col * 18 + 1, slotStartY + row * 18 + 1);
            if (index >= 0 && index < willBeUploadPatternContent.size())
            {
                CompoundTag patternTag = willBeUploadPatternContent.get(index);
                GenericStack output = PatternContentHelper.patternTag_to_GenericStack(patternTag, "out", 0);
                if (output != null)
                {
                    RendHelper.rendItemOrFluidTooltip(guiGraphics, output, mouseX, mouseY);
                }
                    else
                    {
                        RendHelper.rendErrorPatternItemTooltip(guiGraphics, patternTag, "out", mouseX, mouseY);
                    }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        if (isInOpenFolderButtonArea((int) mouseX, (int) mouseY))
        {
            Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("ae2_pattern_content_nbt");
            try
            {
                Util.getPlatform().openUri(dir.toFile().toURI());
            }
                catch (Exception e)
                {
                    System.err.println("无法打开文件夹");
                }
            playButtonClickSound();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        //文件选择滚轮
        if (isInFileSelectorArea((int) mouseX, (int) mouseY))
        {
            if (fileList.isEmpty())
            {
                return true;
            }
            int newIndex = selectedFileIndex + (delta > 0 ? -1 : 1);
            if (newIndex < 0)
            {
                newIndex = fileList.size() - 1;
            }
            if (newIndex >= fileList.size())
            {
                newIndex = 0;
            }
            if (selectedFileIndex != newIndex)
            {
                selectedFileIndex = newIndex;
                loadFileContent(newIndex);
            }
            return true;
        }
        //虚拟槽位滚轮
        if (isInVirtualSlotArea((int) mouseX, (int) mouseY))
        {
            if (delta > 0)
            {
                if (filePreviewScrollOffset > 0)
                {
                    filePreviewScrollOffset--;
                }
            }
            else
                if (delta < 0)
                {
                    if (filePreviewScrollOffset * slotTotalCol + slotTotalRow * slotTotalCol < willBeUploadPatternContent.size())
                    {
                        filePreviewScrollOffset++;
                    }
                }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    private void startUpload()
    {
        playerInventoryBlankPatternItemCount = 0;
        for (int i = 0; i < 36; i++)
        {
            ItemStack itemStack = Minecraft.getInstance().player.getInventory().getItem(i);
            if (!itemStack.isEmpty() && BuiltInRegistries.ITEM.getKey(itemStack.getItem()).toString().equals("ae2:blank_pattern"))
            {
                playerInventoryBlankPatternItemCount += itemStack.getCount();
            }
        }

        if (willBeUploadPatternContent != null && !willBeUploadPatternContent.isEmpty())
        {
            if (Minecraft.getInstance().player.getAbilities().instabuild)
            {
                if (playerInventoryBlankPatternItemCount >= 1)
                {
                    //回调函数
                    callback.startUpload(willBeUploadPatternContent);
                    onClose();
                }
                    else
                    {
                        isPlayerInventoryBlankPatternNotEnough = true;
                    }
            }
            else
            {
                if (playerInventoryBlankPatternItemCount >= willBeUploadPatternContent.size())
                {
                    //回调函数
                    callback.startUpload(willBeUploadPatternContent);
                    onClose();
                }
                    else
                    {
                        isPlayerInventoryBlankPatternNotEnough = true;
                    }
            }
        }
    }

    private boolean isInOpenFolderButtonArea(int x, int y)
    {
        return x >= 4 && x <= 17 && y >= 5 && y <= 18;
    }

    private boolean isInFileSelectorArea(int x, int y)
    {
        return x >= 18 && x <= 127 && y >= 4 && y <= 19;
    }

    private boolean isInVirtualSlotArea(int x, int y)
    {
        return x >= slotStartX && x < slotStartX + slotTotalCol * 18 && y >= slotStartY && y < slotStartY + slotTotalRow * 18;
    }

    private void playButtonClickSound()
    {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    @Override
    public void onClose()
    {
        Minecraft.getInstance().setScreen(prevScreen);
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }
}