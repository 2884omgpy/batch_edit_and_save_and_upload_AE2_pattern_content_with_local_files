package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.GUIBackgroundRendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.RendHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.init.ModJEIPlugin;
import com.mojang.blaze3d.systems.RenderSystem;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.ingredients.IIngredientType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PatternContentEditScreen extends Screen
{
    public static final ResourceLocation PATTERN_CONTENT_EDIT_SCREEN_TEXTURE = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/pattern_content_edit_screen.png");

    public static final ResourceLocation PREV_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/prev_button_hover.png");
    public static final ResourceLocation NEXT_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/next_button_hover.png");

    private final int fileIndex;
    private final int patternIndex;
    private CompoundTag patternTag;
    private final Screen previousScreen;
    private final Player player;
    private List<Slot> slots = new ArrayList<>();
    private GenericStack carriedStack = null;

    private List<GenericStack> currentInputs;
    private List<GenericStack> currentOutputs;
    private String currentPatternType;

    private int CENTER_GUI_START_X = 0;
    private int CENTER_GUI_START_Y = 0;

    private int JEI_ITEM_LIST_SCREEN_WIDTH = 0;
    private int JEI_ITEM_LIST_SCREEN_HEIGHT = 0;
    private int JEI_ITEM_LIST_SCREEN_START_X = 0;
    private int JEI_ITEM_LIST_SCREEN_START_Y = 0;

    private int SNBT_PREVIEW_PANEL_SCREEN_WIDTH = 0;
    private int SNBT_PREVIEW_PANEL_SCREEN_HEIGHT = 0;
    private int SNBT_PREVIEW_PANEL_SCREEN_START_X = 0;
    private int SNBT_PREVIEW_PANEL_SCREEN_START_Y = 0;

    private static final int AE2_PATTERN_PANEL_START_X_IN_CENTER_SCREEN = 7;
    private static final int AE2_PATTERN_PANEL_START_Y_IN_CENTER_SCREEN = 17;

    private List<GenericStack> allJeiItems = new ArrayList<>();        //所有JEI物品和流体
    private List<GenericStack> filteredJeiItems = new ArrayList<>();   //过滤后的物品和流体
    private int jeiItemListPage = 0;                //当前JEI列表页码
    private int jeiItemListColPerPage;              //每页列数
    private int jeiItemListRowPerPage;              //每页行数
    private int jeiItemListItemPerPage;             //每页物品数
    private int jeiItemListTotalPage;
    private int jeiItemListStartX;
    private int jeiItemListStartY;
    private EditBox jeiSearchBox;                   //搜索输入框
    private boolean jeiListInitialized = false;     //标记是否已初始化JEI物品

    private final int fontLineHeight = 9;
    private int RowsPerPage = 1;
    private int maxWidth = 0;
    private int SNBTLineOffset = 0;
    private int SNBTLinesCount = 0;
    private int nowLineIndex = 1;

    private boolean isSNBTSlideSelecting = false;
    private int SNBTLineOffsetBeforeMouseClicked;
    private double slideDeltaY;

    public PatternContentEditScreen(int fileIndex, int patternIndex, CompoundTag patternTag, Screen previousScreen)
    {
        super(Component.translatable("本地样板内容编辑器"));
        this.fileIndex = fileIndex;

        this.patternIndex = patternIndex;
        this.patternTag = patternTag;
        this.previousScreen = previousScreen;
        this.player = Minecraft.getInstance().player;
    }

    public PatternContentEditScreen(CompoundTag patternTag, Screen previousScreen)
    {
        this(-1, -1, patternTag, previousScreen);
    }

    @Override
    protected void init()
    {
        CENTER_GUI_START_X = (width - 176) / 2;
        CENTER_GUI_START_Y = (height - 182) / 2;

        JEI_ITEM_LIST_SCREEN_WIDTH = (int)Math.ceil(width / 2.0) - 88;
        JEI_ITEM_LIST_SCREEN_HEIGHT = height;
        JEI_ITEM_LIST_SCREEN_START_X = width / 2 + 88;

        SNBT_PREVIEW_PANEL_SCREEN_WIDTH = JEI_ITEM_LIST_SCREEN_WIDTH;
        SNBT_PREVIEW_PANEL_SCREEN_HEIGHT = height;

        JEI_Init();

        initFromPatternTag();
        slots.clear();
        //复位处理样板显示页码
        RendHelper.PROCESSING_ENCODING_PANEL_PAGE = 0;
        SNBTLineOffset = 0;

        addPlayerInventorySlots();

        createButton();

        super.init();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        renderBackground(guiGraphics);
        guiGraphics.blit(PATTERN_CONTENT_EDIT_SCREEN_TEXTURE, CENTER_GUI_START_X, CENTER_GUI_START_Y, 0, 0, 176, 182, 176, 182);
        guiGraphics.drawString(font, Component.translatable("样板内容编辑器"), CENTER_GUI_START_X + 8, CENTER_GUI_START_Y + 6, 0x3F3F3F, false);
        guiGraphics.drawString(font, Component.translatable("物品栏（只读模式）"), CENTER_GUI_START_X + 8, CENTER_GUI_START_Y + 88, 0x3F3F3F, false);

        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, JEI_ITEM_LIST_SCREEN_START_X, JEI_ITEM_LIST_SCREEN_START_Y, JEI_ITEM_LIST_SCREEN_WIDTH, JEI_ITEM_LIST_SCREEN_HEIGHT);
        GUIBackgroundRendHelper.rendJEIRecipeNameBar(guiGraphics, JEI_ITEM_LIST_SCREEN_START_X + 6, JEI_ITEM_LIST_SCREEN_START_Y + 4, JEI_ITEM_LIST_SCREEN_WIDTH - 12);
        GUIBackgroundRendHelper.rendJEIItemNameInputTextbox(guiGraphics, JEI_ITEM_LIST_SCREEN_START_X + 4, JEI_ITEM_LIST_SCREEN_START_Y + JEI_ITEM_LIST_SCREEN_HEIGHT - 24, JEI_ITEM_LIST_SCREEN_WIDTH - 8);

        GUIBackgroundRendHelper.rendMinecraftOriginalGUIBackground(guiGraphics, SNBT_PREVIEW_PANEL_SCREEN_START_X, SNBT_PREVIEW_PANEL_SCREEN_START_Y, SNBT_PREVIEW_PANEL_SCREEN_WIDTH, SNBT_PREVIEW_PANEL_SCREEN_HEIGHT);
        GUIBackgroundRendHelper.rendSNBTEditScreen(guiGraphics, SNBT_PREVIEW_PANEL_SCREEN_START_X + 5, SNBT_PREVIEW_PANEL_SCREEN_START_Y + 5, SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 10, SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 30);

        updateInventorySlotItem();
        rendItemAndTooltip(guiGraphics, mouseX, mouseY);
        rendPatternContentPreviewAndPatternModePreview(guiGraphics, CENTER_GUI_START_X + AE2_PATTERN_PANEL_START_X_IN_CENTER_SCREEN, CENTER_GUI_START_Y + AE2_PATTERN_PANEL_START_Y_IN_CENTER_SCREEN, mouseX, mouseY);

        rendJEIItemList(guiGraphics, mouseX, mouseY);
        guiGraphics.drawCenteredString(font, (jeiItemListPage + 1) + "/" + (jeiItemListTotalPage + 1), JEI_ITEM_LIST_SCREEN_START_X + JEI_ITEM_LIST_SCREEN_WIDTH / 2, 7, 0xFFFFFF);
        rendButtonHoverStatus(guiGraphics, mouseX, mouseY);

        rendSNBT(guiGraphics);

        //渲染鼠标拖动物品
        if (carriedStack != null)
        {
            RenderSystem.disableDepthTest();//禁用深度测试
            RenderSystem.enableBlend();     //启用混合（通常已启用）
            RenderSystem.defaultBlendFunc();//设置默认混合函数

            guiGraphics.pose().pushPose();
            //提高Z值，使其在深度上更靠前
            guiGraphics.pose().translate(0, 0, 255);
            RendHelper.rendItemOrFluid(guiGraphics, carriedStack, mouseX - 8, mouseY - 8);
            guiGraphics.pose().popPose();

            RenderSystem.enableDepthTest(); //重新启用深度测试
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        if(is_in_JEI_item_area((int)mouseX, (int)mouseY))
        {
            int slotCol = ((int)mouseX - jeiItemListStartX) / 18;
            int slotRow = ((int)mouseY - jeiItemListStartY) / 18;
            int slotIndex = jeiItemListPage * jeiItemListItemPerPage + jeiItemListColPerPage * slotRow + slotCol;
            if (slotIndex < filteredJeiItems.size())
            {
                carriedStack = filteredJeiItems.get(slotIndex);
                return true;
            }
        }
        jeiSearchBox.setFocused(jeiSearchBox.isMouseOver(mouseX, mouseY));

        if(is_in_JEI_item_list_screen_area((int)mouseX, (int)mouseY))
        {
            if(is_in_prev_button_area((int)mouseX, (int)mouseY))
            {
                if(jeiItemListPage > 0)
                {
                    jeiItemListPage--;
                }
                else
                {
                    jeiItemListPage = jeiItemListTotalPage;
                }
                playButtonClickSound();
            }
            else
                if(is_in_next_button_area((int)mouseX, (int)mouseY))
                {
                    if(jeiItemListPage < jeiItemListTotalPage)
                    {
                        jeiItemListPage++;
                    }
                    else
                    {
                        jeiItemListPage = 0;
                    }
                    playButtonClickSound();
                }
        }
            else
            {
                if(is_in_player_inventory_area((int)mouseX, (int)mouseY))
                {
                    int row = ((int)mouseY - CENTER_GUI_START_Y - 99) / 18;
                    int col = ((int)mouseX - CENTER_GUI_START_X - 7) / 18;
                    ItemStack item = slots.get(9 + row * 9 + col).stack;
                    carriedStack = GenericStack.fromItemStack(item);
                    return true;
                }
                else
                    if(is_in_player_hotbar_area((int)mouseX, (int)mouseY))
                    {
                        int col = ((int)mouseX - CENTER_GUI_START_X - 7) / 18;
                        ItemStack item = slots.get(col).stack;
                        carriedStack = GenericStack.fromItemStack(item);
                        return true;
                    }
                    else
                        if (SNBTLinesCount > RowsPerPage && is_on_SNBT_Slider((int)mouseX, (int)mouseY))
                        {
                            isSNBTSlideSelecting = true;
                            SNBTLineOffsetBeforeMouseClicked = SNBTLineOffset;
                            slideDeltaY = 0;
                        }
            }

        if (is_in_pattern_content_preview_area((int)mouseX, (int)mouseY))
        {
            int panelX = CENTER_GUI_START_X + AE2_PATTERN_PANEL_START_X_IN_CENTER_SCREEN;
            int panelY = CENTER_GUI_START_Y + AE2_PATTERN_PANEL_START_Y_IN_CENTER_SCREEN;
            int relX = (int)mouseX - panelX;
            int relY = (int)mouseY - panelY;
            if (handlePatternSlotClick(relX, relY, button))
            {
                return true;
            }
        }
        else
            if (is_in_pattern_mode_selector_area((int)mouseX, (int)mouseY))
            {
                int row = ((int)mouseY - CENTER_GUI_START_Y - 17) / 18;
                int col = ((int)mouseX - CENTER_GUI_START_X - 133) / 18;
                int index = 2 * row + col;
                String newType = switch (index)
                {
                    case 0 -> "ae2:crafting_pattern";
                    case 1 -> "ae2:processing_pattern";
                    case 2 -> "ae2:smithing_table_pattern";
                    case 3 -> "ae2:stonecutting_pattern";
                    default -> currentPatternType;
                };
                if (!newType.equals(currentPatternType))
                {
                    convertPatternType(newType);
                    syncToTag();
                    playButtonClickSound();
                    return true;
                }
            }

        //处理其他区域
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY)
    {
        if(isSNBTSlideSelecting)
        {
            slideDeltaY += dragY;
            SNBTLineOffset = (int)(Math.min(SNBTLinesCount - RowsPerPage, Math.max(0, SNBTLineOffsetBeforeMouseClicked + slideDeltaY * (SNBTLinesCount - RowsPerPage) / (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32 - (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32) * RowsPerPage / (double)SNBTLinesCount))));

            if (SNBTLineOffset < 0)
            {
                SNBTLineOffset = 0;
            }
            else
                if (SNBTLineOffset > SNBTLinesCount - RowsPerPage)
                {
                    SNBTLineOffset = SNBTLinesCount - RowsPerPage;
                }
        }

        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button)
    {
        isSNBTSlideSelecting = false;
        slideDeltaY = 0;
        return true;
    }

    //鼠标滚轮操作
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        if(is_in_pattern_content_preview_area((int)mouseX, (int)mouseY))
        {
            if (delta > 0)
            {
                if (RendHelper.PROCESSING_ENCODING_PANEL_PAGE > 0)
                {
                    RendHelper.PROCESSING_ENCODING_PANEL_PAGE--;
                }
            }
            else
                if (delta < 0)
                {
                    if (RendHelper.PROCESSING_ENCODING_PANEL_PAGE < 8)
                    {
                        RendHelper.PROCESSING_ENCODING_PANEL_PAGE++;
                    }
                }
        }
        else
            if (is_in_JEI_item_list_screen_area((int)mouseX, (int)mouseY))
            {
                if (delta > 0)
                {
                    if (jeiItemListPage > 0)
                    {
                        jeiItemListPage--;
                    }
                        else
                        {
                            jeiItemListPage = jeiItemListTotalPage;
                        }
                }
                else
                    if (delta < 0)
                    {
                        if (jeiItemListPage < jeiItemListTotalPage)
                        {
                            jeiItemListPage++;
                        }
                            else
                            {
                                jeiItemListPage = 0;
                            }
                    }
            }
            else
                if(is_in_snbt_preview_panel_area((int)mouseX, (int)mouseY))
                {
                    if (delta > 0 && SNBTLineOffset > 0)
                    {
                        SNBTLineOffset--;
                    }
                    else
                        if (delta < 0 && SNBTLineOffset < SNBTLinesCount - RowsPerPage)
                        {
                            SNBTLineOffset++;
                        }
                }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        if (jeiSearchBox.isFocused())
        {
            if (keyCode == 257 || keyCode == 335)
            {//回车键
                jeiSearchBox.setFocused(false);
                return true;
            }
            String oldText = jeiSearchBox.getValue();
            boolean handled = jeiSearchBox.keyPressed(keyCode, scanCode, modifiers);
            String newText = jeiSearchBox.getValue();
            if (!oldText.equals(newText))
            {
                updateJeiFilter(newText);
            }
            return handled;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        if (jeiSearchBox.isFocused())
        {
            String oldText = jeiSearchBox.getValue();
            boolean handled = jeiSearchBox.charTyped(codePoint, modifiers);
            String newText = jeiSearchBox.getValue();
            if (!oldText.equals(newText))
            {
                updateJeiFilter(newText);
            }
            return handled;
        }
        return super.charTyped(codePoint, modifiers);
    }

    private void createButton()
    {
        Button cancelButton = Button.builder(Component.translatable("取消"), button ->
        {
            Minecraft.getInstance().setScreen(previousScreen);
        }).pos(CENTER_GUI_START_X + 133, CENTER_GUI_START_Y + 53).size(36, 16).build();

        Button saveButton = Button.builder(Component.translatable("保存"), button ->
        {
            if (previousScreen instanceof PatternContentAddFromJEIScreen)
            {
                ((PatternContentAddFromJEIScreen) previousScreen).updatePattern(fileIndex, patternIndex, patternTag);
            }
            Minecraft.getInstance().setScreen(previousScreen);
        }).pos(CENTER_GUI_START_X + 133, CENTER_GUI_START_Y + 69).size(36, 16).build();

        Button syncSNBTToPatternButton = Button.builder(Component.translatable("编辑SNBT内容"), button ->
        {
            Minecraft.getInstance().setScreen(new SNBTEditScreen(patternTag, this));
        }).pos(SNBT_PREVIEW_PANEL_SCREEN_START_X + 4, SNBT_PREVIEW_PANEL_SCREEN_START_Y + SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 24).size(SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 8, 20).build();

        addRenderableWidget(cancelButton);
        addRenderableWidget(saveButton);
        addRenderableWidget(syncSNBTToPatternButton);
    }

    //刷新JEI列表（输入物品名称筛选时）
    private void updateJeiFilter(String filter)
    {
        filteredJeiItems.clear();
        if (filter.isEmpty())
        {
            filteredJeiItems.addAll(allJeiItems);
            return;
        }

        String lower = filter.toLowerCase();
        for (GenericStack stack : allJeiItems)
        {
            boolean matched = false;

            //名称搜索
            String name = stack.what().getDisplayName().getString();
            if (name.toLowerCase().contains(lower))
            {
                matched = true;
            }

            //ID搜索
            if (!matched)
            {
                if (stack.what() instanceof AEItemKey itemKey)
                {
                    String id = BuiltInRegistries.ITEM.getKey(itemKey.getItem()).toString();
                    if (id.toLowerCase().contains(lower))
                    {
                        matched = true;
                    }
                }
                else
                    if (stack.what() instanceof AEFluidKey fluidKey)
                    {
                        String id = BuiltInRegistries.FLUID.getKey(fluidKey.getFluid()).toString();
                        if (id.toLowerCase().contains(lower))
                        {
                            matched = true;
                        }
                    }
            }

            //TAG搜索
            if (!matched && stack.what() instanceof AEItemKey itemKey)
            {
                ItemStack itemStack = itemKey.toStack();
                matched = itemStack.getTags().anyMatch(tag ->
                {
                    String tagName = "#" + tag.location();
                    return tagName.toLowerCase().contains(lower);
                });
            }
            else
                if (stack.what() instanceof AEFluidKey fluidKey)
                {
                    Fluid fluid = fluidKey.getFluid();
                    matched = fluid.builtInRegistryHolder().tags().anyMatch(tag ->
                    {
                        String tagName = "#" + tag.location().toString();
                        return tagName.toLowerCase().contains(lower);
                    });
                }

            if (matched)
            {
                filteredJeiItems.add(stack);
            }
        }

        jeiItemListTotalPage = Math.max(0, filteredJeiItems.size() / jeiItemListItemPerPage);
        jeiItemListPage = 0;
    }

    @Override
    public void tick()
    {
        super.tick();
        if (jeiSearchBox != null)
        {
            jeiSearchBox.tick();
        }
    }

    //通过样板Tag初始化
    private void initFromPatternTag()
    {
        if (patternTag == null)
        {
            currentPatternType = "ae2:crafting_pattern";
            convertPatternType(currentPatternType);
            return;
        }
        currentPatternType = patternTag.getString("id");
        CompoundTag tag = patternTag.getCompound("tag");
        //根据类型解析
        if (currentPatternType.equals("ae2:crafting_pattern"))
        {
            currentInputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "in");
            while (currentInputs.size() < 9)
            {
                currentInputs.add(null);
            }
            currentOutputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "out");
            while (currentOutputs.size() < 1)
            {
                currentOutputs.add(null);
            }
        }
        else
            if (currentPatternType.equals("ae2:processing_pattern"))
            {
                currentInputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "in");
                while (currentInputs.size() < 81)
                {
                    currentInputs.add(null);
                }
                currentOutputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "out");
                while (currentOutputs.size() < 27)
                {
                    currentOutputs.add(null);
                }
            }
            else
                if (currentPatternType.equals("ae2:smithing_table_pattern"))
                {
                    currentInputs = new ArrayList<>();
                    //解析输入
                    if (tag.contains("template"))
                    {
                        currentInputs.add(PatternContentHelper.Tag_to_GenericStack(tag.getCompound("template")));
                    }
                        else
                        {
                            currentInputs.add(null);
                        }

                    if (tag.contains("base"))
                    {
                        currentInputs.add(PatternContentHelper.Tag_to_GenericStack(tag.getCompound("base")));
                    }
                        else
                        {
                            currentInputs.add(null);
                        }

                    if (tag.contains("addition"))
                    {
                        currentInputs.add(PatternContentHelper.Tag_to_GenericStack(tag.getCompound("addition")));
                    }
                        else
                        {
                            currentInputs.add(null);
                        }
                    //解析输出
                    currentOutputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "out");
                    while (currentOutputs.size() < 1)
                    {
                        currentOutputs.add(null);
                    }
                }
                else
                    if (currentPatternType.equals("ae2:stonecutting_pattern"))
                    {
                        currentInputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "in");
                        while (currentInputs.size() < 1)
                        {
                            currentInputs.add(null);
                        }
                        currentOutputs = PatternContentHelper.patternTag_to_List_GenericStack(tag, currentPatternType, "out");
                        while (currentOutputs.size() < 1)
                        {
                            currentOutputs.add(null);
                        }
                    }
    }

    //转换样板类型
    private void convertPatternType(String newType)
    {
        //备份当前数据
        List<GenericStack> oldInputs = new ArrayList<>(currentInputs);
        List<GenericStack> oldOutputs = new ArrayList<>(currentOutputs);

        //根据目标类型确定槽位数量
        int targetInputSize, targetOutputSize;
        switch (newType)
        {
            case "ae2:crafting_pattern" ->
            {
                targetInputSize = 9;
                targetOutputSize = 1;
            }
            case "ae2:processing_pattern" ->
            {
                targetInputSize = 81;
                targetOutputSize = 27;
            }
            case "ae2:smithing_table_pattern" ->
            {
                targetInputSize = 3;
                targetOutputSize = 1;
            }
            case "ae2:stonecutting_pattern" ->
            {
                targetInputSize = 1;
                targetOutputSize = 1;
            }
            default ->
            {
                return;
            }
        }

        List<GenericStack> newInputs = new ArrayList<>();
        List<GenericStack> newOutputs = new ArrayList<>();

        //填充输入槽
        for (int i = 0; i < targetInputSize; i++)
        {
            if (i < oldInputs.size())
            {
                newInputs.add(oldInputs.get(i));
            }
                else
                {
                    newInputs.add(null);
                }
        }
        //填充输出槽
        for (int i = 0; i < targetOutputSize; i++)
        {
            if (i < oldOutputs.size())
            {
                newOutputs.add(oldOutputs.get(i));
            }
                else
                {
                    newOutputs.add(null);
                }
        }

        currentInputs = newInputs;
        currentOutputs = newOutputs;
        currentPatternType = newType;
    }

    //同步至Tag
    private void syncToTag()
    {
        CompoundTag tag = new CompoundTag();
        if (currentPatternType.equals("ae2:crafting_pattern"))
        {
            ListTag inList = new ListTag();
            for (GenericStack stack : currentInputs)
            {
                inList.add(PatternContentHelper.GenericStack_to_Tag(stack, false));
            }
            tag.put("in", inList);
            ListTag outList = new ListTag();
            outList.add(PatternContentHelper.GenericStack_to_Tag(currentOutputs.get(0), false));
            tag.put("out", outList);
            //复制原有其他字段
            if (patternTag != null && patternTag.contains("tag"))
            {
                CompoundTag oldTag = patternTag.getCompound("tag");
                if (oldTag.contains("recipe"))
                {
                    tag.putString("recipe", oldTag.getString("recipe"));
                }
                if (oldTag.contains("substitute"))
                {
                    tag.putByte("substitute", oldTag.getByte("substitute"));
                }
                if (oldTag.contains("substituteFluids"))
                {
                    tag.putByte("substituteFluids", oldTag.getByte("substituteFluids"));
                }
            }
                else
                {
                    tag.putByte("substitute", (byte)0);
                    tag.putByte("substituteFluids", (byte)1);
                }
        }
        else
            if (currentPatternType.equals("ae2:processing_pattern"))
            {
                ListTag inList = new ListTag();
                for (GenericStack stack : currentInputs)
                {
                    inList.add(PatternContentHelper.GenericStack_to_Tag(stack, true));
                }
                tag.put("in", inList);
                ListTag outList = new ListTag();
                for (GenericStack stack : currentOutputs)
                {
                    outList.add(PatternContentHelper.GenericStack_to_Tag(stack, true));
                }
                tag.put("out", outList);
            }
            else
                if (currentPatternType.equals("ae2:smithing_table_pattern"))
                {
                    if (currentInputs.size() > 0)
                    {
                        tag.put("template", PatternContentHelper.GenericStack_to_Tag(currentInputs.get(0), false));
                    }
                        else
                        {
                            tag.put("template", new CompoundTag());
                        }

                    if (currentInputs.size() > 1)
                    {
                        tag.put("base", PatternContentHelper.GenericStack_to_Tag(currentInputs.get(1), false));
                    }
                        else
                        {
                            tag.put("base", new CompoundTag());
                        }

                    if (currentInputs.size() > 2)
                    {
                        tag.put("addition", PatternContentHelper.GenericStack_to_Tag(currentInputs.get(2), false));
                    }
                        else
                        {
                            tag.put("addition", new CompoundTag());
                        }

                    if (currentOutputs.size() > 0)
                    {
                        tag.put("out", PatternContentHelper.GenericStack_to_Tag(currentOutputs.get(0), false));
                    }
                        else
                        {
                            tag.put("out", new CompoundTag());
                        }
                    //复制recipe等（如果有）
                    if (patternTag != null && patternTag.contains("tag"))
                    {
                        CompoundTag oldTag = patternTag.getCompound("tag");
                        if (oldTag.contains("recipe"))
                        {
                            tag.putString("recipe", oldTag.getString("recipe"));
                        }
                        if (oldTag.contains("substitute"))
                        {
                            tag.putByte("substitute", oldTag.getByte("substitute"));
                        }
                    }
                }
                else
                    if (currentPatternType.equals("ae2:stonecutting_pattern"))
                    {
                        if (currentInputs.size() > 0)
                        {
                            tag.put("in", PatternContentHelper.GenericStack_to_Tag(currentInputs.get(0), false));
                        }
                            else
                            {
                                tag.put("in", new CompoundTag());
                            }

                        if (currentOutputs.size() > 0)
                        {
                            tag.put("out", PatternContentHelper.GenericStack_to_Tag(currentOutputs.get(0), false));
                        }
                            else
                            {
                                tag.put("out", new CompoundTag());
                            }

                        if (patternTag != null && patternTag.contains("tag"))
                        {
                            CompoundTag oldTag = patternTag.getCompound("tag");
                            if (oldTag.contains("recipe"))
                            {
                                tag.putString("recipe", oldTag.getString("recipe"));
                            }
                            if (oldTag.contains("substitute"))
                            {
                                tag.putByte("substitute", oldTag.getByte("substitute"));
                            }
                        }
                    }
        CompoundTag newPatternTag = new CompoundTag();
        newPatternTag.putString("id", currentPatternType);
        newPatternTag.putByte("Count", (byte)1);
        newPatternTag.put("tag", tag);
        this.patternTag = newPatternTag;
    }

    //样板槽位点击处理
    private boolean handlePatternSlotClick(int x, int y, int button)
    {
        if (currentPatternType == null) return false;
        switch (currentPatternType)
        {
            case "ae2:crafting_pattern":
            {//合成样板：输入槽
                if (is_in_crafting_encoding_input_slot(x, y))
                {
                    int col = (x - 9) / 18;
                    int row = (y - 8) / 18;
                    int index = row * 3 + col;
                    if (index >= 0 && index < 9)
                    {
                        performSlotAction(index, true, button);
                        return true;
                    }
                }
                //输出槽
                if (is_in_crafting_encoding_output_slot(x, y))
                {
                    performSlotAction(0, false, button);
                    return true;
                }
                break;
            }
            case "ae2:processing_pattern":
            {//处理样板：输入槽
                if (is_in_processing_encoding_input_slot(x, y))
                {
                    int col = (x - 17) / 18;
                    int row = (y - 8) / 18;
                    int pageOffset = RendHelper.PROCESSING_ENCODING_PANEL_PAGE * 9;
                    int index = pageOffset + row * 3 + col;
                    if (index >= 0 && index < currentInputs.size())
                    {
                        performSlotAction(index, true, button);
                        return true;
                    }
                }
                //输出槽
                if (is_in_processing_encoding_output_slot(x, y))
                {
                    int row = (y - 8) / 18;
                    int pageOffset = RendHelper.PROCESSING_ENCODING_PANEL_PAGE * 3;
                    int index = pageOffset + row;
                    if (index >= 0 && index < currentOutputs.size())
                    {
                        performSlotAction(index, false, button);
                        return true;
                    }
                }
                break;
            }
            case "ae2:smithing_table_pattern":
            {//锻造台：输入槽
                if (is_in_smithing_table_encoding_template_slot(x, y))
                {
                    performSlotAction(0, true, button);
                    return true;
                }
                else
                    if (is_in_smithing_table_encoding_base_slot(x, y))
                    {
                        performSlotAction(1, true, button);
                        return true;
                    }
                    else
                        if (is_in_smithing_table_encoding_addition_slot(x, y))
                        {
                            performSlotAction(2, true, button);
                            return true;
                        }
                        else//输出槽
                            if (is_in_smithing_table_encoding_output_slot(x, y))
                            {
                                performSlotAction(0, false, button);
                                return true;
                            }
                break;
            }
            case "ae2:stonecutting_pattern":
            {//切石机：输入槽
                if (is_in_stone_cutting_encoding_input_slot(x, y))
                {
                    performSlotAction(0, true, button);
                    return true;
                }
                else//输出槽
                    if (is_in_stone_cutting_encoding_output_slot(x, y))
                    {
                        performSlotAction(0, false, button);
                        return true;
                    }
                break;
            }
        }
        return false;
    }

    //样板槽位操作
    private void performSlotAction(int index, boolean isInput, int button)
    {
        List<GenericStack> list = isInput ? currentInputs : currentOutputs;
        GenericStack current = list.get(index);
        GenericStack newStack = null;

        if (button == 0)
        {//左键
            if (carriedStack != null)
            {
                GenericStack carried = carriedStack;
                if (current == null)
                {
                    newStack = carried;
                }
                else
                    if (current.what().equals(carried.what()))
                    {
                        //同类型，数量相加
                        newStack = new GenericStack(current.what(), current.amount() + carried.amount());
                    }
                        else
                        {
                            //不同类型，覆盖
                            newStack = carried;
                        }
            }
                else
                {
                    //鼠标空，删除槽位物品
                    newStack = null;
                }
        }
        else
            if (button == 1)
            {//右键
                if (carriedStack != null)
                {
                    GenericStack carried = carriedStack;
                    long amountToAdd = 1;

                    //检查鼠标物品是否为流体容器
                    if (carried.what() instanceof AEItemKey itemKey)
                    {
                        ItemStack itemStack = itemKey.toStack();
                        //从物品中提取流体
                        FluidStack fluid = net.minecraftforge.fluids.FluidUtil.getFluidContained(itemStack).orElse(null);
                        if (fluid != null)
                        {
                            //如果是流体容器，使用流体代替物品
                            carried = GenericStack.fromFluidStack(fluid);
                            amountToAdd = fluid.getAmount();
                        }
                    }

                    if (current == null)
                    {
                        //空槽，添加一个
                        newStack = new GenericStack(carried.what(), amountToAdd);
                    }
                    else
                        if (current.what().equals(carried.what()))
                        {
                            //同类型，减少数量（减去鼠标上的数量）
                            long newAmount = current.amount() - carried.amount();
                            if (newAmount <= 0)
                            {
                                newStack = null;
                            }
                                else
                                {
                                    newStack = new GenericStack(current.what(), newAmount);
                                }
                        }
                            else
                            {
                                //不同类型，无效
                                return;
                            }
                }
                    else
                    {
                        //鼠标空，槽位有物品则减1
                        if (current != null)
                        {
                            long newAmount = current.amount() - 1;
                            if (newAmount <= 0)
                            {
                                newStack = null;
                            }
                                else
                                {
                                    newStack = new GenericStack(current.what(), newAmount);
                                }
                        }
                    }
            }
            else
                if (button == 2)
                {//中键
                    if (current != null)
                    {
                        //槽位有物品，弹出数量设置窗口
                        openAmountSetter(index, isInput, current);
                        return; //无需立即更新，回调中会设置
                    }
                    else
                        if (carriedStack != null)
                        {
                            //槽位空，鼠标有物品，添加鼠标物品（数量为鼠标数量）
                            newStack = carriedStack;
                        }
                            else
                            {
                                return;
                            }
                }

        // 更新列表并同步
        if (newStack != null)
        {
            list.set(index, newStack);
        }
            else
            {
                list.set(index, null);
            }
        syncToTag();
    }

    //设置数量
    private void openAmountSetter(int slotIndex, boolean isInput, GenericStack selectedItemStack)
    {
        Minecraft.getInstance().setScreen(new PatternItemAmountSettingScreen(newAmount ->
        {
            GenericStack newStack = new GenericStack(selectedItemStack.what(), newAmount);
            if (isInput)
            {
                currentInputs.set(slotIndex, newStack);
            }
                else
                {
                    currentOutputs.set(slotIndex, newStack);
                }
            syncToTag();
        }, selectedItemStack.amount(), selectedItemStack, this));
    }

    private void JEI_Init()
    {
        if (!jeiListInitialized)
        {
            var jeiRuntime = ModJEIPlugin.getJeiRuntime();
            if (jeiRuntime != null)
            {
                var ingredientManager = jeiRuntime.getIngredientManager();
                // 获取物品
                var allItems = ingredientManager.getAllIngredients(VanillaTypes.ITEM_STACK);
                for (ItemStack stack : allItems)
                {
                    GenericStack gs = GenericStack.fromItemStack(stack);
                    if (gs != null) allJeiItems.add(gs);
                }
                // 获取流体
                for (IIngredientType<?> type : ingredientManager.getRegisteredIngredientTypes())
                {
                    if (type.getIngredientClass() == FluidStack.class)
                    {
                        //@SuppressWarnings("unchecked")
                        Collection<FluidStack> allFluids = (Collection<FluidStack>) ingredientManager.getAllIngredients(type);
                        for (FluidStack fs : allFluids)
                        {
                            GenericStack gs = GenericStack.fromFluidStack(fs);
                            if (gs != null) allJeiItems.add(gs);
                        }
                        break; // 找到后退出循环
                    }
                }
                filteredJeiItems.addAll(allJeiItems);
            }
            jeiListInitialized = true;
        }

        jeiItemListPage = 0;

        //计算每页物品行数和列数
        jeiItemListColPerPage = Math.max(1, (JEI_ITEM_LIST_SCREEN_WIDTH - 6) / 18);
        jeiItemListRowPerPage = Math.max(1, (JEI_ITEM_LIST_SCREEN_HEIGHT - 41) / 18);
        jeiItemListItemPerPage = jeiItemListColPerPage * jeiItemListRowPerPage;
        jeiItemListTotalPage = filteredJeiItems.size() / jeiItemListItemPerPage;

        jeiItemListStartX = JEI_ITEM_LIST_SCREEN_START_X + JEI_ITEM_LIST_SCREEN_WIDTH / 2 - jeiItemListColPerPage * 18 / 2;
        jeiItemListStartY = JEI_ITEM_LIST_SCREEN_START_Y - 3 + JEI_ITEM_LIST_SCREEN_HEIGHT / 2 - jeiItemListRowPerPage * 18 / 2;

        //创建搜索框（位于右侧底部）
        jeiSearchBox = new EditBox(this.font, JEI_ITEM_LIST_SCREEN_START_X + 8, height - 18, JEI_ITEM_LIST_SCREEN_WIDTH - 16, 16, Component.literal(""));
        jeiSearchBox.setMaxLength(255);
        jeiSearchBox.setBordered(false);
        jeiSearchBox.setTextColor(0xFFFFFF);
        jeiSearchBox.setVisible(true);
        jeiSearchBox.setCanLoseFocus(true);
        addRenderableWidget(jeiSearchBox);
    }

    private void rendJEIItemList(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        for (int i = 0; i < jeiItemListItemPerPage; i++)
        {
            int jeiItemListNowPageStartIndex = jeiItemListPage * jeiItemListItemPerPage + i;
            if (jeiItemListNowPageStartIndex >= filteredJeiItems.size())
            {
                break;
            }

            int row = i / jeiItemListColPerPage;
            int col = i % jeiItemListColPerPage;
            int x = jeiItemListStartX + col * 18 + 1;
            int y = jeiItemListStartY + row * 18 + 1;
            GenericStack stack = filteredJeiItems.get(jeiItemListNowPageStartIndex);
            GUIBackgroundRendHelper.rendSlot(guiGraphics, x - 1, y - 1);
            RendHelper.rendItemOrFluid(guiGraphics, stack, x, y);

            //鼠标悬停高亮和tooltip
            if (mouseX >= x - 1 && mouseX < x + 17 && mouseY >= y - 1 && mouseY < y + 17)
            {
                RendHelper.rendSlotBeSelectedEffect(guiGraphics, x, y);
                RendHelper.rendItemOrFluidTooltip(guiGraphics, stack, mouseX, mouseY);
            }
        }
    }

    //内部槽位类
    private static class Slot
    {
        final int index;
        final int x, y;
        ItemStack stack;
        Slot(int index, int x, int y)
        {
            this.index = index; this.x = x; this.y = y;
        }
    }

    private void rendButtonHoverStatus(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if(is_in_prev_button_area(mouseX, mouseY))
        {
            guiGraphics.blit(PREV_BUTTON_HOVER, JEI_ITEM_LIST_SCREEN_START_X + 6, JEI_ITEM_LIST_SCREEN_START_Y + 4, 0, 0, 13, 13, 13, 13);
        }
        else
            if(is_in_next_button_area(mouseX, mouseY))
            {
                guiGraphics.blit(NEXT_BUTTON_HOVER, width - 19, JEI_ITEM_LIST_SCREEN_START_Y + 4, 0, 0, 13, 13, 13, 13);
            }
    }

    //更新槽位物品
    private void updateInventorySlotItem()
    {
        for (Slot slot : slots)
        {
            slot.stack = player.getInventory().getItem(slot.index);
        }
    }

    //渲染物品
    private void rendItemAndTooltip(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        for (Slot slot : slots)
        {
            if (!slot.stack.isEmpty())
            {
                guiGraphics.renderItem(slot.stack, slot.x, slot.y);
                if (slot.stack.getCount() > 1)
                {
                    guiGraphics.renderItemDecorations(font, slot.stack, slot.x, slot.y);
                }
            }
        }

        //渲染物品槽位选中效果和tooltip
        if(is_in_player_inventory_area(mouseX, mouseY))
        {
            int row = (mouseY - CENTER_GUI_START_Y - 99) / 18;
            int col = (mouseX - CENTER_GUI_START_X - 7) / 18;
            RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 8 + col * 18, CENTER_GUI_START_Y + 100 + row * 18);
            guiGraphics.renderTooltip(font, slots.get(9 + row * 9 + col).stack, mouseX, mouseY);
        }
        else
            if(is_in_player_hotbar_area(mouseX, mouseY))
            {
                int col = (mouseX - CENTER_GUI_START_X - 7) / 18;
                RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 8 + col * 18, CENTER_GUI_START_Y + 158);
                guiGraphics.renderTooltip(font, slots.get(col).stack, mouseX, mouseY);
            }
    }

    //添加玩家物品栏
    private void addPlayerInventorySlots()
    {
        //添加快捷栏槽位（1行9列）
        for (int col = 0; col < 9; ++col)
        {
            slots.add(new Slot(col, CENTER_GUI_START_X + 8 + col * 18, CENTER_GUI_START_Y + 158));
        }

        //添加玩家背包槽位（3行9列）
        for (int row = 0; row < 3; ++row)
        {
            for (int col = 0; col < 9; ++col)
            {
                slots.add(new Slot(col + row * 9 + 9, CENTER_GUI_START_X + 8 + col * 18, CENTER_GUI_START_Y + 100 + row * 18));
            }
        }
    }

    //绘制样板内容预览和样板模式预览
    private void rendPatternContentPreviewAndPatternModePreview(GuiGraphics guiGraphics, int x, int y, int mouseX, int mouseY)
    {
        //使用currentInputs和currentOutputs作为物品数据
        List<GenericStack> inputStack = currentInputs;
        List<GenericStack> outputStack = currentOutputs;

        //从原始NBT中获取物品ID用于显示错误物品的ID和tooltip
        List<String> inputItemId = new ArrayList<>();
        List<String> outputItemId = new ArrayList<>();
        if (patternTag != null)
        {
            CompoundTag tag = patternTag.getCompound("tag");
            inputItemId = PatternContentHelper.patternTag_to_List_String(tag, currentPatternType, "in");
            outputItemId = PatternContentHelper.patternTag_to_List_String(tag, currentPatternType, "out");
        }

        //渲染面板和物品
        RendHelper.rendAE2PatternPanelAndItemAndTooltip(guiGraphics, currentPatternType, inputStack, inputItemId, outputStack, outputItemId, x, y, mouseX, mouseY);

        //绘制模式选择图标
        guiGraphics.renderItem(new ItemStack(Items.CRAFTING_TABLE), CENTER_GUI_START_X + 134, CENTER_GUI_START_Y + 18);
        guiGraphics.renderItem(new ItemStack(Items.FURNACE), CENTER_GUI_START_X + 152, CENTER_GUI_START_Y + 18);
        guiGraphics.renderItem(new ItemStack(Items.SMITHING_TABLE), CENTER_GUI_START_X + 134, CENTER_GUI_START_Y + 36);
        guiGraphics.renderItem(new ItemStack(Items.STONECUTTER), CENTER_GUI_START_X + 152, CENTER_GUI_START_Y + 36);

        //高亮当前选中类型
        if (currentPatternType != null)
        {
            switch (currentPatternType)
            {
                case "ae2:crafting_pattern":
                    RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 134, CENTER_GUI_START_Y + 18);
                    break;
                case "ae2:processing_pattern":
                    RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 152, CENTER_GUI_START_Y + 18);
                    break;
                case "ae2:smithing_table_pattern":
                    RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 134, CENTER_GUI_START_Y + 36);
                    break;
                case "ae2:stonecutting_pattern":
                    RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 152, CENTER_GUI_START_Y + 36);
                    break;
            }
        }

        // 模式选择器 tooltip
        if (is_in_pattern_mode_selector_area(mouseX, mouseY))
        {
            int row = (mouseY - CENTER_GUI_START_Y - 17) / 18;
            int col = (mouseX - CENTER_GUI_START_X - 133) / 18;
            int index = 2 * row + col;
            RendHelper.rendSlotBeSelectedEffect(guiGraphics, CENTER_GUI_START_X + 134 + col * 18, CENTER_GUI_START_Y + 18 + row * 18);
            String tooltip = switch (index)
            {
                case 0 -> "合成样板";
                case 1 -> "处理样板";
                case 2 -> "锻造台样板";
                case 3 -> "切石机样板";
                default -> "";
            };
            guiGraphics.renderTooltip(font, Component.translatable(tooltip), mouseX, mouseY);
        }
    }

    //绘制SNBT
    private void rendSNBT(GuiGraphics guiGraphics)
    {
        if (patternTag == null)
        {
            guiGraphics.drawString(font, "<NBT内容为空>", SNBT_PREVIEW_PANEL_SCREEN_START_X + 6, SNBT_PREVIEW_PANEL_SCREEN_START_Y + 6, 0xFF0000, false);
            return;
        }

        int startX = SNBT_PREVIEW_PANEL_SCREEN_START_X + 6;
        int startY = SNBT_PREVIEW_PANEL_SCREEN_START_Y + 6;
        maxWidth = SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 12;
        RowsPerPage = Math.max(1, (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 31) / fontLineHeight);

        List<String> allString = new ArrayList<>();
        nowLineIndex = 1;
        //格式化展开SNBT
        formatSNBT(patternTag, 0, allString);
        SNBTLinesCount = allString.size();

        if (SNBTLinesCount > RowsPerPage)
        {
            maxWidth = SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 19;

            allString = new ArrayList<>();
            nowLineIndex = 1;
            formatSNBT(patternTag, 0, allString);
            SNBTLinesCount = allString.size();

            int sliderHeight = (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32) * RowsPerPage / SNBTLinesCount;

            GUIBackgroundRendHelper.rendAE2SlideBackground(guiGraphics, SNBT_PREVIEW_PANEL_SCREEN_START_X + SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 14, SNBT_PREVIEW_PANEL_SCREEN_START_Y + 5, SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 30);
            GUIBackgroundRendHelper.rendAE2Slider(guiGraphics, SNBT_PREVIEW_PANEL_SCREEN_START_X + SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 13, SNBT_PREVIEW_PANEL_SCREEN_START_Y + 6 + SNBTLineOffset * (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32 - sliderHeight) / (SNBTLinesCount - RowsPerPage), sliderHeight);
        }

        for(int i = SNBTLineOffset; i < SNBTLineOffset + RowsPerPage; i++)
        {
            if (i < SNBTLinesCount)
            {
                guiGraphics.drawString(font, allString.get(i), startX, startY + (i - SNBTLineOffset) * fontLineHeight, 0xFFFFFF, false);
            }
            else
                {
                    break;
                }
        }
    }

    private void formatSNBT(CompoundTag tag, int indentationCount, List<String> lines)
    {
        if (tag.isEmpty())
        {
            addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount) + "{}");
            return;
        }

        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount) + "{");
        for (String key : tag.getAllKeys())
        {
            Tag value = tag.get(key);
            String prefix = addIndentation(indentationCount + 1) + key + ": ";
            if (value instanceof CompoundTag)
            {
                addLineContent(lines, String.format("%04d", nowLineIndex) + " " + prefix);
                formatSNBT((CompoundTag) value, indentationCount + 1, lines);
            }
            else
                if (value instanceof ListTag)
                {
                    addLineContent(lines, String.format("%04d", nowLineIndex) + " " + prefix);
                    formatList((ListTag) value, indentationCount + 1, lines);
                }
                else
                    if (value != null)
                    {
                        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + prefix + value.getAsString());
                    }
                        else
                        {
                            addLineContent(lines, String.format("%04d", nowLineIndex) + " " + prefix);
                        }
        }
        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount) + "}");
    }

    private void formatList(ListTag list, int indentationCount, List<String> lines)
    {
        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount) + "[");
        for (int i = 0; i < list.size(); i++)
        {
            Tag element = list.get(i);
            if (element instanceof CompoundTag)
            {
                formatSNBT((CompoundTag) element, indentationCount + 1, lines);
            }
            else
                if (element instanceof ListTag)
                {
                    formatList((ListTag) element, indentationCount + 1, lines);
                }
                    else
                    {
                        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount + 1) + element.getAsString());
                    }
        }
        addLineContent(lines, String.format("%04d", nowLineIndex) + " " + addIndentation(indentationCount) + "]");
    }

    private String addIndentation(int indentationCount)
    {
        return String.join("", java.util.Collections.nCopies(indentationCount, "    "));
    }

    private void addLineContent(List<String> lines, String content)
    {
        if (font.width(content) <= Math.max(6, maxWidth))
        {
            lines.add(content);
        }
        else
            {
                String trimmed;
                while(!content.isEmpty())
                {
                    trimmed = font.plainSubstrByWidth(content, Math.max(6, maxWidth));
                    content = content.substring(trimmed.length());
                    lines.add(trimmed);
                }
            }
        nowLineIndex++;
    }

    //回调函数
    public void updatePatternTag(CompoundTag newTag)
    {
        this.patternTag = newTag;
        initFromPatternTag(); // 重新初始化缓存
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }

    //返回到前一个屏幕
    @Override
    public void onClose()
    {
        Minecraft.getInstance().setScreen(previousScreen);
    }

    //播放按钮点击声音
    private void playButtonClickSound()
    {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    //是否在玩家物品栏中(不包含快捷栏)
    private boolean is_in_player_inventory_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + 7 && x <= CENTER_GUI_START_X + 168 && y >= CENTER_GUI_START_Y + 99 && y <= CENTER_GUI_START_Y + 152;
    }

    //是否在玩家快捷栏中
    private boolean is_in_player_hotbar_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + 7 && x <= CENTER_GUI_START_X + 168 && y >= CENTER_GUI_START_Y + 157 && y <= CENTER_GUI_START_Y + 174;
    }

    private boolean is_in_JEI_item_list_screen_area(int x, int y)
    {
        return x >= JEI_ITEM_LIST_SCREEN_START_X && x <= JEI_ITEM_LIST_SCREEN_START_X + JEI_ITEM_LIST_SCREEN_WIDTH - 1;
    }

    private boolean is_in_JEI_item_area(int x, int y)
    {
        return x >= jeiItemListStartX && x <= jeiItemListStartX + jeiItemListColPerPage * 18 - 1 && y >= jeiItemListStartY && y <= jeiItemListStartY + jeiItemListRowPerPage * 18 - 1;
    }

    private boolean is_in_prev_button_area(int x, int y)
    {
        return x >= JEI_ITEM_LIST_SCREEN_START_X + 6 && x <= JEI_ITEM_LIST_SCREEN_START_X + 18 && y >= JEI_ITEM_LIST_SCREEN_START_Y + 4 && y <= JEI_ITEM_LIST_SCREEN_START_Y + 16;
    }

    private boolean is_in_next_button_area(int x, int y)
    {
        return x >= width - 18 && x <= width - 6 && y >= JEI_ITEM_LIST_SCREEN_START_Y + 4 && y <= JEI_ITEM_LIST_SCREEN_START_Y + 16;
    }

    private boolean is_in_snbt_preview_panel_area(int x, int y)
    {
        return x >= SNBT_PREVIEW_PANEL_SCREEN_START_X && x <= SNBT_PREVIEW_PANEL_SCREEN_START_X + SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 1;
    }

    private boolean is_in_pattern_content_preview_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + 7 && x <= CENTER_GUI_START_X + 133 && y >= CENTER_GUI_START_Y + 17 && y <= CENTER_GUI_START_Y + 85;
    }

    private boolean is_in_pattern_mode_selector_area(int x, int y)
    {
        return x >= CENTER_GUI_START_X + 133 && x <= CENTER_GUI_START_X + 168 && y >= CENTER_GUI_START_Y + 17 && y <= CENTER_GUI_START_Y + 52;
    }

    private boolean is_on_SNBT_Slider(int x, int y)
    {
        return x >= SNBT_PREVIEW_PANEL_SCREEN_START_X + SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 13 && x <= SNBT_PREVIEW_PANEL_SCREEN_START_X + SNBT_PREVIEW_PANEL_SCREEN_WIDTH - 7 && y >= SNBT_PREVIEW_PANEL_SCREEN_START_Y + 6 + SNBTLineOffset * (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32 - (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32) * RowsPerPage / SNBTLinesCount) / (SNBTLinesCount - RowsPerPage) && y <= SNBT_PREVIEW_PANEL_SCREEN_START_Y + 6 + SNBTLineOffset * (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32 - (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32) * RowsPerPage / SNBTLinesCount) + (SNBT_PREVIEW_PANEL_SCREEN_HEIGHT - 32) * RowsPerPage / SNBTLinesCount;
    }

    private boolean is_in_crafting_encoding_input_slot(int x, int y)
    {
        return x >= 8 && x <= 61 && y >= 7 && y <= 60;
    }

    private boolean is_in_crafting_encoding_output_slot(int x, int y)
    {
        return x >= 101 && x <= 116 && y >= 26 && y <= 41;
    }

    private boolean is_in_processing_encoding_input_slot(int x, int y)
    {
        return x >= 16 && x <= 69 && y >= 7 && y <= 60;
    }

    private boolean is_in_processing_encoding_output_slot(int x, int y)
    {
        return x >= 100 && x <= 115 && y >= 7 && y <= 60;
    }

    private boolean is_in_smithing_table_encoding_template_slot(int x, int y)
    {
        return x >= 11 && x <= 28 && y >= 25 && y <= 42;
    }

    private boolean is_in_smithing_table_encoding_base_slot(int x, int y)
    {
        return x >= 29 && x <= 46 && y >= 25 && y <= 42;
    }

    private boolean is_in_smithing_table_encoding_addition_slot(int x, int y)
    {
        return x >= 47 && x <= 64 && y >= 25 && y <= 42;
    }

    private boolean is_in_smithing_table_encoding_output_slot(int x, int y)
    {
        return x >= 101 && x <= 118 && y >= 25 && y <= 42;
    }

    private boolean is_in_stone_cutting_encoding_input_slot(int x, int y)
    {
        return x >= 11 && x <= 28 && y >= 24 && y <= 41;
    }

    private boolean is_in_stone_cutting_encoding_output_slot(int x, int y)
    {
        return x >= 44 && x <= 59 && y >= 7 && y <= 24;
    }
}