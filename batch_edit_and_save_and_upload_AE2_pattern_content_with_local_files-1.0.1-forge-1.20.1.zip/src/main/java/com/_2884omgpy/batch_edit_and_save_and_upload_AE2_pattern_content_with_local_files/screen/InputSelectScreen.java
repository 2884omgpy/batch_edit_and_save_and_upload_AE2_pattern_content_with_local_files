package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen;

import appeng.api.stacks.GenericStack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.RendHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class InputSelectScreen extends Screen
{
    public static final ResourceLocation INPUT_SELECT_SCREEN_TEXTURE = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/input_select_screen.png");
    private final List<PatternContentHelper.InputSlotInfo> inputSlotInfos;
    private final List<PatternContentHelper.OutputSlotInfo> outputSlotInfos;
    private final Screen previousScreen;
    private final String patternType;
    private final Object recipe;
    private final Consumer<CompoundTag> onConfirm;

    private int shouldChooseItemSlotIndex = 0;
    private List<GenericStack> canSelectedInputItemsFromTag;
    private List<GenericStack> canSelectedOutputItemsFromTag;

    private int currentDisplayIndex = 0;
    private int candidatesOffset = 0;
    private List<GenericStack> currentCandidates;

    private static int GUI_START_X = 0;
    private static int GUI_START_Y = 0;

    public InputSelectScreen(List<PatternContentHelper.InputSlotInfo> inputSlotInfos, List<PatternContentHelper.OutputSlotInfo> outputSlotInfos, String patternType, Object recipe, Consumer<CompoundTag> onConfirm, Screen previousScreen)
    {
        super(Component.translatable("原材料选择"));
        this.inputSlotInfos = inputSlotInfos;
        this.outputSlotInfos = outputSlotInfos;
        this.patternType = patternType;
        this.recipe = recipe;
        this.onConfirm = onConfirm;
        this.previousScreen = previousScreen;

        this.canSelectedInputItemsFromTag = new ArrayList<>();
        this.canSelectedOutputItemsFromTag = new ArrayList<>();

        for (PatternContentHelper.InputSlotInfo info : inputSlotInfos)
        {
            if(info.candidates != null)
            {
                if (info.candidates.size() == 1)
                {
                    canSelectedInputItemsFromTag.add(info.candidates.get(0));
                }
                    else
                    {
                        canSelectedInputItemsFromTag.add(null); // 待选
                    }
            }
                else
                {
                    canSelectedInputItemsFromTag.add(null);
                }
        }

        for (PatternContentHelper.OutputSlotInfo info : outputSlotInfos)
        {
            if(info.candidates != null)
            {
                if (info.candidates.size() == 1)
                {
                    canSelectedOutputItemsFromTag.add(info.candidates.get(0));
                }
                    else
                    {
                        canSelectedOutputItemsFromTag.add(null); // 待选
                    }
            }
                else
                {
                    canSelectedOutputItemsFromTag.add(null);
                }
        }

        //找到第一个未选择的槽位（先输入后输出）
        for (int i = 0; i < canSelectedInputItemsFromTag.size() + canSelectedOutputItemsFromTag.size(); i++)
        {
            if (i < canSelectedInputItemsFromTag.size())
            {
                if (canSelectedInputItemsFromTag.get(i) == null)
                {
                    shouldChooseItemSlotIndex = i;
                    break;
                }
            }
                else
                {
                    if (canSelectedOutputItemsFromTag.get(i - canSelectedInputItemsFromTag.size()) == null)
                    {
                        shouldChooseItemSlotIndex = i;
                        break;
                    }
                }
        }
    }

    @Override
    protected void init()
    {
        super.init();
        GUI_START_X = width / 2 - 88;
        GUI_START_Y = height / 2 - 111;

        if (!inputSlotInfos.isEmpty() || !outputSlotInfos.isEmpty())
        {
            updateCandidatesForCurrentSlot(shouldChooseItemSlotIndex);
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        renderBackground(guiGraphics);
        guiGraphics.blit(INPUT_SELECT_SCREEN_TEXTURE, GUI_START_X, GUI_START_Y, 0, 0, 176, 222, 176, 222);

        if (is_in_candidate_item_slot_area(mouseX, mouseY))
        {
            rendMouseHoveredItemEffectAndToolTips(guiGraphics, mouseX, mouseY);
        }
        else
            if (is_in_tag_item_slot_area(mouseX, mouseY))
            {
                RendHelper.rendSlotBeSelectedEffect(guiGraphics, GUI_START_X + 8, GUI_START_Y + 27);
                RendHelper.rendItemOrFluidTooltip(guiGraphics, currentCandidates.get(currentDisplayIndex), mouseX, mouseY);
            }

        if (currentCandidates != null && !currentCandidates.isEmpty())
        {
            RendHelper.rendItemOrFluid(guiGraphics, currentCandidates.get(currentDisplayIndex), GUI_START_X + 8, GUI_START_Y + 27);
        }

        if (!inputSlotInfos.isEmpty() || !outputSlotInfos.isEmpty())
        {
            guiGraphics.drawCenteredString(font, (shouldChooseItemSlotIndex + 1) + "/" + (inputSlotInfos.size() + outputSlotInfos.size()), GUI_START_X + 88, GUI_START_Y + 7, 0xFFFFFF);

            guiGraphics.drawString(font, Component.translatable("请在以下槽位中选择原材料/产物"), GUI_START_X + 31, GUI_START_Y + 31, 0xFFFFFF);

            for (int i = candidatesOffset * 9; i < candidatesOffset * 9 + 81; i++)
            {
                int row = i / 9 - candidatesOffset;
                int col = i % 9;

                if (i < currentCandidates.size())
                {
                    RendHelper.rendItemOrFluid(guiGraphics, currentCandidates.get(i), GUI_START_X + 8 + col * 18, GUI_START_Y + 54 + row * 18);
                }
                    else
                    {
                        break;
                    }
            }
        }
            else
            {
                guiGraphics.drawString(font, Component.translatable("该配方没有需要进行选择的原材料"), GUI_START_X + 31, GUI_START_Y + 31, 0xFFFFFF);
            }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    private void updateCandidatesForCurrentSlot(int index)
    {
        candidatesOffset = 0;
        if (index < inputSlotInfos.size())
        {
            if (inputSlotInfos.get(index).candidates != null)
            {
                if(inputSlotInfos.get(index).candidates.size() >= 2)
                {
                    currentCandidates = inputSlotInfos.get(index).candidates;
                }
                    else
                    {
                        advanceToNextSlot();
                    }
            }
                else
                {
                    advanceToNextSlot();
                }
        }
        else
            if(index - inputSlotInfos.size() < outputSlotInfos.size())
            {
                int outputSlotIndex = index - inputSlotInfos.size();
                if (outputSlotInfos.get(outputSlotIndex).candidates != null)
                {
                    if(outputSlotInfos.get(outputSlotIndex).candidates.size() >= 2)
                    {
                        currentCandidates = outputSlotInfos.get(outputSlotIndex).candidates;
                    }
                        else
                        {
                            advanceToNextSlot();
                        }
                }
                    else
                    {
                        advanceToNextSlot();
                    }
            }

        if (currentCandidates != null)
        {
            currentDisplayIndex = 0;
        }
    }

    private void rendMouseHoveredItemEffectAndToolTips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        int row = (mouseY - GUI_START_Y - 53) / 18;
        int col = (mouseX - GUI_START_X - 7) / 18;
        int index = candidatesOffset * 9 + row * 9 + col;

        RendHelper.rendSlotBeSelectedEffect(guiGraphics, GUI_START_X + 8 + col * 18, GUI_START_Y + 54 + row * 18);
        if (currentCandidates != null)
        {
            if (index >= 0 && index < currentCandidates.size())
            {
                RendHelper.rendItemOrFluidTooltip(guiGraphics, currentCandidates.get(index), mouseX, mouseY);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        if (is_in_candidate_item_slot_area((int)mouseX, (int)mouseY))
        {
            int row = ((int)mouseY - GUI_START_Y - 53) / 18;
            int col = ((int)mouseX - GUI_START_X - 7) / 18;
            int index = candidatesOffset * 9 + row * 9 + col;
            if (currentCandidates != null)
            {
                if (index >= 0 && index < currentCandidates.size())
                {
                    if (shouldChooseItemSlotIndex < inputSlotInfos.size())
                    {
                        canSelectedInputItemsFromTag.set(shouldChooseItemSlotIndex, currentCandidates.get(index));
                    }
                    else
                        if (shouldChooseItemSlotIndex - inputSlotInfos.size() < outputSlotInfos.size())
                        {
                            canSelectedOutputItemsFromTag.set(shouldChooseItemSlotIndex - inputSlotInfos.size(), currentCandidates.get(index));
                        }
                    advanceToNextSlot();
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        if (is_in_candidate_item_slot_area((int)mouseX, (int)mouseY))
        {
            if (delta > 0)
            {
                if (candidatesOffset > 0)
                {
                    candidatesOffset--;
                }
            }
            else
                if (delta < 0)
                {
                    if (candidatesOffset * 9 + 81 < currentCandidates.size())
                    {
                        candidatesOffset++;
                    }
                }
        }

        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    private void advanceToNextSlot()
    {
        if (shouldChooseItemSlotIndex < inputSlotInfos.size() + outputSlotInfos.size() - 1)
        {
            shouldChooseItemSlotIndex++;
            updateCandidatesForCurrentSlot(shouldChooseItemSlotIndex);
        }
            else
            {
                CompoundTag finalNBT = PatternContentHelper.inputAndOutputAndPatternTypeAndRecipeToPatternNBT(canSelectedInputItemsFromTag, canSelectedOutputItemsFromTag, patternType, recipe);
                onConfirm.accept(finalNBT);
                onClose();
            }
    }

    @Override
    public void tick()
    {
        super.tick();
        if (currentCandidates != null && currentCandidates.size() > 1)
        {
            if (currentDisplayIndex < currentCandidates.size() - 1)
            {
                currentDisplayIndex++;
            }
                else
                {
                    currentDisplayIndex = 0;
                }
        }
            else
            {
                currentDisplayIndex = 0;
            }
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }

    @Override
    public void onClose()
    {
        Minecraft.getInstance().setScreen(previousScreen);
    }

    private boolean is_in_tag_item_slot_area(int mouseX, int mouseY)
    {
        return mouseX >= GUI_START_X + 7 && mouseX <= GUI_START_X + 24 && mouseY >= GUI_START_Y + 26 && mouseY <= GUI_START_Y + 43;
    }

    private boolean is_in_candidate_item_slot_area(int mouseX, int mouseY)
    {
        return mouseX >= GUI_START_X + 7 && mouseX <= GUI_START_X + 168 && mouseY >= GUI_START_Y + 53 && mouseY <= GUI_START_Y + 214;
    }
}