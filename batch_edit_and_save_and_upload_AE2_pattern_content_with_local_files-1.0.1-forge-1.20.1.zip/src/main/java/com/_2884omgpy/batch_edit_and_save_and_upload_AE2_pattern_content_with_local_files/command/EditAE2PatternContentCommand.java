package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen.PatternContentAddFromJEIScreen;

public class EditAE2PatternContentCommand
{
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher)
    {
        dispatcher.register(Commands.literal("editae2patterncontent").executes(EditAE2PatternContentCommand::execute));
    }

    private static int execute(CommandContext<CommandSourceStack> context)
    {   //仅客户端执行
        if (context.getSource().getEntity().level().isClientSide)
        {
            Minecraft.getInstance().setScreen(new PatternContentAddFromJEIScreen());
        }
        return 1;
    }
}