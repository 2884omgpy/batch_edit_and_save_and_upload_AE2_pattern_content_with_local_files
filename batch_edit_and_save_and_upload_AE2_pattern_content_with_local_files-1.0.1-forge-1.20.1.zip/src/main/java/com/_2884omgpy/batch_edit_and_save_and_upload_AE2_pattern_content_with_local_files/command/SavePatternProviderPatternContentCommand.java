package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.command;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.common.ForgeMod;

import java.util.ArrayList;
import java.util.List;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.network.OpenScreenWithPatternsPacket;
import net.minecraftforge.network.NetworkDirection;

public class SavePatternProviderPatternContentCommand
{
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher)
    {
        dispatcher.register(Commands.literal("savepatternproviderpatterncontent").executes(SavePatternProviderPatternContentCommand::execute));
    }

    private static int execute(CommandContext<CommandSourceStack> context)
    {
        var source = context.getSource();
        var player = source.getPlayer();
        if (player == null)
        {
            source.sendFailure(Component.translatable("只有玩家才能执行此命令"));
            return 0;
        }
        var level = player.level();
        double reachDistance = player.getAttributeValue(ForgeMod.BLOCK_REACH.get());
        var hitResult = player.pick(reachDistance, 0.0F, false);
        if (hitResult instanceof BlockHitResult blockHit)
        {
            BlockPos pos = blockHit.getBlockPos();
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity != null)
            {
                //获取方块实体的 NBT
                CompoundTag nbt = blockEntity.saveWithoutMetadata();

                //递归提取所有样板
                List<CompoundTag> patternTags = PatternContentHelper.extractPatternsFromNBT(nbt);
                if (patternTags.isEmpty())
                {
                    source.sendFailure(Component.translatable("该容器内没有样板"));
                    return 0;
                }

                //标准化每个样板
                List<CompoundTag> normalizedTags = new ArrayList<>();
                for (CompoundTag tag : patternTags)
                {
                    CompoundTag normalized = PatternContentHelper.normalizePattern(tag);
                    normalizedTags.add(normalized);
                }

                if (normalizedTags.isEmpty())
                {
                    source.sendFailure(Component.translatable("没有有效的样板数据"));
                    return 0;
                }
                //发送网络包
                BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.CHANNEL.sendTo(new OpenScreenWithPatternsPacket(normalizedTags), player.connection.connection, NetworkDirection.PLAY_TO_CLIENT);
                source.sendSuccess(() -> Component.translatable("已将样板内容保存至缓存"), false);
            }
                else
                {
                    source.sendFailure(Component.translatable("该方块不是容器"));
                }
        }
            else
            {
                source.sendFailure(Component.translatable("未找到目标方块"));
            }
        return 1;
    }
}