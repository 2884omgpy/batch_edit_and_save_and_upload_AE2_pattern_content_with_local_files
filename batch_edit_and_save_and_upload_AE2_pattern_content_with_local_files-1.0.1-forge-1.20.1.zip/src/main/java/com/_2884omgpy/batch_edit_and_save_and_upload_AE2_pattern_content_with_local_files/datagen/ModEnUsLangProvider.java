package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.datagen;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.LanguageProvider;

public class ModEnUsLangProvider extends LanguageProvider
{
    public ModEnUsLangProvider(PackOutput output)
    {
        super(output, BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID,"en_us");
    }

    @Override
    protected void addTranslations()
    {
        add("","");
    }
}