package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.datagen;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.concurrent.CompletableFuture;

@Mod.EventBusSubscriber(modid = BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModDataGenerater
{
    @SubscribeEvent
    public static void gatherData(GatherDataEvent event) {
        DataGenerator generator = event.getGenerator();
        PackOutput packOutput = generator.getPackOutput();
        ExistingFileHelper existingFileHelper = event.getExistingFileHelper();
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();

        //客户端数据生成
        if (event.includeClient())
        {
            generator.addProvider(true, new ModEnUsLangProvider(packOutput));
            generator.addProvider(true, new ModZhCnLangProvider(packOutput));
            generator.addProvider(true, new ModZhTwLangProvider(packOutput));
            generator.addProvider(true, new ModRuRuLangProvider(packOutput));
            generator.addProvider(true, new ModJaJpLangProvider(packOutput));
            generator.addProvider(true, new ModKoKrLangProvider(packOutput));
        }
    }
}