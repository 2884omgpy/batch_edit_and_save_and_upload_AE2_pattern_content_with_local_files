package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.network;

import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class OpenScreenWithPatternsPacket
{
    private final List<CompoundTag> patterns;

    public OpenScreenWithPatternsPacket(List<CompoundTag> patterns)
    {
        this.patterns = patterns;
    }

    public static void encode(OpenScreenWithPatternsPacket msg, FriendlyByteBuf buffer)
    {
        CompoundTag compoundTag = new CompoundTag();
        ListTag listTag = new ListTag();
        for (CompoundTag tag : msg.patterns)
        {
            listTag.add(tag);
        }
        compoundTag.put("patterns", listTag);
        buffer.writeNbt(compoundTag);
    }

    public static OpenScreenWithPatternsPacket decode(FriendlyByteBuf buffer)
    {
        CompoundTag compoundTag = buffer.readNbt();
        List<CompoundTag> patterns = new ArrayList<>();
        if (compoundTag != null && compoundTag.contains("patterns", Tag.TAG_LIST))
        {
            ListTag list = compoundTag.getList("patterns", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size(); i++)
            {
                patterns.add(list.getCompound(i));
            }
        }
        return new OpenScreenWithPatternsPacket(patterns);
    }

    public static void handle(OpenScreenWithPatternsPacket msg, Supplier<NetworkEvent.Context> context)
    {   //在客户端打开屏幕
        context.get().enqueueWork(() ->
        {
            net.minecraft.client.Minecraft.getInstance().setScreen(new com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen.PatternContentAddFromJEIScreen(msg.patterns));
        });
        context.get().setPacketHandled(true);
    }
}