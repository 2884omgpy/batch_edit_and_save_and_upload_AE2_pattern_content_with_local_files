package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class MultilineTextBox extends AbstractWidget
{
    private final Font font;
    private StringBuilder text = new StringBuilder();
    private List<String> lines = null;

    private int stringIndex = 0;    //字符索引
    private int stringRow = 0;      //字符行数
    private int stringCol = 0;      //字符列数

    private int selectionStart = -1;    // 选择起始字符索引
    private int selectionEnd = -1;      // 选择结束字符索引
    private boolean isSelecting = false;

    public static int scrollOffset = 0;   //垂直滚动偏移（行索引）
    public static int lineHeight = 9;     //行高
    public static int linesPerPage;       //可见行数
    public static int linesCount;

    public MultilineTextBox(Font font, int x, int y, int width, int height)
    {
        super(x, y, Math.max(6, width), Math.max(9, height), Component.literal(""));
        this.font = font;
        linesPerPage = height / 9;
    }

    public void setText(String string)
    {
        text = new StringBuilder(string);
        stringIndex = Math.min(stringIndex, text.length());
    }

    public String getText()
    {
        return text.toString();
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        //将文本按宽度拆分为行
        refreshEverySingleLines();
        refreshCharIndexFromRowAndCol();

        //计算可见行范围
        int startLine = scrollOffset;
        int endLine = Math.min(startLine + linesPerPage, lines.size());

        // 绘制可见行
        int y = getY() + 2;
        for (int i = startLine; i < endLine; i++)
        {
            String line = lines.get(i);
            guiGraphics.drawString(font, line, getX() + 2, y, 0xFFFFFF);
            y += lineHeight;
        }

        if (selectionStart >= 0 && selectionEnd >= 0 && selectionStart != selectionEnd)
        {
            int start = Math.min(selectionStart, selectionEnd);
            int end = Math.max(selectionStart, selectionEnd);

            //找到起始行、列和结束行、列
            int selectionStartLine = 0;
            int selectionStartCol = 0;
            int selectionEndLine = 0;
            int selectionEndCol = 0;
            int remaining = start;

            for (int i = 0; i < lines.size(); i++)
            {
                int len = lines.get(i).length();
                if (remaining < len)
                {
                    selectionStartLine = i;
                    selectionStartCol = remaining;
                    break;
                }
                remaining -= len;
            }
            remaining = end;

            for (int i = 0; i < lines.size(); i++)
            {
                int len = lines.get(i).length();
                if (remaining <= len)
                {
                    selectionEndLine = i;
                    selectionEndCol = remaining;
                    break;
                }
                remaining -= len;
            }

            // 绘制高亮
            int startX = getX() + 2 + font.width(lines.get(selectionStartLine).substring(0, selectionStartCol));
            int endX = getX() + 2 + font.width(lines.get(selectionEndLine).substring(0, selectionEndCol));
            int startY = getY() + 1 + (selectionStartLine - scrollOffset) * lineHeight;
            int endY = getY() + 1 + (selectionEndLine - scrollOffset) * lineHeight;

            if (selectionStartLine == selectionEndLine)
            {
                guiGraphics.fill(startX, startY, endX, startY + lineHeight, 0x80FFFFFF);
            }
                else
                {
                    // 第一行从 startX 到行尾
                    guiGraphics.fill(startX, startY, getX() + 2 + font.width(lines.get(selectionStartLine)), startY + lineHeight, 0x80FFFFFF);
                    // 中间整行
                    for (int i = selectionStartLine + 1; i < selectionEndLine; i++)
                    {
                        int selectionY = getY() + 1 + (i - scrollOffset) * lineHeight;
                        guiGraphics.fill(getX() + 2, selectionY, getX() + 2 + font.width(lines.get(i)), selectionY + lineHeight, 0x80FFFFFF);
                    }
                    // 最后一行从行首到 endX
                    guiGraphics.fill(getX() + 2, endY, endX, endY + lineHeight, 0x80FFFFFF);
                }
        }

        //绘制光标（如果焦点）
        if (isFocused() && (System.currentTimeMillis() / 500 % 2 == 0))
        {
            if (stringRow >= startLine && stringRow <= endLine)
            {
                String lineBeforeCursor = lines.get(stringRow).substring(0, stringCol);
                int cursorX = getX() + 1 + font.width(lineBeforeCursor);
                int cursorY = getY() + 1 + (stringRow - startLine) * lineHeight;
                guiGraphics.fill(cursorX, cursorY, cursorX + 1, cursorY + lineHeight, 0xFFFFFFFF);
            }
        }
    }

    //将字符串按宽度拆分为行
    private List<String> wrapText(String text, int maxWidth)
    {
        List<String> lines = new ArrayList<>();
        if (font.width(text) <= Math.max(6, maxWidth))
        {
            lines.add(text);
        }
            else
            {
                String trimmed;
                while(!text.isEmpty())
                {
                    trimmed = font.plainSubstrByWidth(text, Math.max(6, maxWidth));
                    text = text.substring(trimmed.length());
                    lines.add(trimmed);
                }
            }
        return lines;
    }

    //通过字符串字体长度获取列数
    private int getCharColFromLitterLength(String string, int litterLength)
    {
        return (font.plainSubstrByWidth(string, litterLength)).length();
    }

    private void refreshEverySingleLines()
    {
        lines = wrapText(text.toString(), width - 4);
        linesCount = lines.size();
    }

    private void refreshCharIndexFromRowAndCol()
    {
        stringIndex = 0;
        for (int i = 0; i < stringRow; i++)
        {
            stringIndex += lines.get(i).length();
        }
        stringIndex += stringCol;
    }

    private void refreshCharRowAndColFromIndex()
    {
        refreshEverySingleLines();
        stringRow = 0;
        stringCol = 0;
        int bufferCount = 0;
        int i = 0;
        while (i < lines.size() && bufferCount + lines.get(i).length() < stringIndex + 1)
        {
            stringRow++;
            bufferCount += lines.get(i).length();
            i++;
        }
        if (i < lines.size())
        {
            stringCol = stringIndex - bufferCount;
        }
            else
            {
                //超出末尾，设置到末尾
                stringRow = lines.size() - 1;
                stringCol = lines.get(stringRow).length();
            }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        if (isMouseOver(mouseX, mouseY))
        {
            setFocused(true);

            //清除现有选择
            selectionStart = -1;
            selectionEnd = -1;

            //计算点击位置对应的字符位置
            if (scrollOffset + ((int)mouseY - 6) / lineHeight < lines.size())
            {
                stringRow = scrollOffset + ((int)mouseY - 6) / lineHeight;
                stringCol = getCharColFromLitterLength(lines.get(stringRow), (int)mouseX - 2);
            }
                else
                {
                    stringRow = lines.size() - 1;
                    stringCol = lines.get(stringRow).length();
                }

            refreshCharIndexFromRowAndCol();

            selectionStart = stringIndex;
            selectionEnd = stringIndex;
            isSelecting = true;
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY)
    {
        if (!isFocused() || !isSelecting)
        {
            return false;
        }

        int newIndex = getCharIndexAtPosition(mouseX, mouseY);

        selectionEnd = newIndex;
        stringIndex = newIndex; //光标跟随
        refreshCharRowAndColFromIndex();
        return true;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button)
    {
        if (button == 0)
        {
            isSelecting = false;
        }
        return true;
    }

    private int getCharIndexAtPosition(double mouseX, double mouseY)
    {
        int row = scrollOffset + ((int)mouseY - 7) / lineHeight;
        if (row < scrollOffset)
        {
            row = scrollOffset;
        }
        else
            if(row >= lines.size())
            {
                row = lines.size() - 1;
            }

        int col = getCharColFromLitterLength(lines.get(row), ((int)mouseX - 7));

        //计算全局索引
        int index = 0;
        for (int i = 0; i < row; i++)
        {
            index += lines.get(i).length();
        }
        return index + col;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        if (!isFocused())
        {
            return false;
        }

        //Ctrl组合键
        if (Screen.hasControlDown())
        {
            if (keyCode == 65) //A
            {
                selectAll();
                return true;
            }
            else
                if (keyCode == 67) //C
                {
                    copySelectionToClipboard();
                    return true;
                }
                else
                    if (keyCode == 88) //X
                    {
                        copySelectionToClipboard();
                        deleteSelection();
                        return true;
                    }
                    else
                        if (keyCode == 86) //V
                        {
                            pasteFromClipboard();
                            return true;
                        }
        }

        //功能键
        if (keyCode == 257 || keyCode == 335)//Enter
        {
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
            {
                deleteSelection();//删除选中内容
            }
            text.insert(stringIndex, '\n');
            if (stringCol < lines.get(stringRow).length())
            {
                stringCol++;
            }
            else
                if (stringRow < lines.size())
                {
                    stringRow++;
                    stringCol = 0;
                }
            refreshCharIndexFromRowAndCol();
            //清除选区
            selectionStart = -1;
            selectionEnd = -1;
            return true;
        }
        else
            if (keyCode == 259)//Backspace
            {
                if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                {
                    deleteSelection();
                }
                else
                    if (stringIndex > 0)
                    {
                        text.deleteCharAt(stringIndex - 1);
                        stringIndex--;
                        refreshCharRowAndColFromIndex();
                    }
                return true;
            }
        else
            if (keyCode == 261)//Delete
            {
                if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                {
                    deleteSelection();
                }
                else
                    if (stringIndex < text.length())
                    {
                        text.deleteCharAt(stringIndex);
                    }
                return true;
            }
            else//方向键
                if (keyCode == 263)//左
                {
                    if (Screen.hasShiftDown())
                    {
                        if (selectionStart == -1)
                        {
                            selectionStart = stringIndex;
                            selectionEnd = stringIndex;
                        }
                        if (stringIndex > 0)
                        {
                            stringIndex--;
                            refreshCharRowAndColFromIndex();
                            selectionEnd = stringIndex;
                        }
                    }
                        else
                        {
                            if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                            {
                                stringIndex = Math.min(selectionStart, selectionEnd);
                                refreshCharRowAndColFromIndex();
                                selectionStart = -1;
                                selectionEnd = -1;
                            }
                            else
                                if (stringIndex > 0)
                                {
                                    stringIndex--;
                                    refreshCharRowAndColFromIndex();
                                }
                        }
                    return true;
                }
                else
                    if (keyCode == 262)//右
                    {
                        if (Screen.hasShiftDown())
                        {
                            if (selectionStart == -1)
                            {
                                selectionStart = stringIndex;
                                selectionEnd = stringIndex;
                            }
                            if (stringIndex < text.length())
                            {
                                stringIndex++;
                                refreshCharRowAndColFromIndex();
                                selectionEnd = stringIndex;
                            }
                        }
                            else
                            {
                                if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                                {
                                    stringIndex = Math.max(selectionStart, selectionEnd);
                                    refreshCharRowAndColFromIndex();
                                    selectionStart = -1;
                                    selectionEnd = -1;
                                }
                                else
                                    if (stringIndex < text.length())
                                    {
                                        stringIndex++;
                                        refreshCharRowAndColFromIndex();
                                    }
                            }
                        return true;
                    }
                    else
                        if (keyCode == 265)//上
                        {
                            if (Screen.hasShiftDown())
                            {
                                if (selectionStart == -1)
                                {
                                    selectionStart = stringIndex;
                                    selectionEnd = stringIndex;
                                }
                                if (stringRow > 0)
                                {
                                    stringCol = getCharColFromLitterLength(lines.get(stringRow - 1), font.width(lines.get(stringRow).substring(0, stringCol)));
                                    stringRow--;
                                    refreshCharIndexFromRowAndCol();
                                    selectionEnd = stringIndex;
                                }
                            }
                                else
                                {
                                    if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                                    {
                                        stringIndex = Math.min(selectionStart, selectionEnd);
                                        refreshCharRowAndColFromIndex();
                                        selectionStart = -1;
                                        selectionEnd = -1;
                                    }
                                    else
                                        if (stringRow > 0)
                                        {
                                            stringCol = getCharColFromLitterLength(lines.get(stringRow - 1), font.width(lines.get(stringRow).substring(0, stringCol)));
                                            stringRow--;
                                            refreshCharIndexFromRowAndCol();
                                        }
                                }
                            return true;
                        }
                        else
                            if (keyCode == 264)//下
                            {
                                if (Screen.hasShiftDown())
                                {
                                    if (selectionStart == -1)
                                    {
                                        selectionStart = stringIndex;
                                        selectionEnd = stringIndex;
                                    }
                                    if (stringRow < lines.size() - 1)
                                    {
                                        stringCol = getCharColFromLitterLength(lines.get(stringRow + 1), font.width(lines.get(stringRow).substring(0, stringCol)));
                                        stringRow++;
                                        refreshCharIndexFromRowAndCol();
                                        selectionEnd = stringIndex;
                                    }
                                }
                                    else
                                    {
                                        if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
                                        {
                                            stringIndex = Math.max(selectionStart, selectionEnd);
                                            refreshCharRowAndColFromIndex();
                                            selectionStart = -1;
                                            selectionEnd = -1;
                                        }
                                        else
                                            if (stringRow < lines.size() - 1)
                                            {
                                                stringCol = getCharColFromLitterLength(lines.get(stringRow + 1), font.width(lines.get(stringRow).substring(0, stringCol)));
                                                stringRow++;
                                                refreshCharIndexFromRowAndCol();
                                            }
                                    }
                                return true;
                            }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    //全选
    private void selectAll()
    {
        selectionStart = 0;
        selectionEnd = text.length();
        stringIndex = selectionEnd;
        refreshCharRowAndColFromIndex();
    }

    //复制选中区域内容
    private void copySelectionToClipboard()
    {
        if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
        {
            int start = Math.min(selectionStart, selectionEnd);
            int end = Math.max(selectionStart, selectionEnd);
            String selected = text.substring(start, end);
            Minecraft.getInstance().keyboardHandler.setClipboard(selected);
        }
    }

    //清空选中区域内容
    private void deleteSelection()
    {
        if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
        {
            int start = Math.min(selectionStart, selectionEnd);
            int end = Math.max(selectionStart, selectionEnd);
            text.delete(start, end);
            stringIndex = start;
            refreshCharRowAndColFromIndex();
            selectionStart = -1;
            selectionEnd = -1;
        }
    }

    //粘贴
    private void pasteFromClipboard()
    {
        String clipboard = Minecraft.getInstance().keyboardHandler.getClipboard();
        if (clipboard != null && !clipboard.isEmpty())
        {
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
            {
                deleteSelection();
            }
            text.insert(stringIndex, clipboard);
            stringIndex += clipboard.length();
            refreshCharRowAndColFromIndex();
            selectionStart = -1;
            selectionEnd = -1;
        }
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        if (isFocused())
        {
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd)
            {
                deleteSelection(); // 删除选中内容
            }
            text.insert(stringIndex, codePoint);
            stringIndex++;
            refreshCharRowAndColFromIndex();
            //清除选区（因为插入后不应有选区）
            selectionStart = -1;
            selectionEnd = -1;
            return true;
        }
        return false;
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {}
}