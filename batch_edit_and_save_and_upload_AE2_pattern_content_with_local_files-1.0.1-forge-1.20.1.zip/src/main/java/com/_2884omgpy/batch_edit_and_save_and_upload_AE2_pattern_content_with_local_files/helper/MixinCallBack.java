package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper;

import net.minecraft.nbt.CompoundTag;
import java.util.List;

public interface MixinCallBack
{
    void startUpload(List<CompoundTag> patterns);
}
