package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper;

import appeng.api.stacks.AEFluidKey;
import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.fluids.FluidStack;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RendHelper
{
    public static final int CRAFTING_ENCODING_INPUT_SLOT_START_X = 9;
    public static final int CRAFTING_ENCODING_INPUT_SLOT_START_Y = 8;
    public static final int CRAFTING_ENCODING_OUTPUT_SLOT_START_X = 101;
    public static final int CRAFTING_ENCODING_OUTPUT_SLOT_START_Y = 26;

    public static final int PROCESSING_ENCODING_INPUT_SLOT_START_X = 17;
    public static final int PROCESSING_ENCODING_INPUT_SLOT_START_Y = 8;
    public static final int PROCESSING_ENCODING_OUTPUT_SLOT_START_X = 101;
    public static final int PROCESSING_ENCODING_OUTPUT_SLOT_START_Y = 8;

    public static final int SMITHING_TABLE_ENCODING_TEMPLATE_SLOT_START_X = 12;
    public static final int SMITHING_TABLE_ENCODING_TEMPLATE_SLOT_START_Y = 26;
    public static final int SMITHING_TABLE_ENCODING_BASE_SLOT_START_X = 30;
    public static final int SMITHING_TABLE_ENCODING_BASE_SLOT_START_Y = 26;
    public static final int SMITHING_TABLE_ENCODING_ADDITION_SLOT_START_X = 48;
    public static final int SMITHING_TABLE_ENCODING_ADDITION_SLOT_START_Y = 26;
    public static final int SMITHING_TABLE_ENCODING_OUTPUT_SLOT_START_X = 102;
    public static final int SMITHING_TABLE_ENCODING_OUTPUT_SLOT_START_Y = 26;

    public static final int STONE_CUTTING_ENCODING_INPUT_SLOT_START_X = 12;
    public static final int STONE_CUTTING_ENCODING_INPUT_SLOT_START_Y = 25;
    public static final int STONE_CUTTING_ENCODING_OUTPUT_SLOT_START_X = 44;
    public static final int STONE_CUTTING_ENCODING_OUTPUT_SLOT_START_Y = 8;

    public static int PROCESSING_ENCODING_PANEL_PAGE = 0;

    public static void rendItemOrErrorItemAndTooltip(GuiGraphics guiGraphics, GenericStack itemStack, List<String> itemId, int i, int x , int y, int mouseX, int mouseY)
    {
        if (itemStack != null)
        {
            rendItemOrFluid(guiGraphics, itemStack, x, y);
        }
        else
            if (itemId.size() > i && itemId.get(i) != null)
            {
                GUIBackgroundRendHelper.rendErrorItemPanel(guiGraphics, x, y);
            }

        if(mouseX >= x - 1 && mouseX <= x + 16 && mouseY >= y - 1 && mouseY <= y + 16)
        {
            rendSlotBeSelectedEffect(guiGraphics, x, y);
            if (itemStack != null)
            {
                rendItemOrFluidTooltip(guiGraphics, itemStack, mouseX, mouseY);
            }
            else
                if (itemId != null && itemId.get(i) != null)
                {
                    rendErrorItemTooltip(guiGraphics, itemId.get(i), mouseX, mouseY);
                }
        }
    }

    //绘制物品
    public static void rendItemOrFluid(GuiGraphics guiGraphics, GenericStack stack, int x, int y)
    {
        if (stack.what() instanceof AEItemKey itemKey)
        {
            ItemStack displayStack = itemKey.toStack();
            displayStack.setCount((int)stack.amount());
            guiGraphics.renderItem(displayStack, x, y);
            if (stack.amount() > 1 && stack.amount() <= 999)
            {
                guiGraphics.renderItemDecorations(Minecraft.getInstance().font, displayStack, x, y);
            }
            else
                if (stack.amount() >= 1000 && stack.amount() <= 99999)
                {
                    rendItemSmallerAmountNumber(guiGraphics, String.valueOf(stack.amount()), 0.5f, x, y);
                }
                else
                    if (stack.amount() >= 100000)
                    {
                        rendItemSmallerAmountNumber(guiGraphics, String.valueOf(stack.amount()), 0.25f, x, y);
                    }
        }
        else
            if (stack.what() instanceof AEFluidKey fluidKey)
            {
                renderFluid(guiGraphics, fluidKey.getFluid(), fluidKey.getTag(), (int) stack.amount(), x, y);
            }
    }

    //绘制流体
    public static void renderFluid(GuiGraphics guiGraphics, Fluid fluid, @Nullable CompoundTag tag, int amount, int x, int y)
    {
        FluidStack fluidStack = new FluidStack(fluid, amount, tag);
        var fluidType = fluid.getFluidType();
        var extensions = IClientFluidTypeExtensions.of(fluidType);
        ResourceLocation stillTexture = extensions.getStillTexture(fluidStack);
        if (stillTexture == null)
        {
            stillTexture = ResourceLocation.parse("minecraft:block/water_still");
        }
        int color = extensions.getTintColor(fluidStack);

        var sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(stillTexture);

        //设置颜色
        float red = ((color >> 16) & 0xFF) / 255f;
        float green = ((color >> 8) & 0xFF) / 255f;
        float blue = (color & 0xFF) / 255f;
        float alpha = ((color >> 24) & 0xFF) / 255f;
        RenderSystem.setShaderColor(red, green, blue, alpha);

        guiGraphics.blit(x, y, 0, 16, 16, sprite);

        //重置颜色
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        //显示数量
        if (amount >= 1 && amount <= 99)
        {
            rendItemSmallerAmountNumber(guiGraphics, amount + " mB", 0.5f, x, y);
        }
        else
            if (amount >= 100)
            {
                rendItemSmallerAmountNumber(guiGraphics, amount + " mB", 0.25f, x, y);
            }
    }

    private static void rendItemSmallerAmountNumber(GuiGraphics guiGraphics, String text, float magnification, int x, int y)
    {
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(0, 0, 255);
        guiGraphics.pose().scale(magnification, magnification, 1.0f);
        guiGraphics.drawString(Minecraft.getInstance().font, text, (x + 15) / magnification - Minecraft.getInstance().font.width(text), (y + 16) / magnification - Minecraft.getInstance().font.lineHeight, 0xFFFFFF, true);
        guiGraphics.pose().popPose();
        RenderSystem.enableDepthTest();
    }

    //渲染物品tooltip
    public static void rendItemOrFluidTooltip(GuiGraphics guiGraphics, GenericStack stack, int mouseX, int mouseY)
    {
        if (stack.what() instanceof AEItemKey itemKey)
        {
            ItemStack displayStack = itemKey.toStack();
            displayStack.setCount((int) stack.amount());
            guiGraphics.renderTooltip(Minecraft.getInstance().font, displayStack, mouseX, mouseY);
        }
        else
            if (stack.what() instanceof AEFluidKey fluidKey)
            {
                Fluid fluid = fluidKey.getFluid();
                long amount = stack.amount();
                List<Component> tooltip = new ArrayList<>();

                //流体名称
                tooltip.add(fluidKey.getDisplayName());

                //流体ID
                ResourceLocation fluidId = BuiltInRegistries.FLUID.getKey(fluid);
                tooltip.add(Component.literal("§8" + fluidId));

                //数量（mB）
                tooltip.add(Component.literal("§7" + amount + " mB"));

                //流体对应mod
                String modId = fluidId.getNamespace();
                String modName = net.minecraftforge.fml.ModList.get().getModContainerById(modId).map(mod -> mod.getModInfo().getDisplayName()).orElse(modId);
                tooltip.add(Component.literal("§9§o" + modName));
                guiGraphics.renderTooltip(Minecraft.getInstance().font, tooltip, Optional.empty(), mouseX, mouseY);
            }
                else
                {
                    System.err.println("tooltips渲染出错");
                }
    }

    public static void rendErrorItemTooltip(GuiGraphics guiGraphics, String itemId, int mouseX, int mouseY)
    {
        List<Component> tooltip = new ArrayList<>();
        tooltip.add(Component.literal("§c此槽位物品在当前游戏环境中无法正确读取！！！"));
        tooltip.add(Component.literal("§c" + itemId));
        guiGraphics.renderTooltip(Minecraft.getInstance().font, tooltip, Optional.empty(), mouseX, mouseY);
    }

    public static void rendErrorPatternItemTooltip(GuiGraphics guiGraphics, CompoundTag patternTag, String slotSemantic, int mouseX, int mouseY)
    {
        //解码失败，手动解析输出物品tooltips
        GenericStack item_stack = PatternContentHelper.patternTag_to_GenericStack(patternTag,"out", 0);
        Tag itemTag = patternTag.getCompound("tag").get(slotSemantic);

        //构建tooltip列表
        List<Component> tooltip = new ArrayList<>();

        if (item_stack == null)
        {
            // 尝试从原始 NBT 中提取信息
            String itemId = null;
            if (itemTag != null)
            {
                CompoundTag target = null;
                if (itemTag instanceof CompoundTag)
                {
                    target = (CompoundTag) itemTag;
                }
                else
                    if (itemTag instanceof ListTag)
                    {
                        ListTag list = (ListTag) itemTag;
                        if (!list.isEmpty())
                        {
                            target = list.getCompound(0);
                        }
                    }

                if (target != null)
                {
                    if (target.contains("id"))
                    {
                        itemId = target.getString("id");
                    }
                }
            }
            if (itemId != null)
            {
                tooltip.add(Component.translatable("§c" + "在当前游戏环境中无法正确读取此样板的产物！！！"));
                tooltip.add(Component.literal("§c" + itemId));
            }
                else
                {
                    tooltip.add(Component.translatable("§c" + "此样板产物为空！！！"));
                }
        }
        else
            {
                if (item_stack.what() instanceof AEItemKey itemKey)
                {
                    ItemStack itemStack = itemKey.toStack((int) item_stack.amount());
                    tooltip.add(Component.literal("§c" + itemStack.getHoverName().getString()));
                }
                else
                    if (item_stack.what() instanceof AEFluidKey fluidKey)
                    {
                        FluidStack fluidStack = fluidKey.toStack((int) item_stack.amount());
                        tooltip.add(Component.literal("§c" + fluidStack.getDisplayName().getString()));
                    }
                        else
                        {
                            tooltip.add(Component.translatable("§c" + "在当前游戏环境中无法正确读取此样板的产物！！！"));
                        }

                ResourceLocation id = null;
                if (item_stack.what() instanceof AEItemKey itemKey)
                {
                    id = BuiltInRegistries.ITEM.getKey(itemKey.getItem());
                }
                else
                    if (item_stack.what() instanceof AEFluidKey fluidKey)
                    {
                        id = BuiltInRegistries.FLUID.getKey(fluidKey.getFluid());
                    }

                if (id != null)
                {
                    tooltip.add(Component.literal("§c" + id));
                }
                    else
                    {
                        tooltip.add(Component.translatable("§c" + "未知ID"));
                    }
            }
        tooltip.add(Component.translatable("§c" + "此样板内容出现错误！！！"));
        //渲染tooltip
        guiGraphics.renderTooltip(Minecraft.getInstance().font, tooltip, Optional.empty(), mouseX, mouseY);
    }

    //绘制AE2样板及其内容
    public static void rendAE2PatternPanelAndItemAndTooltip(GuiGraphics guiGraphics, String patternType, List<GenericStack> inputStack, List<String> inputItemId, List<GenericStack> outputStack, List<String> outputItemId, int x, int y, int mouseX, int mouseY)
    {
        switch (patternType)
        {
            case "ae2:crafting_pattern":
            {
                GUIBackgroundRendHelper.rendCraftingEncodingPanel(guiGraphics, x, y);
                for (int i = 0; i < 9; i++)
                {
                    rendItemOrErrorItemAndTooltip(guiGraphics, i < inputStack.size() ? inputStack.get(i) : null, inputItemId, i , x + CRAFTING_ENCODING_INPUT_SLOT_START_X + (i % 3) * 18, y + CRAFTING_ENCODING_INPUT_SLOT_START_Y + (i / 3) * 18, mouseX, mouseY);
                }
                rendItemOrErrorItemAndTooltip(guiGraphics, outputStack.isEmpty() ? null : outputStack.get(0), outputItemId, 0, x + CRAFTING_ENCODING_OUTPUT_SLOT_START_X, y + CRAFTING_ENCODING_OUTPUT_SLOT_START_Y, mouseX, mouseY);
                break;
            }

            case "ae2:processing_pattern":
            {
                GUIBackgroundRendHelper.rendProcessingEncodingPanel(guiGraphics, x, y);
                for (int i = PROCESSING_ENCODING_PANEL_PAGE * 9; i < PROCESSING_ENCODING_PANEL_PAGE * 9 + 9; i++)
                {
                    rendItemOrErrorItemAndTooltip(guiGraphics, i < inputStack.size() ? inputStack.get(i) : null, inputItemId, i , x + PROCESSING_ENCODING_INPUT_SLOT_START_X + ((i - PROCESSING_ENCODING_PANEL_PAGE * 9) % 3) * 18, y + PROCESSING_ENCODING_INPUT_SLOT_START_Y + ((i - PROCESSING_ENCODING_PANEL_PAGE * 9) / 3) * 18, mouseX, mouseY);
                }
                for (int i = PROCESSING_ENCODING_PANEL_PAGE * 3; i < PROCESSING_ENCODING_PANEL_PAGE * 3 + 3; i++)
                {
                    rendItemOrErrorItemAndTooltip(guiGraphics, i < outputStack.size() ? outputStack.get(i) : null, outputItemId, i, x + PROCESSING_ENCODING_OUTPUT_SLOT_START_X, y + PROCESSING_ENCODING_OUTPUT_SLOT_START_Y + (i - PROCESSING_ENCODING_PANEL_PAGE * 3) * 18, mouseX, mouseY);
                }
                GUIBackgroundRendHelper.rendAE2Slider(guiGraphics, x + 8, y + 8 + PROCESSING_ENCODING_PANEL_PAGE * 52 / 9, 6);
                break;
            }

            case "ae2:smithing_table_pattern":
            {
                GUIBackgroundRendHelper.rendSmithingTableEncodingPanel(guiGraphics, x, y);
                rendItemOrErrorItemAndTooltip(guiGraphics, inputStack.isEmpty() ? null : inputStack.get(0), inputItemId, 0, x + SMITHING_TABLE_ENCODING_TEMPLATE_SLOT_START_X, y + SMITHING_TABLE_ENCODING_TEMPLATE_SLOT_START_Y, mouseX, mouseY);
                rendItemOrErrorItemAndTooltip(guiGraphics, inputStack.isEmpty() ? null : inputStack.get(1), inputItemId, 1, x + SMITHING_TABLE_ENCODING_BASE_SLOT_START_X, y + SMITHING_TABLE_ENCODING_BASE_SLOT_START_Y, mouseX, mouseY);
                rendItemOrErrorItemAndTooltip(guiGraphics, inputStack.isEmpty() ? null : inputStack.get(2), inputItemId, 2, x + SMITHING_TABLE_ENCODING_ADDITION_SLOT_START_X, y + SMITHING_TABLE_ENCODING_ADDITION_SLOT_START_Y, mouseX, mouseY);
                rendItemOrErrorItemAndTooltip(guiGraphics, outputStack.isEmpty() ? null : outputStack.get(0), outputItemId, 0, x + SMITHING_TABLE_ENCODING_OUTPUT_SLOT_START_X, y + SMITHING_TABLE_ENCODING_OUTPUT_SLOT_START_Y, mouseX, mouseY);
                break;
            }

            case "ae2:stonecutting_pattern":
            {
                GUIBackgroundRendHelper.rendStoneCuttingEncodingPanel(guiGraphics, x, y);
                rendItemOrErrorItemAndTooltip(guiGraphics, inputStack.isEmpty() ? null : inputStack.get(0), inputItemId, 0, x + STONE_CUTTING_ENCODING_INPUT_SLOT_START_X, y + STONE_CUTTING_ENCODING_INPUT_SLOT_START_Y, mouseX, mouseY);
                GUIBackgroundRendHelper.rendStoneCuttingOutputSlot(guiGraphics, x, y);
                rendItemOrErrorItemAndTooltip(guiGraphics, outputStack.isEmpty() ? null : outputStack.get(0), outputItemId, 0, x + STONE_CUTTING_ENCODING_OUTPUT_SLOT_START_X, y + STONE_CUTTING_ENCODING_OUTPUT_SLOT_START_Y, mouseX, mouseY);
                break;
            }

            default:
            {
                GUIBackgroundRendHelper.rendErrorPatternPanel(guiGraphics, x, y);
            }
        }
    }

    //渲染鼠标在槽位上的选中效果
    public static void rendSlotBeSelectedEffect(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.fill(x, y, x + 16, y + 16, 0x7FFFFFFF);
    }
}
