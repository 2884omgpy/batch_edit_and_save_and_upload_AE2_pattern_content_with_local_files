package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public class GUIBackgroundRendHelper
{
    public static final ResourceLocation LEFT_TOP = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/left_top.png");
    public static final ResourceLocation TOP = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/multipart_top.png");
    public static final ResourceLocation RIGHT_TOP = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/right_top.png");
    public static final ResourceLocation LEFT = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/multipart_left.png");
    public static final ResourceLocation CENTER = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/multipart_center.png");
    public static final ResourceLocation RIGHT = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/multipart_right.png");
    public static final ResourceLocation LEFT_BOTTOM = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/left_bottom.png");
    public static final ResourceLocation BOTTOM = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/multipart_bottom.png");
    public static final ResourceLocation RIGHT_BOTTOM = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/right_bottom.png");

    public static final ResourceLocation SLOT = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/slot.png");

    public static final ResourceLocation PREV_BUTTON = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/prev_button.png");
    public static final ResourceLocation JEI_RECIPE_NAME_BAR_MULTIPART = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/jei_recipe_name_bar_multipart.png");
    public static final ResourceLocation NEXT_BUTTON = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/next_button.png");

    public static final ResourceLocation JEI_ITEM_NAME_INPUT_TEXTBOX_LEFT = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/jei_item_name_input_textbox_left.png");
    public static final ResourceLocation JEI_ITEM_NAME_INPUT_TEXTBOX_MULTIPART = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/jei_item_name_input_textbox_multipart.png");
    public static final ResourceLocation JEI_ITEM_NAME_INPUT_TEXTBOX_RIGHT = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/jei_item_name_input_textbox_right.png");

    public static final ResourceLocation FILE_NAME_SELECT_TEXTBOX = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/file_name_select_textbox.png");
    public static final ResourceLocation ERROR_PATTERN_PANEL_BACKGROUND = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/custom_error_pattern_panel/error_pattern_panel_background.png");

    public static final ResourceLocation SNBT_EDIT_SCREEN_MULTIPART = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/snbt_edit_screen_multipart.png");

    public static final ResourceLocation AE2_PATTERN_PANEL = ResourceLocation.fromNamespaceAndPath("ae2", "textures/guis/pattern_modes.png");
    public static final ResourceLocation ERROR_ITEM = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/minecraft_original_gui/error_item.png");
    public static final ResourceLocation ERROR_PATTERN_PANEL = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/custom_error_pattern_panel/error_pattern_panel.png");

    public static final ResourceLocation AE2_SLIDE_BACKGROUND_MULTIPART = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/ae2_slide_background_multipart.png");
    public static final ResourceLocation AE2_SLIDE_MULTIPART = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/ae2_slide_multipart.png");

    public static final ResourceLocation AE2_PATTERN_CONTENT_AMOUNT_SETTING_INPUT_TEXTBOX = ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "textures/gui/anything_else/ae2_pattern_content_amount_setting_input_textbox.png");

    public static void rendMinecraftOriginalGUIBackground(GuiGraphics guiGraphics, int x, int y, int width, int height)
    {
        guiGraphics.blit(LEFT_TOP, x, y, 0, 0, 4, 4, 4, 4);
        guiGraphics.blit(TOP, x + 4, y, 0, 0, width - 8, 4, 1, 4);
        guiGraphics.blit(RIGHT_TOP, x + width - 4, y, 0, 0, 4, 4, 4, 4);
        guiGraphics.blit(LEFT, x, y + 4, 0, 0, 4, height - 8, 4, 1);
        guiGraphics.blit(CENTER, x + 4, y + 4, 0, 0, width - 8, height - 8, 1, 1);
        guiGraphics.blit(RIGHT, x + width - 4, y + 4, 0, 0, 4, height- 8, 4, 1);
        guiGraphics.blit(LEFT_BOTTOM, x, y + height - 4, 0, 0, 4, 4, 4, 4);
        guiGraphics.blit(BOTTOM, x + 4, y + height - 4, 0, 0, width - 8, 4, 1, 4);
        guiGraphics.blit(RIGHT_BOTTOM, x + width - 4, y + height - 4, 0, 0, 4, 4, 4, 4);
    }

    public static void rendSlot(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(SLOT, x, y, 0, 0, 18, 18, 18, 18);
    }

    public static void rendJEIRecipeNameBar(GuiGraphics guiGraphics, int x, int y, int width)
    {
        guiGraphics.blit(PREV_BUTTON, x, y, 0, 0, 13, 13, 13, 13);
        guiGraphics.blit(JEI_RECIPE_NAME_BAR_MULTIPART, x + 13, y, 0, 0, width - 26, 13, 1, 13);
        guiGraphics.blit(NEXT_BUTTON, x + width - 13, y, 0, 0, 13, 13, 13, 13);
    }

    public static void rendJEIItemNameInputTextbox(GuiGraphics guiGraphics, int x, int y, int width)
    {
        guiGraphics.blit(JEI_ITEM_NAME_INPUT_TEXTBOX_LEFT, x, y, 0, 0, 2, 20, 2, 20);
        guiGraphics.blit(JEI_ITEM_NAME_INPUT_TEXTBOX_MULTIPART, x + 2, y, 0, 0, width - 4, 20, 1, 20);
        guiGraphics.blit(JEI_ITEM_NAME_INPUT_TEXTBOX_RIGHT, x + width - 2, y, 0, 0, 2, 20, 2, 20);
    }

    public static void rendFileNameSelectTextbox(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(FILE_NAME_SELECT_TEXTBOX, x, y, 0, 0, 124, 16, 124, 16);
    }

    public static void rendErrorPatternPanelBackGround(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(ERROR_PATTERN_PANEL_BACKGROUND, x, y, 0, 0, 126, 68, 126, 68);
    }

    public static void rendSNBTEditScreen(GuiGraphics guiGraphics, int x, int y, int width, int height)
    {
        guiGraphics.blit(SNBT_EDIT_SCREEN_MULTIPART, x, y, 0, 0, width, height, 1, 1);
    }

    public static void rendAE2SlideBackground(GuiGraphics guiGraphics, int x, int y, int height)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 7, 77, 9, 1, 256, 256);
        guiGraphics.blit(AE2_SLIDE_BACKGROUND_MULTIPART, x, y + 1, 0, 0, 9, height - 2, 9, 1);
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y + height - 1, 7, 130, 9, 1, 256, 256);
    }

    public static void rendCraftingEncodingPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 0, 0, 126, 68, 256, 256);
    }

    public static void rendProcessingEncodingPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 0, 70, 126, 68, 256, 256);
    }

    public static void rendSmithingTableEncodingPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 128, 70, 126, 68, 256, 256);
    }

    public static void rendStoneCuttingEncodingPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 0, 141, 126, 68, 256, 256);
    }

    public static void rendErrorPatternPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(ERROR_PATTERN_PANEL, x, y, 0, 0, 126, 68, 126, 68);
    }

    public static void rendErrorItemPanel(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(ERROR_ITEM, x, y, 0,0, 16, 16, 16, 16);
    }

    public static void rendStoneCuttingOutputSlot(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x + 44, y + 7, 126, 141, 16, 18, 256, 256);
    }

    public static void rendAE2Slider(GuiGraphics guiGraphics, int x, int y, int height)
    {
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y, 242, 0, 7, 1, 256, 256);
        guiGraphics.blit(AE2_SLIDE_MULTIPART, x, y + 1, 0, 0, 7, height - 2, 7, 2);
        guiGraphics.blit(AE2_PATTERN_PANEL, x, y + height - 1, 242, 14, 7, 1, 256, 256);
    }

    public static void rendAE2PatternContentAmountSettingInputTextbox(GuiGraphics guiGraphics, int x, int y)
    {
        guiGraphics.blit(AE2_PATTERN_CONTENT_AMOUNT_SETTING_INPUT_TEXTBOX, x, y, 0, 0, 66, 12, 66, 12);
    }
}
