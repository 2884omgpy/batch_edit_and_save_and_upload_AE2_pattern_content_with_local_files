package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.mixin;

import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.menu.AEBaseMenu;
import appeng.menu.implementations.PatternProviderMenu;
import appeng.parts.crafting.PatternProviderPart;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen.PatternContentAddFromJEIScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(AEBaseScreen.class)
public abstract class PatternProviderScreenMixin extends Screen
{
    protected PatternProviderScreenMixin(Component title)
    {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void addButton(CallbackInfo ci)
    {
        AbstractContainerMenu containerMenu = ((AbstractContainerScreenAccessor) this).getMenu();
        ContainerScreenAccessor containerScreen = (ContainerScreenAccessor) this;
        if (this.getClass().getName().contains("PatternProvider") || ((Object)this) instanceof PatternProviderScreen<?> || containerMenu instanceof PatternProviderMenu)
        {
            int guiLeft = containerScreen.getLeftPos();
            int guiTop = containerScreen.getTopPos();
            int guiWidth = containerScreen.getImageWidth();
            int guiHeight = containerScreen.getImageHeight();

            Button savePatternContentButton = Button.builder(Component.translatable("保存样板内容"), button -> Minecraft.getInstance().setScreen(new PatternContentAddFromJEIScreen(getPatternsFromThisPatternProvider(), this))).pos(guiLeft + 89, guiTop + 4).size(64, 16).build();

            this.addRenderableWidget(savePatternContentButton);
        }
    }

    private List<CompoundTag> getPatternsFromThisPatternProvider()
    {
        AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) this;
        AEBaseMenu menu = (AEBaseMenu) accessor.getMenu();
        if (menu instanceof PatternProviderMenu)
        {
            Object target = menu.getTarget();
            if (target instanceof BlockEntity blockEntity)
            {
                return PatternContentHelper.readNBTFromBlockEntity(blockEntity);
            }
            else
                if (target instanceof PatternProviderPart part)
                {
                    return PatternContentHelper.readNBTFromPart(part);
                }
        }
        return null;
    }
}