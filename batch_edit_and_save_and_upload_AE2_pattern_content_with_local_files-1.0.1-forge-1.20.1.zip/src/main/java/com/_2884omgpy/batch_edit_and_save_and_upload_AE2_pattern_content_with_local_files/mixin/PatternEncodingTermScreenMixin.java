package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.mixin;

import appeng.api.stacks.AEItemKey;
import appeng.api.stacks.GenericStack;
import appeng.client.gui.AEBaseScreen;
import appeng.client.gui.me.items.PatternEncodingTermScreen;
import appeng.core.sync.network.NetworkHandler;
import appeng.core.sync.packets.InventoryActionPacket;
import appeng.helpers.InventoryAction;
import appeng.menu.me.items.PatternEncodingTermMenu;
import appeng.parts.encoding.EncodingMode;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.MixinCallBack;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.helper.PatternContentHelper;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.screen.PatternContentUploadScreen;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(AEBaseScreen.class)
public abstract class PatternEncodingTermScreenMixin extends Screen implements MixinCallBack
{
    int guiLeft;
    int guiTop;
    int guiWidth;
    int guiHeight;

    PatternEncodingTermScreen<?> screen;
    PatternEncodingTermMenu menu;

    //模拟玩家编码状态机
    private int currentPatternIndex = 0;
    private boolean shouldEncodeNextPattern = false;
    private List<CompoundTag> allPatternContent = new ArrayList<>();
    private CompoundTag patternContent;
    private List<ItemStack> allItemStack = new ArrayList<>();

    private int step = 0;

    private boolean isUploading = false;
    private int uploadPatternUseTicks = 0;
    private boolean isNowEncodeThisFinished = false;

    protected PatternEncodingTermScreenMixin(Component title)
    {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void addButton(CallbackInfo ci)
    {
        if (!this.getClass().getName().contains("PatternEncodingTermScreen"))
        {
            return;
        }

        screen = (PatternEncodingTermScreen<?>) (Object) this;
        menu = screen.getMenu();

        if (this.getClass().getName().contains("PatternEncodingTermScreen"))
        {
            ContainerScreenAccessor accessor = (ContainerScreenAccessor) this;
            guiLeft = accessor.getLeftPos();
            guiTop = accessor.getTopPos();
            guiWidth = accessor.getImageWidth();
            guiHeight = accessor.getImageHeight();

            Button uploadPatternContentButton = Button.builder(Component.translatable("上传本地样板内容"), button ->
            {
                Minecraft.getInstance().setScreen(new PatternContentUploadScreen(this, this));
            }).pos(guiLeft + guiWidth - 102, guiTop + guiHeight - 178).size(80, 14).build();

            this.addRenderableWidget(uploadPatternContentButton);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void drawUploadProgress(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci)
    {
        if (!this.getClass().getName().contains("PatternEncodingTermScreen"))
        {
            return;
        }
        if (isUploading)
        {
            guiGraphics.drawString(this.font, "当前编码进度:" + currentPatternIndex + "/" + allPatternContent.size() + ";耗时" + uploadPatternUseTicks + "tick", guiLeft + 41, guiTop + 138, 0xFFFFFF, false);
        }
    }

    public void startUpload(List<CompoundTag> willBeUploadPatternContent)
    {
        allPatternContent = willBeUploadPatternContent;

        uploadPatternUseTicks = 0;
        currentPatternIndex = 0;
        step = 0;

        isUploading = true;
        shouldEncodeNextPattern = true;
        isNowEncodeThisFinished = false;
    }

    @Inject(method = "containerTick", at = @At("RETURN"))
    public void perTickDoEncodePattenStep(CallbackInfo ci)
    {
        if (!this.getClass().getName().contains("PatternEncodingTermScreen"))
        {
            return;
        }
        if (!isUploading)
        {
            uploadPatternUseTicks = 0;
            return;
        }

        uploadPatternUseTicks++;

        if (shouldEncodeNextPattern)
        {
            shouldEncodeNextPattern = false;
            patternContent = allPatternContent.get(currentPatternIndex);
            getNextPatternListItemStack();
        }

        SimulatePlayerEncodePattern();

        //如果当前样板编码完成，则编码下一个
        if (isNowEncodeThisFinished)
        {
            isNowEncodeThisFinished = false;
            if (currentPatternIndex < allPatternContent.size() - 1)
            {
                currentPatternIndex++;
                shouldEncodeNextPattern = true;
            }
                else
                {   //已经编码所有内容
                    isUploading = false;
                }
        }
    }

    //模拟玩家编写单个样板的行为
    private void SimulatePlayerEncodePattern()
    {
        switch (step)
        {
            case 0:
            {
                fromPlayerInventoryMoveBlankPatternToPatternEncodingTerminalBlankPatternInputSlot();
                setPatternType();
                step++;
                break;
            }
            case 1:
            {
                editPatternContent();
                step++;
                break;
            }
            case 2:
            {
                if (patternContent.getString("id").equals("ae2:stonecutting_pattern"))
                {
                    selectStoneCuttingOutput();
                    step++;
                    break;
                }
                    else
                    {
                        encodePattern();
                        step++;
                        break;
                    }
            }
            case 3:
            {
                if (patternContent.getString("id").equals("ae2:stonecutting_pattern"))
                {
                    encodePattern();
                    step++;
                    break;
                }
                else
                    {
                        takeEncodedPattern();
                        isNowEncodeThisFinished = true;
                        step = 0;
                        break;
                    }
            }
            case 4:
            {
                takeEncodedPattern();
                isNowEncodeThisFinished = true;
                step = 0;
                break;
            }
            default:
            {
                isNowEncodeThisFinished = true;
                step = 0;
                break;
            }
        }
    }

    //放入空白样板
    private void fromPlayerInventoryMoveBlankPatternToPatternEncodingTerminalBlankPatternInputSlot()
    {
        int playerInventoryBlankPatternSlotIndex = -1;
        int thisSlotBlankPatternCount = 0;
        boolean isPlayerInventoryHasBlankPattern = false;
        boolean isPatternEncodingTerminalBlankPatternInputSlotHasBlankPattern = !menu.getSlot(163).getItem().isEmpty();

        if (!isPatternEncodingTerminalBlankPatternInputSlotHasBlankPattern)
        {
            for (int i = 0; i < 36; i++)
            {
                ItemStack itemStack = Minecraft.getInstance().player.getInventory().getItem(i);
                if (!itemStack.isEmpty() && BuiltInRegistries.ITEM.getKey(itemStack.getItem()).toString().equals("ae2:blank_pattern"))
                {
                    playerInventoryBlankPatternSlotIndex = i + 5;
                    isPlayerInventoryHasBlankPattern = true;
                    thisSlotBlankPatternCount = itemStack.getCount();
                    break;
                }
            }

            if (isPlayerInventoryHasBlankPattern)
            {
                if (Minecraft.getInstance().player.getAbilities().instabuild)
                {
                    //创造模式下，模拟鼠标中键复制
                    Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), playerInventoryBlankPatternSlotIndex, 2, ClickType.CLONE, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));

                    //模拟左键，放入样板输入槽
                    Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), 163, 0, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));
                }
                    else
                    {
                        //模拟右键点击背包中样板所在的槽位，拿出一半的样板（剩下一半用于占位，防止这个槽位被别的物品占用）
                        Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), playerInventoryBlankPatternSlotIndex, 1, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));

                        //模拟右键点击样板编码终端样板输入槽(SlotIndex = 163)，放入1个样板
                        Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), 163, 1, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));

                        if (thisSlotBlankPatternCount != 1 && thisSlotBlankPatternCount != 2)
                        {
                            //模拟左键点击背包中样板存放的位置，把多余的样板放回去
                            Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), playerInventoryBlankPatternSlotIndex, 0, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));
                        }
                    }
            }
        }
    }

    //选择样板类型
    private void setPatternType()
    {
        String id = patternContent.getString("id");
        switch (id)
        {
            case "ae2:crafting_pattern":
            {
                menu.setMode(EncodingMode.CRAFTING);
                break;
            }
            case "ae2:processing_pattern":
            {
                menu.setMode(EncodingMode.PROCESSING);
                break;
            }
            case "ae2:smithing_table_pattern":
            {
                menu.setMode(EncodingMode.SMITHING_TABLE);
                break;
            }
            case "ae2:stonecutting_pattern":
            {
                menu.setMode(EncodingMode.STONECUTTING);
                break;
            }
        }
    }

    //写入样板内容
    private void editPatternContent()
    {
        menu.clear();
        String id = patternContent.getString("id");
        switch (id)
        {
            case "ae2:crafting_pattern":
            {
                for(int i = 0; i <= 8; i++)
                {
                    if (allItemStack.get(i) != null)
                    {
                        NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, i + 41, allItemStack.get(i)));
                    }
                }
                break;
            }
            case "ae2:processing_pattern":
            {
                for(int i = 0; i <= 107; i++)
                {
                    if (allItemStack.get(i) != null)
                    {
                        NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, i + 51, allItemStack.get(i)));
                        System.out.println("allItemStack.get(" + i +") = " + allItemStack.get(i).getItem());
                    }
                }
                break;
            }
            case "ae2:smithing_table_pattern":
            {
                for(int i = 0; i <= 2; i++)
                {
                    if (allItemStack.get(i) != null)
                    {
                        NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, i + 160, allItemStack.get(i)));
                    }
                }
                break;
            }
            case "ae2:stonecutting_pattern":
            {
                if (allItemStack.get(0) != null)
                {
                    NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, 159, allItemStack.get(0)));
                }
                break;
            }
        }
    }

    //编写样板
    private void encodePattern()
    {
        menu.encode();
    }

    private void selectStoneCuttingOutput()
    {
        CompoundTag tag = patternContent.getCompound("tag");

        if (tag.contains("recipe", 8))
        {
            String recipeId = tag.getString("recipe");
            ResourceLocation id = ResourceLocation.tryParse(recipeId);
            if (id != null)
            {
                menu.setStonecuttingRecipeId(id);
            }
        }
            else
            {
                if (allItemStack.get(1) != null)
                {
                    AEItemKey desiredOutput = AEItemKey.of(allItemStack.get(1));
                    if (desiredOutput != null)
                    {
                        for (var recipe : menu.getStonecuttingRecipes())
                        {
                            var out = AEItemKey.of(recipe.getResultItem(Minecraft.getInstance().level.registryAccess()));
                            if (desiredOutput.equals(out))
                            {
                                menu.setStonecuttingRecipeId(recipe.getId());
                                return;
                            }
                        }
                    }
                }
            }
    }

    //拿取编写好的样板
    private void takeEncodedPattern()
    {
        int playerInventoryEmptySlotIndex = -1;
        boolean isPlayerInventoryHasEmptySlot = false;

        for (int i = 0; i < 36; i++)
        {
            if (Minecraft.getInstance().player.getInventory().getItem(i).isEmpty())
            {
                playerInventoryEmptySlotIndex = i + 5;
                isPlayerInventoryHasEmptySlot = true;
                break;
            }
        }

        if (isPlayerInventoryHasEmptySlot)
        {
            //模拟左键点击样板编码终端样板输出槽(SlotIndex = 164)
            Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), 164, 0, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));

            //模拟左键点击背包中空槽位
            Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), playerInventoryEmptySlotIndex, 0, ClickType.PICKUP, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));
        }
            else
            {
                //如果玩家背包满了没有空槽位，则把样板丢出去
                Minecraft.getInstance().player.connection.send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), 164, 0, ClickType.THROW, ItemStack.EMPTY, new Int2ObjectOpenHashMap<>()));
            }

        //清空List<ItemStack>
        allItemStack.clear();

        //清空样板内容槽位
        if (patternContent.getString("id").equals("ae2:stonecutting_pattern"))
        {
            NetworkHandler.instance().sendToServer(new InventoryActionPacket(InventoryAction.SET_FILTER, 159, ItemStack.EMPTY));
        }
            else
            {
                menu.clear();
            }
    }

    //获取下一个样板内容的List<ItemStack>
    private void getNextPatternListItemStack()
    {
        List<GenericStack> input = PatternContentHelper.patternTag_to_List_GenericStack(patternContent.getCompound("tag"), patternContent.getString("id"), "in");
        List<GenericStack> output = PatternContentHelper.patternTag_to_List_GenericStack(patternContent.getCompound("tag"), patternContent.getString("id"), "out");

        for(int i = 0; i < input.size(); i++)
        {
            allItemStack.add(input.get(i) == null ? null : GenericStack.wrapInItemStack(input.get(i)));
        }

        for(int i = 0; i < output.size(); i++)
        {
            allItemStack.add(output.get(i) == null ? null : GenericStack.wrapInItemStack(output.get(i)));
        }
    }
}
