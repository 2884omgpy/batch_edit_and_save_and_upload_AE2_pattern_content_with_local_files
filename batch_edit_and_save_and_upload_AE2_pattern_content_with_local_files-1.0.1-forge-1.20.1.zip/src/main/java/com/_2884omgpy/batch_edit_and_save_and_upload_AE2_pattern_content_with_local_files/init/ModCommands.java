package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.init;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.command.EditAE2PatternContentCommand;
import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.command.SavePatternProviderPatternContentCommand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;


@Mod.EventBusSubscriber(modid = BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ModCommands
{
    //editae2patterncontent
    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event)
    {
        EditAE2PatternContentCommand.register(event.getDispatcher());
    }

    //savepatternproviderpatterncontent
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event)
    {
        SavePatternProviderPatternContentCommand.register(event.getDispatcher());
    }
}
