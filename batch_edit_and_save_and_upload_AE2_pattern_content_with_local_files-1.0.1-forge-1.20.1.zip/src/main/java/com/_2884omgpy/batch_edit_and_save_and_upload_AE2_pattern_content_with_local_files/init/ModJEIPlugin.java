package com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.init;

import com._2884omgpy.batch_edit_and_save_and_upload_AE2_pattern_content_with_local_files.BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.IRecipeCategoriesLookup;
import mezz.jei.api.recipe.IRecipeLookup;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

import java.util.*;

@JeiPlugin
public class ModJEIPlugin implements IModPlugin
{
    private static IJeiRuntime jeiRuntime;
    private static List<IRecipeCategory<?>> allCategories = new ArrayList<>();
    private static Map<ResourceLocation, List<?>> recipesByType = new HashMap<>();

    @Override
    public @NotNull ResourceLocation getPluginUid()
    {
        return ResourceLocation.fromNamespaceAndPath(BatchEditAndSaveAndUploadAE2PatternContentWithLocalFiles.MOD_ID, "jei_plugin");
    }

    @Override
    public void onRuntimeAvailable(@NotNull IJeiRuntime runtime)
    {
        jeiRuntime = runtime;

        //获取所有配方类别
        IRecipeCategoriesLookup categoriesLookup = runtime.getRecipeManager().createRecipeCategoryLookup();
        allCategories = categoriesLookup.get().toList();

        //预加载每个类别的所有配方
        for (IRecipeCategory<?> category : allCategories)
        {
            RecipeType<?> recipeType = category.getRecipeType();
            IRecipeLookup<?> recipeLookup = runtime.getRecipeManager().createRecipeLookup(recipeType);
            List<?> recipes = recipeLookup.get().toList();
            recipesByType.put(recipeType.getUid(), recipes);
        }
    }

    public static <T> Optional<IRecipeLayoutDrawable<T>> createRecipeLayout(IRecipeCategory<T> category, Object recipe, IFocusGroup focusGroup)
    {
        if (jeiRuntime == null)
        {
            return Optional.empty();
        }
        //获取该类别对应的配方类型类
        Class<? extends T> recipeClass = category.getRecipeType().getRecipeClass();

        //类型不匹配，返回空
        if (!recipeClass.isInstance(recipe))
        {
            return Optional.empty();
        }

        T typedRecipe = recipeClass.cast(recipe);
        return jeiRuntime.getRecipeManager().createRecipeLayoutDrawable(category, typedRecipe, focusGroup);
    }

    public static IFocusGroup getEmptyFocusGroup()
    {
        if (jeiRuntime == null)
        {
            return null; // 或返回一个默认空实现，但这里简单处理
        }
            else
            {
                return jeiRuntime.getJeiHelpers().getFocusFactory().getEmptyFocusGroup();
            }
    }

    public static IJeiRuntime getJeiRuntime()
    {
        return jeiRuntime;
    }

    public static List<IRecipeCategory<?>> getAllCategories()
    {
        return allCategories;
    }

    public static List<?> getRecipesForCategory(IRecipeCategory<?> category)
    {
        return recipesByType.getOrDefault(category.getRecipeType().getUid(), List.of());
    }
}